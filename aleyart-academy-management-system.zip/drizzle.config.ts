import { defineConfig } from "drizzle-kit";
import { config as loadEnv } from "dotenv";

loadEnv({ path: ".env" });

/**
 * Target database for `npx drizzle-kit push`. Reads DATABASE_URL so the same
 * command works for local dev and for creating tables in a hosted database
 * (Neon, Supabase, etc.):
 *
 *   DATABASE_URL="postgresql://...neon.tech/aleyart?sslmode=require" \
 *     npx drizzle-kit push
 */
export default defineConfig({
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  dbCredentials: {
    url:
      process.env.DATABASE_URL ??
      "postgresql://postgres:postgres@127.0.0.1:5432/app_db",
  },
});
