# Free Deployment Guide — ALEYART ACADEMY SMS

One hosted copy, one database, reachable from **every device** (phone, tablet,
laptop, desktop). There's nothing to "sync" — every device reads the same
PostgreSQL through the same URL, so data is always identical everywhere.

**Stack (all free):** GitHub (code) → Neon (PostgreSQL) → Vercel (hosting) →
Vercel Blob (file storage).

Budget 30–45 minutes. You need: a GitHub account, a Neon account and a Vercel
account (all free, sign up with GitHub where possible).

---

## Step 1 — Put the code on GitHub

```bash
# inside the project folder
git init
git add -A
git commit -m "ALEYART ACADEMY School Management System"
git branch -M main
git remote add origin https://github.com/<you>/aleyart-sms.git
git push -u origin main
```

> `.gitignore` already excludes `.env`, `.next`, `node_modules` and
> `data/uploads` — secrets never reach GitHub.

## Step 2 — Free PostgreSQL on Neon

1. https://neon.tech → **Sign up** (GitHub login works) → **New Project**.
2. Name it `aleyart-sms`, pick a region close to Ghana, keep defaults.
3. Open the project → **Connect** → copy the **pooled connection string**.
   It looks like:
   `postgresql://user:pass@ep-xxx-pooler.eu-west-2.aws.neon.tech/aleyart?sslmode=require`

## Step 3 — Create the database tables (one time)

On your own computer, inside the project folder:

```bash
npm install
DATABASE_URL="postgresql://user:pass@...neon.tech/aleyart?sslmode=require" \
  npx drizzle-kit push
```

You only need to repeat this when the schema changes in future updates.

## Step 4 — Deploy on Vercel

1. https://vercel.com → **Add New → Project** → **Import** your GitHub repo.
2. Vercel detects Next.js automatically — do not change build settings.
3. In **Environment Variables**, add:

   | Name | Value |
   |---|---|
   | `DATABASE_URL` | the Neon pooled connection string from Step 2 |
   | `NEXT_PUBLIC_APP_URL` | `https://your-app-name.vercel.app` (the URL Vercel shows, no trailing slash) |

4. **Deploy** → wait ~2 minutes.

The app **auto-seeds on first boot**: roles, permissions, Basic 1–9, subjects,
grading schemes, fee categories, school settings and the default admin account.

## Step 5 — Durable file storage (crests & photos)

Serverless hosting has an **ephemeral disk** — files written to it vanish on
redeploy. The app already supports Vercel Blob (free 1 GB) and uses it
automatically when present:

1. Vercel project → **Storage** → **Create Database → Blob**.
2. **Connect Project** → Vercel injects `BLOB_READ_WRITE_TOKEN`.
3. **Redeploy** (Deployments → ⋯ → Redeploy).

Done — uploaded crests and student photos now persist forever via the Blob CDN.
Without this step the app still works, but re-upload the crest after redeploys.

## Step 6 — First login

1. Open the Vercel URL → sign in `admin` / `admin123`.
2. You'll be **forced to set your own password** before continuing. Do it.
3. Go to **School Settings** → confirm SCHOOL NAME, motto, location, PO box,
   phone → upload the official crest.

## Step 7 — Use it on every device ("sync")

- Phones/tablets: open the same Vercel URL in the browser and sign in.
- For an app feel: browser menu → **"Add to Home Screen"** — it installs as a
  standalone app with the school crest icon thanks to the bundled PWA manifest.
- Laptop/desktop: bookmark the URL.
- Every logged-in device sees **the exact same live data** — changes made on
  one device appear on all others instantly, because all of them talk to the
  single Neon database.

## Step 8 — Optional: custom domain (free)

Vercel project → **Settings → Domains** → add a domain you own (e.g.
`sms.myschool.edu.gh`) and follow the DNS instructions. Free `.vercel.app`
subdomain works fine without this. After setting a domain, update
`NEXT_PUBLIC_APP_URL` to match so **printed QR codes point at the production
URL**, then redeploy.

---

## Operating notes

- **Backups:** Neon free tier keeps **point-in-time restore** for 6 hours;
  also see `docs/BACKUP-AND-RESTORE.md` — run `pg_dump` from any computer
  against the Neon URL for off-site copies.
- **Seeded default account** exists only on a fresh database: `admin` /
  `admin123` (forced change on first login).
- **Security:** credentials are only ever in Vercel env vars / your local
  `.env` — never in Git. Rotate the DB password anytime in Neon's dashboard
  and update the Vercel env var.
- **Vercel free (Hobby) terms:** fine for a private school internal tool. If
  you later need more, the same setup scales by upgrading plans only — no code
  changes.
- **PDF / print exports:** printing uses the browser's print engine (A4 / card
  size, 100% actual size) — nothing extra to install on any device.
