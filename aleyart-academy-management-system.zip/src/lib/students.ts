import { sql } from "drizzle-orm";
import crypto from "node:crypto";
import { db } from "@/db";
import { studentIdCounters } from "@/db/schema";

export const STUDENT_STATUSES = ["active", "inactive", "graduated", "archived"] as const;
export type StudentStatus = (typeof STUDENT_STATUSES)[number];

export const GENDERS = ["male", "female", "other"] as const;

export function buildFullName(first: string, middle: string | null | undefined, last: string): string {
  return [first, middle, last]
    .map((s) => (s ?? "").trim())
    .filter(Boolean)
    .join(" ");
}

/** Extract the starting year from an academic year name: "2026/2027" → 2026. */
export function academicYearStartYear(name: string): number | null {
  const m = /^(\d{4})\/(\d{4})$/.exec(name.trim());
  return m ? Number(m[1]) : null;
}

/** Generate the permanent opaque QR token (issued once, never rotated). */
export function generateQrToken(): string {
  return crypto.randomBytes(48).toString("base64url"); // ~64 URL-safe chars, 384 bits
}

/**
 * Atomically allocate the next permanent Student ID + admission number for an
 * admission year, e.g. (ALA-2026-0001, ADM-2026-0001). Must run inside a
 * transaction — the counter row increments via upsert, race-safe.
 */
export async function issueStudentCodes(
  tx: Pick<typeof db, "execute">,
  yearStart: number,
): Promise<{ studentCode: string; admissionNumber: string }> {
  const result = await tx.execute<{ next_value: number }>(sql`
    INSERT INTO student_id_counters (year, next_value)
    VALUES (${yearStart}, 2)
    ON CONFLICT (year)
    DO UPDATE SET next_value = student_id_counters.next_value + 1
    RETURNING next_value - 1 AS next_value
  `);
  const seq = Number(result.rows[0]?.next_value ?? 1);
  const suffix = String(seq).padStart(4, "0");
  return {
    studentCode: `ALA-${yearStart}-${suffix}`,
    admissionNumber: `ADM-${yearStart}-${suffix}`,
  };
}

export type HistoryAction = "enrolled" | "promoted" | "repeated" | "demoted" | "transferred";

/** Classify a class/year movement for the audit trail + history row label. */
export function classifyMovement(
  currentSortOrder: number | null,
  targetSortOrder: number,
  sameYear: boolean,
): HistoryAction {
  if (sameYear) return "transferred";
  if (currentSortOrder === null) return "enrolled";
  if (targetSortOrder > currentSortOrder) return "promoted";
  if (targetSortOrder === currentSortOrder) return "repeated";
  return "demoted";
}
