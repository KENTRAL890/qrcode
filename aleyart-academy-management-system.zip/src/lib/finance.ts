import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  feeCharges,
  feePayments,
  feeStructures,
  studentFeeAccounts,
} from "@/db/schema";
import { addMoney, subtractMoney, ZERO } from "@/lib/money";

export { PAYMENT_METHODS, type PaymentMethod } from "@/lib/finance-constants";
import { PAYMENT_METHODS as _PM } from "@/lib/finance-constants";
void _PM;

/* ------------------------------------------------------------------ */
/* Permanent receipt numbers — ALA-RCP-2026-000001                     */
/* ------------------------------------------------------------------ */

/**
 * Atomically allocate the next permanent receipt number for a year.
 * Must run inside the payment transaction; the counter upsert is race-safe.
 * Once issued the number is never reused or rewritten.
 */
export async function issueReceiptNumber(
  tx: Pick<typeof db, "execute">,
  year: number,
): Promise<string> {
  const result = await tx.execute<{ next_value: number }>(sql`
    INSERT INTO receipt_counters (year, next_value)
    VALUES (${year}, 2)
    ON CONFLICT (year)
    DO UPDATE SET next_value = receipt_counters.next_value + 1
    RETURNING next_value - 1 AS next_value
  `);
  const seq = Number(result.rows[0]?.next_value ?? 1);
  return `ALA-RCP-${year}-${String(seq).padStart(6, "0")}`;
}

/* ------------------------------------------------------------------ */
/* Account balance recomputation                                       */
/* ------------------------------------------------------------------ */

/**
 * Recompute an account's totals from its ledger rows.
 * Outstanding = Amount Charged − Amount Paid, computed with exact decimals.
 * Reversed charges/payments are excluded from the active totals.
 */
export async function recomputeAccount(
  tx: typeof db,
  accountId: string,
): Promise<{ totalCharged: string; totalPaid: string; outstanding: string }> {
  const chargeRows = await tx
    .select({ amount: feeCharges.amount, kind: feeCharges.kind, status: feeCharges.status })
    .from(feeCharges)
    .where(and(eq(feeCharges.accountId, accountId), eq(feeCharges.status, "active")));

  // charge/adjustment add; reversal rows carry a negative amount
  let totalCharged = ZERO;
  for (const row of chargeRows) {
    totalCharged = addMoney(totalCharged, row.amount);
  }

  const paymentRows = await tx
    .select({ amount: feePayments.amount })
    .from(feePayments)
    .where(and(eq(feePayments.accountId, accountId), eq(feePayments.status, "active")));

  let totalPaid = ZERO;
  for (const row of paymentRows) {
    totalPaid = addMoney(totalPaid, row.amount);
  }

  const outstanding = subtractMoney(totalCharged, totalPaid);

  await tx
    .update(studentFeeAccounts)
    .set({ totalCharged, totalPaid, outstanding, updatedAt: new Date() })
    .where(eq(studentFeeAccounts.id, accountId));

  return { totalCharged, totalPaid, outstanding };
}

/**
 * Find or create the fee account for a student in a given year + term.
 * The class is captured at creation time so the account stays historically
 * accurate even after the student is promoted.
 */
export async function ensureAccount(
  tx: typeof db,
  params: {
    studentId: string;
    studentCode: string;
    academicYearId: string;
    termId: string;
    classId: string | null;
  },
): Promise<string> {
  const [existing] = await tx
    .select({ id: studentFeeAccounts.id })
    .from(studentFeeAccounts)
    .where(
      and(
        eq(studentFeeAccounts.studentId, params.studentId),
        eq(studentFeeAccounts.academicYearId, params.academicYearId),
        eq(studentFeeAccounts.termId, params.termId),
      ),
    )
    .limit(1);
  if (existing) return existing.id;

  const [created] = await tx
    .insert(studentFeeAccounts)
    .values({
      studentId: params.studentId,
      studentCode: params.studentCode,
      academicYearId: params.academicYearId,
      termId: params.termId,
      classId: params.classId,
      totalCharged: ZERO,
      totalPaid: ZERO,
      outstanding: ZERO,
    })
    .returning({ id: studentFeeAccounts.id });
  return created.id;
}

/** Fee structure lines applicable to a class/year/term. */
export async function structureLinesFor(
  classId: string,
  academicYearId: string,
  termId: string,
) {
  return db
    .select()
    .from(feeStructures)
    .where(
      and(
        eq(feeStructures.classId, classId),
        eq(feeStructures.academicYearId, academicYearId),
        eq(feeStructures.isActive, true),
      ),
    );
}

/** CSV escaping that is safe against spreadsheet formula injection. */
export function csvCell(value: unknown): string {
  const text = value === null || value === undefined ? "" : String(value);
  // Neutralise =, +, -, @ leading characters (CSV injection)
  const guarded = /^[=+\-@\t\r]/.test(text) ? `'${text}` : text;
  return `"${guarded.replaceAll('"', '""')}"`;
}

export function toCsv(headers: string[], rows: Array<Array<unknown>>): string {
  const lines = [headers.map(csvCell).join(",")];
  for (const row of rows) lines.push(row.map(csvCell).join(","));
  // BOM makes Excel open UTF-8 correctly
  return "\uFEFF" + lines.join("\r\n");
}
