/** Shared upload constraints safe to import from client components. */
export const MAX_CREST_BYTES = 2 * 1024 * 1024; // 2 MB
export const CREST_ACCEPT = ".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp";
