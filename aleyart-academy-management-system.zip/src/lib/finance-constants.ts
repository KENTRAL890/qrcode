/** Shared finance constants safe to import from client components. */
export const PAYMENT_METHODS = [
  "cash",
  "bank transfer",
  "mobile money",
  "cheque",
  "pos",
] as const;

export type PaymentMethod = (typeof PAYMENT_METHODS)[number];
