import { cache } from "react";
import { redirect } from "next/navigation";
import { db } from "@/db";
import {
  permissions,
  rolePermissions,
  roles,
  sessions,
  userRoles,
  users,
} from "@/db/schema";
import { and, eq, gt, ne, inArray } from "drizzle-orm";
import crypto from "node:crypto";
import { cookies } from "next/headers";
import type { PermissionCode } from "@/lib/permissions";
import { SESSION_COOKIE } from "@/lib/session";

export interface AuthUser {
  id: string;
  username: string;
  fullName: string;
  status: string;
  mustChangePassword: boolean;
  roles: string[];
  permissions: Set<string>;
  sessionId: string;
}

/**
 * Resolve the current authenticated user (server-only).
 * Reads the httpOnly cookie, validates the DB session (expiry + inactivity),
 * then loads roles + permission codes. Returns null when unauthenticated.
 */
export const getCurrentUser = cache(async function getCurrentUser(): Promise<AuthUser | null> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;

  const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
  const now = new Date();

  const [row] = await db
    .select({
      sessionId: sessions.id,
      lastSeenAt: sessions.lastSeenAt,
      userId: users.id,
      username: users.username,
      fullName: users.fullName,
      status: users.status,
      mustChangePassword: users.mustChangePassword,
    })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(and(eq(sessions.tokenHash, tokenHash), gt(sessions.expiresAt, now)))
    .limit(1);

  if (!row) return null;

  // Idle timeout: 60 minutes without activity
  if (now.getTime() - row.lastSeenAt.getTime() > 60 * 60 * 1000) {
    await db.delete(sessions).where(eq(sessions.id, row.sessionId));
    return null;
  }

  if (row.status !== "active") return null;

  // Sliding touch (throttled by react cache + cheap write)
  db.update(sessions)
    .set({ lastSeenAt: now })
    .where(
      and(eq(sessions.id, row.sessionId), ne(sessions.lastSeenAt, now)),
    )
    .execute()
    .catch(() => {});

  const roleRows = await db
    .select({ roleId: userRoles.roleId, name: roles.name })
    .from(userRoles)
    .innerJoin(roles, eq(roles.id, userRoles.roleId))
    .where(eq(userRoles.userId, row.userId));

  const roleIds = roleRows.map((r) => r.roleId);
  const roleNames = roleRows.map((r) => r.name);

  let permCodes: string[] = [];
  if (roleIds.length > 0) {
    const permRows = await db
      .select({ code: permissions.code })
      .from(rolePermissions)
      .innerJoin(permissions, eq(permissions.id, rolePermissions.permissionId))
      .where(inArray(rolePermissions.roleId, roleIds));
    permCodes = permRows.map((p) => p.code);
  }

  return {
    id: row.userId,
    username: row.username,
    fullName: row.fullName,
    status: row.status,
    mustChangePassword: row.mustChangePassword,
    roles: roleNames,
    permissions: new Set(permCodes),
    sessionId: row.sessionId,
  };
});

export function userHasPermission(
  user: Pick<AuthUser, "roles" | "permissions">,
  code: PermissionCode,
): boolean {
  return user.roles.includes("super_admin") || user.permissions.has(code);
}

/** Require an authenticated, active user. Redirects when appropriate. */
export async function requireUser(): Promise<AuthUser> {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.mustChangePassword) redirect("/change-password");
  return user;
}

/** Require a user without forcing the password-change redirect. */
export async function requireUserRaw(): Promise<AuthUser> {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return user;
}

/** Server-side permission enforcement for pages and actions. */
export async function requirePermission(code: PermissionCode): Promise<AuthUser> {
  const user = await requireUser();
  if (!userHasPermission(user, code)) redirect("/forbidden");
  return user;
}

export function isSuperAdmin(user: Pick<AuthUser, "roles">): boolean {
  return user.roles.includes("super_admin");
}
