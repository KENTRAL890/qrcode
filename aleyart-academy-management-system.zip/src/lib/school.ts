import { unstable_cache, revalidateTag } from "next/cache";
import { db } from "@/db";
import { schoolSettings, users } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const BRANDING_TAG = "school-branding";

export interface SchoolBranding {
  id: string | null;
  schoolName: string;
  motto: string;
  location: string;
  poBox: string;
  telephone: string;
  crestUrl: string | null;
  updatedAt: Date | null;
  updatedByName: string | null;
}

/**
 * Last-resort defaults — only rendered if the database has no settings row
 * at all (e.g. before seeding). Under normal operation every value displayed
 * anywhere in the system comes from the single current `school_settings` row.
 */
export const FALLBACK_BRANDING: SchoolBranding = {
  id: null,
  schoolName: "ALEYART ACADEMY",
  motto: "Seeking Wisdom",
  location: "Odokor-Official Town, Ghana",
  poBox: "P.O. Box 4183",
  telephone: "0553797233",
  crestUrl: null,
  updatedAt: null,
  updatedByName: null,
};

const loadBranding = unstable_cache(
  async (): Promise<SchoolBranding> => {
    const [row] = await db
      .select({
        id: schoolSettings.id,
        schoolName: schoolSettings.schoolName,
        motto: schoolSettings.motto,
        location: schoolSettings.location,
        poBox: schoolSettings.poBox,
        telephone: schoolSettings.telephone,
        crestFileId: schoolSettings.crestFileId,
        updatedAt: schoolSettings.updatedAt,
        updatedByName: users.fullName,
      })
      .from(schoolSettings)
      .leftJoin(users, eq(users.id, schoolSettings.updatedBy))
      .where(eq(schoolSettings.isCurrent, true))
      .orderBy(desc(schoolSettings.updatedAt))
      .limit(1);

    if (!row) throw new Error("no-settings-row");

    return {
      id: row.id,
      schoolName: row.schoolName,
      motto: row.motto ?? "",
      location: row.location ?? "",
      poBox: row.poBox ?? "",
      telephone: row.telephone ?? "",
      crestUrl: row.crestFileId ? `/api/files/${row.crestFileId}` : null,
      updatedAt: row.updatedAt,
      updatedByName: row.updatedByName,
    };
  },
  ["school-branding-v1"],
  { tags: [BRANDING_TAG], revalidate: false },
);

/**
 * THE single source of truth for school name, motto, crest and contact info.
 * Every page/layout (login, dashboard, settings, print docs, verification
 * pages, receipts, reports…) must read branding through this function.
 */
export async function getSchoolBranding(): Promise<SchoolBranding> {
  try {
    return await loadBranding();
  } catch {
    return FALLBACK_BRANDING;
  }
}

/** Call after any change to the school_settings row. */
export function revalidateBranding() {
  revalidateTag(BRANDING_TAG, "max");
}
