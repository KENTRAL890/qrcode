/**
 * Central permission + role catalogue.
 * Server-side guards in src/lib/auth.ts enforce these codes.
 */

export const PERMISSIONS = [
  { code: "dashboard.view", name: "View dashboard", module: "Dashboard" },
  { code: "settings.view", name: "View school settings", module: "Settings" },
  { code: "settings.edit", name: "Edit school settings", module: "Settings" },
  { code: "files.upload", name: "Upload school files", module: "Settings" },
  { code: "academic.view", name: "View academic structure", module: "Academic" },
  { code: "academic.manage", name: "Manage academic years, terms & classes", module: "Academic" },
  { code: "subjects.view", name: "View subjects", module: "Academic" },
  { code: "subjects.manage", name: "Manage subjects & assignments", module: "Academic" },
  { code: "users.view", name: "View user accounts", module: "Administration" },
  { code: "users.manage", name: "Create & manage user accounts", module: "Administration" },
  { code: "roles.manage", name: "Assign sensitive roles", module: "Administration" },
  { code: "audit.view", name: "View audit log", module: "Administration" },
  { code: "students.view", name: "View student directory", module: "Students" },
  { code: "students.manage", name: "Create & edit student records", module: "Students" },
  { code: "students.promote", name: "Promote students between classes/years", module: "Students" },
  { code: "assessments.view", name: "View assessments", module: "Assessments" },
  { code: "assessments.manage", name: "Enter & edit assessment scores", module: "Assessments" },
  { code: "reports.view", name: "View terminal reports", module: "Reports" },
  { code: "reports.manage", name: "Generate & edit terminal reports", module: "Reports" },
  { code: "reports.publish", name: "Publish & lock terminal reports", module: "Reports" },
  { code: "reports.unlock", name: "Unlock locked reports", module: "Reports" },
  { code: "grading.manage", name: "Configure grading schemes & aggregate rules", module: "Reports" },
  { code: "fees.view", name: "View fee accounts & balances", module: "Finance" },
  { code: "fees.manage", name: "Configure fee categories & structures", module: "Finance" },
  { code: "payments.record", name: "Record payments & issue receipts", module: "Finance" },
  { code: "payments.reverse", name: "Reverse or adjust financial records", module: "Finance" },
  { code: "finance.reports", name: "View financial reports", module: "Finance" },
  { code: "exports.data", name: "Export data (CSV/Excel)", module: "Finance" },
] as const;

export type PermissionCode = (typeof PERMISSIONS)[number]["code"];

export const ROLE_NAMES = [
  "super_admin",
  "admin",
  "teacher",
  "office_staff",
  "viewer",
] as const;

export type RoleName = (typeof ROLE_NAMES)[number];

export const ROLE_LABELS: Record<string, string> = {
  super_admin: "Super Administrator",
  admin: "Administrator",
  teacher: "Teacher",
  office_staff: "Office Staff",
  viewer: "Viewer",
};

const ALL_CODES = PERMISSIONS.map((p) => p.code);

/** Permissions granted to each built-in role (super admin gets everything). */
export const ROLE_PERMISSION_MAP: Record<RoleName, PermissionCode[]> = {
  super_admin: [...ALL_CODES],
  admin: [
    "dashboard.view",
    "settings.view",
    "settings.edit",
    "files.upload",
    "academic.view",
    "academic.manage",
    "subjects.view",
    "subjects.manage",
    "users.view",
    "users.manage",
    "audit.view",
    "students.view",
    "students.manage",
    "students.promote",
    "assessments.view",
    "assessments.manage",
    "reports.view",
    "reports.manage",
    "reports.publish",
    "reports.unlock",
    "grading.manage",
    "fees.view",
    "fees.manage",
    "payments.record",
    "payments.reverse",
    "finance.reports",
    "exports.data",
  ],
  teacher: [
    "dashboard.view",
    "academic.view",
    "subjects.view",
    "students.view",
    "assessments.view",
    "assessments.manage",
    "reports.view",
    "reports.manage",
  ],
  office_staff: [
    "dashboard.view",
    "academic.view",
    "subjects.view",
    "students.view",
    "students.manage",
    "assessments.view",
    "reports.view",
    "fees.view",
    "payments.record",
    "finance.reports",
    "exports.data",
  ],
  viewer: ["dashboard.view"],
};
