import { db } from "@/db";
import { auditLogs } from "@/db/schema";

export interface AuditEntry {
  userId?: string | null;
  action: string;
  entity: string;
  entityId?: string | null;
  details?: Record<string, unknown> | null;
  ipAddress?: string | null;
}

/**
 * Append an audit event. Never throws — audit failures are logged to the
 * server console so a logging hiccup cannot break a business action.
 * There is deliberately no update/delete API here: the log is append-only
 * and only super_admin can view it in Phase 1.
 */
export async function logAudit(entry: AuditEntry): Promise<void> {
  try {
    await db.insert(auditLogs).values({
      userId: entry.userId ?? null,
      action: entry.action,
      entity: entry.entity,
      entityId: entry.entityId ?? null,
      details: entry.details ?? null,
      ipAddress: entry.ipAddress ?? null,
    });
  } catch (error) {
    console.error("[audit] failed to write audit log:", error);
  }
}
