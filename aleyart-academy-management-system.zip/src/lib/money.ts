/**
 * Exact money handling for financial records.
 *
 * All amounts are stored in PostgreSQL as NUMERIC(12,2) and carried through
 * the application as strings. Arithmetic is performed on integer minor units
 * (pesewas) so IEEE-754 floating point rounding can never corrupt a balance.
 */

const MINOR_UNITS = 100n;

/** Parse a user/DB amount into integer minor units. Throws on bad input. */
export function toMinor(value: string | number): bigint {
  const raw = String(value).trim();
  if (!/^-?\d{1,12}(\.\d{1,2})?$/.test(raw)) {
    throw new Error(`Invalid money value: "${raw}"`);
  }
  const negative = raw.startsWith("-");
  const digits = negative ? raw.slice(1) : raw;
  const [whole, frac = ""] = digits.split(".");
  const padded = (frac + "00").slice(0, 2);
  const minor = BigInt(whole) * MINOR_UNITS + BigInt(padded);
  return negative ? -minor : minor;
}

/** Render integer minor units back to a NUMERIC-safe decimal string. */
export function fromMinor(minor: bigint): string {
  const negative = minor < 0n;
  const abs = negative ? -minor : minor;
  const whole = abs / MINOR_UNITS;
  const frac = abs % MINOR_UNITS;
  return `${negative ? "-" : ""}${whole}.${frac.toString().padStart(2, "0")}`;
}

export function addMoney(...values: Array<string | number>): string {
  return fromMinor(values.reduce<bigint>((sum, v) => sum + toMinor(v), 0n));
}

export function subtractMoney(a: string | number, b: string | number): string {
  return fromMinor(toMinor(a) - toMinor(b));
}

export function compareMoney(a: string | number, b: string | number): number {
  const x = toMinor(a);
  const y = toMinor(b);
  return x === y ? 0 : x > y ? 1 : -1;
}

export function isPositiveMoney(value: string | number): boolean {
  return toMinor(value) > 0n;
}

export function isNegativeMoney(value: string | number): boolean {
  return toMinor(value) < 0n;
}

export function maxMoney(a: string, b: string): string {
  return compareMoney(a, b) >= 0 ? a : b;
}

export interface MoneyValidation {
  ok: boolean;
  error?: string;
  value?: string;
}

/** Validate a user-supplied amount (positive, max 2dp, within range). */
export function validateMoneyInput(
  raw: unknown,
  opts?: { min?: string; max?: string; label?: string },
): MoneyValidation {
  const label = opts?.label ?? "Amount";
  const text = String(raw ?? "").trim();
  if (!text) return { ok: false, error: `${label} is required.` };
  if (!/^\d{1,9}(\.\d{1,2})?$/.test(text)) {
    return {
      ok: false,
      error: `${label} must be a positive number with at most 2 decimal places.`,
    };
  }
  let minor: bigint;
  try {
    minor = toMinor(text);
  } catch {
    return { ok: false, error: `${label} is not a valid amount.` };
  }
  if (minor <= 0n) return { ok: false, error: `${label} must be greater than zero.` };
  if (opts?.min && minor < toMinor(opts.min)) {
    return { ok: false, error: `${label} must be at least ${opts.min}.` };
  }
  if (opts?.max && minor > toMinor(opts.max)) {
    return { ok: false, error: `${label} must not exceed ${opts.max}.` };
  }
  return { ok: true, value: fromMinor(minor) };
}

/** Outstanding = charged − paid, never below zero for display purposes. */
export function computeOutstanding(charged: string, paid: string): string {
  const diff = toMinor(charged) - toMinor(paid);
  return fromMinor(diff);
}

export const ZERO = "0.00";
