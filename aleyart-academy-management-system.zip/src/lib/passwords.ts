import bcrypt from "bcryptjs";

const DUMMY_HASH = bcrypt.hashSync("timing-equalizer", 10);

export function hashPassword(plain: string): string {
  return bcrypt.hashSync(plain, 10);
}

/** Constant-time-ish verification; safe to call with a missing hash. */
export function verifyPassword(plain: string, hash: string | null | undefined): boolean {
  try {
    return bcrypt.compareSync(plain, hash ?? DUMMY_HASH);
  } catch {
    return false;
  }
}

export interface PasswordCheck {
  ok: boolean;
  error?: string;
}

/** Strength rules applied to every new password set in the system. */
export function checkPasswordStrength(
  password: string,
  opts?: { username?: string },
): PasswordCheck {
  if (password.length < 8) {
    return { ok: false, error: "Password must be at least 8 characters long." };
  }
  if (password.length > 128) {
    return { ok: false, error: "Password must be at most 128 characters long." };
  }
  if (!/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) {
    return { ok: false, error: "Password must contain both letters and numbers." };
  }
  if (password.toLowerCase() === "admin123") {
    return { ok: false, error: "The default password is not allowed as a new password." };
  }
  if (opts?.username && password.toLowerCase().includes(opts.username.toLowerCase())) {
    return { ok: false, error: "Password must not contain your username." };
  }
  return { ok: true };
}
