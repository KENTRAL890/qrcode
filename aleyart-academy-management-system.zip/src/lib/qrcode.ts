import QRCode from "qrcode";
import { headers } from "next/headers";

/**
 * Absolute base URL for links printed on physical ID cards. Prefers the
 * configured public URL; otherwise derives it from the incoming request
 * (works behind the platform preview proxy).
 */
export async function getAppBaseUrl(): Promise<string> {
  const configured = process.env.NEXT_PUBLIC_APP_URL?.replace(/\/+$/, "");
  if (configured) return configured;
  try {
    const h = await headers();
    const host = h.get("x-forwarded-host") ?? h.get("host");
    if (host) {
      const proto = h.get("x-forwarded-proto") ?? "https";
      return `${proto}://${host}`;
    }
  } catch {
    /* headers unavailable in this context */
  }
  return "http://localhost:3000";
}

/** The opaque URL embedded in a student's QR code. No personal data inside. */
export async function getVerifyUrl(qrToken: string): Promise<string> {
  const base = await getAppBaseUrl();
  return `${base}/verify/${qrToken}`;
}

/** Vector SVG QR (crisp at print scale), error-correction M. */
export async function qrSvg(text: string): Promise<string> {
  return QRCode.toString(text, {
    type: "svg",
    errorCorrectionLevel: "M",
    margin: 0,
  });
}
