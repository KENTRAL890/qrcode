import crypto from "node:crypto";
import path from "node:path";
import { promises as fs } from "node:fs";

export const UPLOAD_DIR = path.join(process.cwd(), "data", "uploads");

export { MAX_CREST_BYTES, CREST_ACCEPT } from "@/lib/upload-constants";
import { MAX_CREST_BYTES } from "@/lib/upload-constants";

const ALLOWED = {
  jpg: { mimes: ["image/jpeg"], label: "JPG" },
  jpeg: { mimes: ["image/jpeg"], label: "JPEG" },
  png: { mimes: ["image/png"], label: "PNG" },
  webp: { mimes: ["image/webp"], label: "WEBP" },
} as const;

type Ext = keyof typeof ALLOWED;

export function sanitizeOriginalFilename(name: string): string {
  const base = name.split(/[\\/]/).pop() ?? "file";
  return base.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 120) || "file";
}

function detectSignature(buf: Buffer): Ext | null {
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return "jpg";
  if (
    buf.length >= 8 &&
    buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47 &&
    buf[4] === 0x0d && buf[5] === 0x0a && buf[6] === 0x1a && buf[7] === 0x0a
  )
    return "png";
  if (
    buf.length >= 12 &&
    buf.subarray(0, 4).toString("ascii") === "RIFF" &&
    buf.subarray(8, 12).toString("ascii") === "WEBP"
  )
    return "webp";
  return null;
}

export interface ImageValidation {
  ok: boolean;
  error?: string;
  /** canonical extension derived from the real file signature */
  ext?: Ext;
  originalFilename?: string;
  buffer?: Buffer;
}

/**
 * Validate an uploaded image (crest or student photo):
 * - extension whitelist (jpg/jpeg/png/webp), declared MIME whitelist,
 * - magic-byte signature must match the declared type,
 * - configurable size cap, filename sanitized.
 */
export async function validateImageUpload(
  file: File,
  opts: { maxBytes: number; label: string },
): Promise<ImageValidation> {
  const { maxBytes, label } = opts;
  if (!file || file.size === 0) {
    return { ok: false, error: `Please choose a ${label} image to upload.` };
  }
  if (file.size > maxBytes) {
    return {
      ok: false,
      error: `${label} image is too large. Maximum size is ${Math.round(maxBytes / 1048576)} MB.`,
    };
  }

  const originalFilename = sanitizeOriginalFilename(file.name || "crest");
  const rawExt = (originalFilename.split(".").pop() ?? "").toLowerCase();
  if (!(rawExt === "jpg" || rawExt === "jpeg" || rawExt === "png" || rawExt === "webp")) {
    return { ok: false, error: "Unsupported file type. Allowed: JPG, JPEG, PNG, WEBP." };
  }

  const declaredMime = (file.type || "").toLowerCase();
  if (!(ALLOWED as Record<string, { mimes: readonly string[] }>)[rawExt]?.mimes.includes(declaredMime)) {
    return { ok: false, error: "Unsupported MIME type. The file must be a JPG, PNG or WEBP image." };
  }

  const buffer = Buffer.from(await file.arrayBuffer());
  const signature = detectSignature(buffer);
  if (!signature) {
    return { ok: false, error: "The uploaded file is not a valid image (signature check failed)." };
  }
  const declaredIsJpeg = rawExt === "jpg" || rawExt === "jpeg";
  const signatureMatches =
    (signature === "jpg" && declaredIsJpeg) || signature === rawExt;
  if (!signatureMatches) {
    return {
      ok: false,
      error: `File content (${signature.toUpperCase()}) does not match its extension (.${rawExt}).`,
    };
  }

  return {
    ok: true,
    ext: rawExt as Ext,
    originalFilename,
    buffer,
  };
}

/**
 * Persist a validated buffer.
 *
 * Storage strategy (transparent to callers):
 * - When `BLOB_READ_WRITE_TOKEN` is present (Vercel Blob attached): uploads go
 *   to durable cloud object storage and `storagePath` holds the public URL.
 * - Otherwise: the local `data/uploads` directory, served via /api/files/[id].
 */
export async function storeFile(
  ext: string,
  buffer: Buffer,
): Promise<{ storagePath: string; storedFilename: string; checksum: string }> {
  const checksum = crypto.createHash("sha256").update(buffer).digest("hex");
  const storedFilename = `${crypto.randomUUID()}.${ext}`;

  if (process.env.BLOB_READ_WRITE_TOKEN && process.env.NEXT_RUNTIME !== "edge") {
    try {
      const { put } = await import("@vercel/blob");
      const blob = await put(`aleyart/${storedFilename}`, buffer, {
        access: "public",
        addRandomSuffix: false,
      });
      return { storagePath: blob.url, storedFilename, checksum };
    } catch (error) {
      console.error("[storage] blob put failed, falling back to disk:", error);
    }
  }

  await fs.mkdir(UPLOAD_DIR, { recursive: true });
  const storagePath = path.join(UPLOAD_DIR, storedFilename);
  await fs.writeFile(storagePath, buffer, { flag: "wx" });
  return { storagePath, storedFilename, checksum };
}

/** Resolve a stored filename safely inside the uploads directory. */
export function resolveUploadPath(storedFilename: string): string | null {
  if (!/^[a-f0-9-]{36}\.(jpg|jpeg|png|webp)$/i.test(storedFilename)) return null;
  const full = path.join(UPLOAD_DIR, storedFilename);
  const resolved = path.resolve(full);
  if (!resolved.startsWith(path.resolve(UPLOAD_DIR) + path.sep)) return null;
  return resolved;
}

/** School crest validation (2 MB cap). */
export function validateCrestUpload(file: File) {
  return validateImageUpload(file, { maxBytes: MAX_CREST_BYTES, label: "Crest" });
}

/** Student photo validation (2 MB cap). */
export function validateStudentPhotoUpload(file: File) {
  return validateImageUpload(file, { maxBytes: MAX_CREST_BYTES, label: "Student photo" });
}
