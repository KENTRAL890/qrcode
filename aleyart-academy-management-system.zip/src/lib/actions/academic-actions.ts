"use server";

import { revalidatePath } from "next/cache";
import { eq, ne, count } from "drizzle-orm";
import { db } from "@/db";
import { academicYears, classes, studentFeeAccounts, terminalReports, terms } from "@/db/schema";
import { inArray } from "drizzle-orm";
import { requirePermission } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/http";
import type { FormState } from "@/lib/actions/auth-actions";

const YEAR_RE = /^(\d{4})\/(\d{4})$/;

const TERM_DEFINITIONS = [
  { name: "First Term", months: ["09-01", "12-15"] },
  { name: "Second Term", months: ["01-08", "04-10"] },
  { name: "Third Term", months: ["05-05", "08-31"] },
] as const;

function revalidateAcademic() {
  revalidatePath("/academic/years");
  revalidatePath("/academic/classes");
  revalidatePath("/dashboard");
}

/* ------------------------------------------------------------------ */
/* Academic years                                                      */
/* ------------------------------------------------------------------ */

export async function createAcademicYearAction(
  _prev: FormState | null,
  formData: FormData,
): Promise<FormState> {
  const actor = await requirePermission("academic.manage");
  const ip = await getClientIp();

  const name = String(formData.get("name") ?? "").trim();
  const startDate = String(formData.get("startDate") ?? "").trim() || null;
  const endDate = String(formData.get("endDate") ?? "").trim() || null;

  const match = YEAR_RE.exec(name);
  if (!match || Number(match[2]) !== Number(match[1]) + 1) {
    return { error: "Academic year must look like 2026/2027 (consecutive years)." };
  }

  const [exists] = await db
    .select({ id: academicYears.id })
    .from(academicYears)
    .where(eq(academicYears.name, name))
    .limit(1);
  if (exists) return { error: `Academic year ${name} already exists.` };

  const startYear = Number(match[1]);
  const effectiveStart = startDate ?? `${startYear}-09-01`;
  const effectiveEnd = endDate ?? `${startYear + 1}-08-31`;

  const [{ value: yearCount }] = await db.select({ value: count() }).from(academicYears);
  const makeCurrent = yearCount === 0;

  await db.transaction(async (tx) => {
    const [year] = await tx
      .insert(academicYears)
      .values({
        name,
        startDate: effectiveStart,
        endDate: effectiveEnd,
        isCurrent: makeCurrent,
        createdBy: actor.id,
      })
      .returning({ id: academicYears.id });

    await tx.insert(terms).values(
      TERM_DEFINITIONS.map((t, i) => {
        const [startMM, dd1] = t.months[0].split("-");
        const [endMM, dd2] = t.months[1].split("-");
        const firstHalf = Number(startMM) >= 9;
        return {
          name: t.name,
          academicYearId: year.id,
          startDate: `${firstHalf ? startYear : startYear + 1}-${startMM}-${dd1}`,
          endDate: `${Number(endMM) >= 9 ? startYear : startYear + 1}-${endMM}-${dd2}`,
          isCurrent: makeCurrent && i === 0,
        };
      }),
    );
  });

  await logAudit({
    userId: actor.id,
    action: "academic_year.created",
    entity: "academic_year",
    entityId: name,
    details: { name, startDate: effectiveStart, endDate: effectiveEnd, isCurrent: makeCurrent },
    ipAddress: ip,
  });

  revalidateAcademic();
  return { ok: true };
}

export async function setCurrentAcademicYearAction(yearId: string): Promise<FormState> {
  const actor = await requirePermission("academic.manage");
  const ip = await getClientIp();

  const [year] = await db.select().from(academicYears).where(eq(academicYears.id, yearId)).limit(1);
  if (!year) return { error: "Academic year not found." };
  if (year.isArchived) return { error: "An archived academic year cannot be made current." };

  await db.transaction(async (tx) => {
    await tx.update(academicYears).set({ isCurrent: false }).where(ne(academicYears.id, yearId));
    await tx
      .update(academicYears)
      .set({ isCurrent: true, updatedAt: new Date() })
      .where(eq(academicYears.id, yearId));
  });

  await logAudit({
    userId: actor.id,
    action: "academic_year.set_current",
    entity: "academic_year",
    entityId: yearId,
    details: { name: year.name },
    ipAddress: ip,
  });

  revalidateAcademic();
  return { ok: true };
}

export async function setAcademicYearArchivedAction(yearId: string, archived: boolean): Promise<FormState> {
  const actor = await requirePermission("academic.manage");
  const ip = await getClientIp();

  const [year] = await db.select().from(academicYears).where(eq(academicYears.id, yearId)).limit(1);
  if (!year) return { error: "Academic year not found." };
  if (archived && year.isCurrent) {
    return { error: "You cannot archive the current academic year." };
  }

  await db
    .update(academicYears)
    .set({ isArchived: archived, updatedAt: new Date() })
    .where(eq(academicYears.id, yearId));

  await logAudit({
    userId: actor.id,
    action: archived ? "academic_year.archived" : "academic_year.unarchived",
    entity: "academic_year",
    entityId: yearId,
    details: { name: year.name },
    ipAddress: ip,
  });

  revalidateAcademic();
  return { ok: true };
}

/**
 * Deletion is blocked when the year contains historical academic/financial
 * records (reports or invoices tied to any of its terms). Empty years are
 * deletable; populated years must be archived instead.
 */
export async function deleteAcademicYearAction(yearId: string): Promise<FormState> {
  const actor = await requirePermission("academic.manage");
  const ip = await getClientIp();

  const [year] = await db.select().from(academicYears).where(eq(academicYears.id, yearId)).limit(1);
  if (!year) return { error: "Academic year not found." };
  if (year.isCurrent) return { error: "The current academic year cannot be deleted." };

  const yearTerms = await db
    .select({ id: terms.id })
    .from(terms)
    .where(eq(terms.academicYearId, yearId));
  const termIds = yearTerms.map((t) => t.id);

  let recordCount = 0;
  if (termIds.length > 0) {
    const [{ value: reportCount }] = await db
      .select({ value: count() })
      .from(terminalReports)
      .where(inArray(terminalReports.termId, termIds));
    const [{ value: invoiceCount }] = await db
      .select({ value: count() })
      .from(studentFeeAccounts)
      .where(inArray(studentFeeAccounts.termId, termIds));
    recordCount = reportCount + invoiceCount;
  }

  if (recordCount > 0) {
    return {
      error:
        "This academic year contains historical academic or financial records and cannot be deleted. Archive it instead to preserve history.",
    };
  }

  await db.delete(academicYears).where(eq(academicYears.id, yearId));

  await logAudit({
    userId: actor.id,
    action: "academic_year.deleted",
    entity: "academic_year",
    entityId: yearId,
    details: { name: year.name },
    ipAddress: ip,
  });

  revalidateAcademic();
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Terms                                                               */
/* ------------------------------------------------------------------ */

export async function setCurrentTermAction(termId: string): Promise<FormState> {
  const actor = await requirePermission("academic.manage");
  const ip = await getClientIp();

  const [term] = await db.select().from(terms).where(eq(terms.id, termId)).limit(1);
  if (!term) return { error: "Term not found." };

  const [year] = await db
    .select()
    .from(academicYears)
    .where(eq(academicYears.id, term.academicYearId))
    .limit(1);
  if (year?.isArchived) return { error: "Cannot set a current term inside an archived year." };

  await db.transaction(async (tx) => {
    await tx.update(terms).set({ isCurrent: false }).where(ne(terms.id, termId));
    await tx.update(terms).set({ isCurrent: true, updatedAt: new Date() }).where(eq(terms.id, termId));
  });

  await logAudit({
    userId: actor.id,
    action: "term.set_current",
    entity: "term",
    entityId: termId,
    details: { name: term.name, academicYear: year?.name },
    ipAddress: ip,
  });

  revalidateAcademic();
  return { ok: true };
}

export async function updateTermDatesAction(
  termId: string,
  startDate: string | null,
  endDate: string | null,
): Promise<FormState> {
  const actor = await requirePermission("academic.manage");
  const ip = await getClientIp();

  const [term] = await db.select().from(terms).where(eq(terms.id, termId)).limit(1);
  if (!term) return { error: "Term not found." };

  const clean = (v: string | null) => (v && /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : null);

  await db
    .update(terms)
    .set({ startDate: clean(startDate), endDate: clean(endDate), updatedAt: new Date() })
    .where(eq(terms.id, termId));

  await logAudit({
    userId: actor.id,
    action: "term.dates_updated",
    entity: "term",
    entityId: termId,
    details: {
      name: term.name,
      from: { start: term.startDate, end: term.endDate },
      to: { start: clean(startDate), end: clean(endDate) },
    },
    ipAddress: ip,
  });

  revalidateAcademic();
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Classes                                                             */
/* ------------------------------------------------------------------ */

export async function toggleClassActiveAction(classId: string): Promise<FormState> {
  const actor = await requirePermission("academic.manage");
  const ip = await getClientIp();

  const [klass] = await db.select().from(classes).where(eq(classes.id, classId)).limit(1);
  if (!klass) return { error: "Class not found." };

  await db
    .update(classes)
    .set({ isActive: !klass.isActive, updatedAt: new Date() })
    .where(eq(classes.id, classId));

  await logAudit({
    userId: actor.id,
    action: klass.isActive ? "class.deactivated" : "class.activated",
    entity: "class",
    entityId: classId,
    details: { name: klass.name },
    ipAddress: ip,
  });

  revalidateAcademic();
  return { ok: true };
}
