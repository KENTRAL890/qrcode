"use server";

import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { verifyPassword, hashPassword, checkPasswordStrength } from "@/lib/passwords";
import { checkRateLimit, recordRateLimitHit, resetRateLimit } from "@/lib/rate-limit";
import { getClientIp, isSecureRequest } from "@/lib/http";
import { logAudit } from "@/lib/audit";
import {
  createSession,
  setSessionCookie,
  clearSessionCookie,
  destroySession,
  destroyAllUserSessions,
  pruneExpiredSessions,
} from "@/lib/session";
import { getCurrentUser, requireUserRaw } from "@/lib/auth";

export interface FormState {
  ok?: boolean;
  error?: string;
}

function safeNextPath(next: string): string {
  return next.startsWith("/") && !next.startsWith("//") ? next : "/dashboard";
}

/* ------------------------------------------------------------------ */
/* Login                                                               */
/* ------------------------------------------------------------------ */

export async function loginAction(_prev: FormState | null, formData: FormData): Promise<FormState> {
  const ip = await getClientIp();
  const username = String(formData.get("username") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  const next = String(formData.get("next") ?? "");

  if (!username || !password) {
    return { error: "Please enter both your username and password." };
  }

  // Rate limit: 5 attempts per 10 minutes per ip+username
  const rlKey = `${ip ?? "unknown"}:${username}`;
  const rl = checkRateLimit(rlKey);
  if (!rl.allowed) {
    await logAudit({
      action: "auth.login_rate_limited",
      entity: "user",
      details: { username },
      ipAddress: ip,
    });
    return {
      error: `Too many sign-in attempts. Please wait ${Math.max(1, Math.ceil(rl.retryAfterSeconds / 60))} minute(s) and try again.`,
    };
  }

  const [user] = await db
    .select()
    .from(users)
    .where(eq(users.username, username))
    .limit(1);

  if (!user) {
    recordRateLimitHit(rlKey);
    verifyPassword(password, null); // timing equalisation
    await logAudit({
      action: "auth.login_failed",
      entity: "user",
      details: { username, reason: "unknown_user" },
      ipAddress: ip,
    });
    return { error: "Invalid username or password." };
  }

  if (user.lockedUntil && user.lockedUntil > new Date()) {
    const mins = Math.max(1, Math.ceil((user.lockedUntil.getTime() - Date.now()) / 60000));
    return { error: `This account is temporarily locked. Try again in ${mins} minute(s).` };
  }

  if (user.status !== "active") {
    await logAudit({
      action: "auth.login_failed",
      entity: "user",
      entityId: user.id,
      details: { reason: "account_disabled" },
      ipAddress: ip,
    });
    return { error: "This account has been deactivated. Contact your administrator." };
  }

  if (!verifyPassword(password, user.passwordHash)) {
    recordRateLimitHit(rlKey);
    const attempts = user.failedAttempts + 1;
    const now = new Date();
    if (attempts >= 5) {
      await db
        .update(users)
        .set({ failedAttempts: 0, lockedUntil: new Date(now.getTime() + 15 * 60 * 1000) })
        .where(eq(users.id, user.id));
      await logAudit({
        action: "auth.account_locked",
        entity: "user",
        entityId: user.id,
        details: { minutes: 15 },
        ipAddress: ip,
      });
      return { error: "Too many failed attempts. This account is locked for 15 minutes." };
    }
    await db.update(users).set({ failedAttempts: attempts }).where(eq(users.id, user.id));
    await logAudit({
      action: "auth.login_failed",
      entity: "user",
      entityId: user.id,
      details: { reason: "bad_password" },
      ipAddress: ip,
    });
    return { error: "Invalid username or password." };
  }

  // Success
  resetRateLimit(rlKey);
  await db
    .update(users)
    .set({ failedAttempts: 0, lockedUntil: null, lastLoginAt: new Date() })
    .where(eq(users.id, user.id));
  pruneExpiredSessions().catch(() => {});

  const h = await headers();
  const { token, expiresAt } = await createSession(user.id, {
    ipAddress: ip,
    userAgent: h.get("user-agent"),
  });
  await setSessionCookie(token, expiresAt, await isSecureRequest());

  await logAudit({
    userId: user.id,
    action: "auth.login",
    entity: "user",
    entityId: user.id,
    ipAddress: ip,
  });

  if (user.mustChangePassword) redirect("/change-password");
  redirect(safeNextPath(next));
}

/* ------------------------------------------------------------------ */
/* Logout                                                              */
/* ------------------------------------------------------------------ */

export async function logoutAction(): Promise<void> {
  const user = await getCurrentUser();
  const ip = await getClientIp();
  if (user) {
    await destroySession(user.sessionId);
    await logAudit({
      userId: user.id,
      action: "auth.logout",
      entity: "user",
      entityId: user.id,
      ipAddress: ip,
    });
  }
  await clearSessionCookie();
  redirect("/login");
}

/* ------------------------------------------------------------------ */
/* Change password (forced after first login)                          */
/* ------------------------------------------------------------------ */

export async function changePasswordAction(_prev: FormState | null, formData: FormData): Promise<FormState> {
  const user = await requireUserRaw();
  const ip = await getClientIp();

  const current = String(formData.get("currentPassword") ?? "");
  const next = String(formData.get("newPassword") ?? "");
  const confirm = String(formData.get("confirmPassword") ?? "");

  if (!current || !next || !confirm) {
    return { error: "All three password fields are required." };
  }
  if (next !== confirm) {
    return { error: "New password and confirmation do not match." };
  }

  const [row] = await db.select().from(users).where(eq(users.id, user.id)).limit(1);
  if (!row || !verifyPassword(current, row.passwordHash)) {
    return { error: "Your current password is incorrect." };
  }
  if (verifyPassword(next, row.passwordHash)) {
    return { error: "New password must be different from the current password." };
  }

  const strength = checkPasswordStrength(next, { username: user.username });
  if (!strength.ok) return { error: strength.error };

  await db
    .update(users)
    .set({
      passwordHash: hashPassword(next),
      mustChangePassword: false,
      updatedAt: new Date(),
    })
    .where(eq(users.id, user.id));

  // Invalidate every other session of this account
  await destroyAllUserSessions(user.id, user.sessionId);

  await logAudit({
    userId: user.id,
    action: "auth.password_changed",
    entity: "user",
    entityId: user.id,
    details: { forced: user.mustChangePassword },
    ipAddress: ip,
  });

  redirect("/dashboard");
}
