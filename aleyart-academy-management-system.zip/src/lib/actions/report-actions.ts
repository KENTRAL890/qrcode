"use server";

import { revalidatePath } from "next/cache";
import { and, asc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import {
  academicYears,
  assessments,
  classes,
  students,
  subjects,
  terminalReports,
  terms,
} from "@/db/schema";
import { requirePermission, userHasPermission, isSuperAdmin } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/http";
import { getSchoolBranding } from "@/lib/school";
import {
  loadBands,
  loadAggregateConfig,
  computeAggregate,
  rankScores,
  loadTeacherScope,
  scopeAllowsClass,
} from "@/lib/grading";
import type { FormState } from "@/lib/actions/auth-actions";

/* ------------------------------------------------------------------ */
/* Snapshot shape — everything needed to reprint a historical report   */
/* ------------------------------------------------------------------ */

export interface ReportSnapshot {
  version: 1;
  capturedAt: string;
  school: {
    schoolName: string;
    motto: string;
    location: string;
    poBox: string;
    telephone: string;
    crestUrl: string | null;
  };
  student: {
    fullName: string;
    studentCode: string;
    admissionNumber: string;
    gender: string;
    photoUrl: string | null;
  };
  academic: {
    className: string;
    academicYear: string;
    term: string;
    classSize: number | null;
  };
  results: Array<{
    subject: string;
    classScore: number;
    examScore: number;
    total: number;
    grade: string;
    gradeLabel: string | null;
    remarks: string | null;
    position: number | null;
  }>;
  totals: {
    totalScore: number;
    averageScore: number;
    overallPosition: number | null;
    aggregate: number | null;
    aggregateBreakdown?: Array<{ subjectName: string; total: number; points: number; role: string }>;
  };
  remarks: {
    teacher: string | null;
    headteacher: string | null;
  };
}

/* ------------------------------------------------------------------ */
/* Computation shared by preview + publish                             */
/* ------------------------------------------------------------------ */

async function computeReportData(studentId: string, termId: string) {
  const [term] = await db.select().from(terms).where(eq(terms.id, termId)).limit(1);
  if (!term) return { error: "Term not found." } as const;

  const [year] = await db
    .select()
    .from(academicYears)
    .where(eq(academicYears.id, term.academicYearId))
    .limit(1);
  if (!year) return { error: "Academic year not found." } as const;

  const [student] = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!student) return { error: "Student not found." } as const;

  // Results for this student/term — class comes from the assessment rows
  // (historical class), NOT from the student's current class.
  const rows = await db
    .select({
      subjectId: assessments.subjectId,
      subjectName: subjects.name,
      classScore: assessments.classScore,
      examScore: assessments.examScore,
      total: assessments.total,
      grade: assessments.grade,
      gradeLabel: assessments.gradeLabel,
      remarks: assessments.remarks,
      classId: assessments.classId,
    })
    .from(assessments)
    .innerJoin(subjects, eq(subjects.id, assessments.subjectId))
    .where(and(eq(assessments.studentId, studentId), eq(assessments.termId, termId)))
    .orderBy(asc(subjects.name));

  if (rows.length === 0) {
    return { error: "No assessment results recorded for this student in this term." } as const;
  }

  const historicalClassId = rows[0].classId;
  const [klass] = await db
    .select()
    .from(classes)
    .where(eq(classes.id, historicalClassId))
    .limit(1);
  if (!klass) return { error: "Historical class not found." } as const;

  const config = await loadAggregateConfig(klass.levelGroup);

  /* ---- subject positions within the historical class/term -------- */
  const cohort = await db
    .select({
      studentId: assessments.studentId,
      subjectId: assessments.subjectId,
      total: assessments.total,
    })
    .from(assessments)
    .where(and(eq(assessments.termId, termId), eq(assessments.classId, historicalClassId)));

  const bySubject = new Map<string, Array<{ studentId: string; total: number }>>();
  const byStudentTotal = new Map<string, number>();
  for (const row of cohort) {
    const total = Number(row.total);
    if (!bySubject.has(row.subjectId)) bySubject.set(row.subjectId, []);
    bySubject.get(row.subjectId)!.push({ studentId: row.studentId, total });
    byStudentTotal.set(row.studentId, (byStudentTotal.get(row.studentId) ?? 0) + total);
  }

  const subjectPositions = new Map<string, number>();
  for (const [subjectId, entries] of bySubject) {
    const ranks = rankScores(entries.map((e) => e.total), config.rankingMethod);
    entries.forEach((entry, i) => {
      if (entry.studentId === studentId) subjectPositions.set(subjectId, ranks[i]);
    });
  }

  /* ---- overall position ----------------------------------------- */
  const cohortStudents = Array.from(byStudentTotal.entries());
  const overallRanks = rankScores(cohortStudents.map(([, t]) => t), config.rankingMethod);
  let overallPosition: number | null = null;
  cohortStudents.forEach(([sid], i) => {
    if (sid === studentId) overallPosition = overallRanks[i];
  });

  /* ---- aggregate (Basic 7–9) ------------------------------------- */
  let aggregate: number | null = null;
  let aggregateBreakdown: Array<{ subjectName: string; total: number; points: number; role: string }> | undefined;
  if (klass.levelGroup === "upper") {
    const aggregateBands = await loadBands("aggregate");
    const result = computeAggregate(
      rows.map((r) => ({ subjectName: r.subjectName, total: Number(r.total) })),
      config,
      aggregateBands,
    );
    aggregate = result.aggregate;
    aggregateBreakdown = result.breakdown;
  }

  const totalScore = rows.reduce((sum, r) => sum + Number(r.total), 0);
  const averageScore = Math.round((totalScore / rows.length) * 100) / 100;

  return {
    student,
    klass,
    year,
    term,
    classSize: cohortStudents.length,
    results: rows.map((r) => ({
      subject: r.subjectName,
      classScore: Number(r.classScore),
      examScore: Number(r.examScore),
      total: Number(r.total),
      grade: r.grade,
      gradeLabel: r.gradeLabel,
      remarks: r.remarks,
      position: subjectPositions.get(r.subjectId) ?? null,
    })),
    totalScore: Math.round(totalScore * 100) / 100,
    averageScore,
    overallPosition: overallPosition as number | null,
    aggregate,
    aggregateBreakdown,
  } as const;
}

/** Live (unsnapshotted) report data for drafts and previews. */
export async function getLiveReportData(studentId: string, termId: string) {
  return computeReportData(studentId, termId);
}

/* ------------------------------------------------------------------ */
/* Generate / refresh a DRAFT report                                   */
/* ------------------------------------------------------------------ */

export async function generateReportAction(
  studentId: string,
  termId: string,
  remarks?: { teacher?: string | null; headteacher?: string | null },
): Promise<FormState & { reportId?: string }> {
  const actor = await requirePermission("reports.manage");
  const ip = await getClientIp();

  const data = await computeReportData(studentId, termId);
  if ("error" in data) return { error: data.error };

  const unrestricted = isSuperAdmin(actor) || userHasPermission(actor, "reports.publish");
  const scope = await loadTeacherScope(actor.id, unrestricted);
  if (!scopeAllowsClass(scope, data.klass.id)) {
    return { error: "You are not assigned to this class." };
  }

  // Existing report for this identity (student + year + term)?
  const [existing] = await db
    .select()
    .from(terminalReports)
    .where(
      and(
        eq(terminalReports.studentId, studentId),
        eq(terminalReports.academicYearId, data.year.id),
        eq(terminalReports.termId, termId),
      ),
    )
    .limit(1);

  if (existing && existing.status !== "draft") {
    return {
      error: `This report is ${existing.status}. Unlock/revert it before regenerating.`,
      reportId: existing.id,
    };
  }

  const payload = {
    studentId,
    studentCode: data.student.studentCode,
    academicYearId: data.year.id,
    termId,
    classId: data.klass.id,
    title: `${data.term.name} Report — ${data.year.name}`,
    status: "draft" as const,
    totalScore: String(data.totalScore),
    averageScore: String(data.averageScore),
    overallPosition: data.overallPosition,
    classSize: data.classSize,
    aggregate: data.aggregate,
    teacherRemarks: remarks?.teacher?.trim().slice(0, 500) ?? existing?.teacherRemarks ?? null,
    headteacherRemarks:
      remarks?.headteacher?.trim().slice(0, 500) ?? existing?.headteacherRemarks ?? null,
    createdBy: actor.id,
    updatedAt: new Date(),
  };

  let reportId: string;
  if (existing) {
    await db.update(terminalReports).set(payload).where(eq(terminalReports.id, existing.id));
    reportId = existing.id;
  } else {
    const [created] = await db
      .insert(terminalReports)
      .values(payload)
      .returning({ id: terminalReports.id });
    reportId = created.id;
  }

  await logAudit({
    userId: actor.id,
    action: existing ? "report.regenerated" : "report.generated",
    entity: "terminal_report",
    entityId: reportId,
    details: {
      studentCode: data.student.studentCode,
      class: data.klass.name,
      academicYear: data.year.name,
      term: data.term.name,
      subjects: data.results.length,
      average: data.averageScore,
      position: data.overallPosition,
      aggregate: data.aggregate,
    },
    ipAddress: ip,
  });

  revalidatePath("/reports");
  revalidatePath(`/reports/${reportId}`);
  return { ok: true, reportId };
}

/* ------------------------------------------------------------------ */
/* Publish — captures the immutable historical snapshot                */
/* ------------------------------------------------------------------ */

export async function publishReportAction(reportId: string): Promise<FormState> {
  const actor = await requirePermission("reports.publish");
  const ip = await getClientIp();

  const [report] = await db
    .select()
    .from(terminalReports)
    .where(eq(terminalReports.id, reportId))
    .limit(1);
  if (!report) return { error: "Report not found." };
  if (report.status === "locked") return { error: "This report is locked. Unlock it first." };
  if (report.status === "published") return { error: "This report is already published." };

  const data = await computeReportData(report.studentId, report.termId);
  if ("error" in data) return { error: data.error };

  // Branding is read at publication time and frozen into the snapshot.
  const brand = await getSchoolBranding();

  const snapshot: ReportSnapshot = {
    version: 1,
    capturedAt: new Date().toISOString(),
    school: {
      schoolName: brand.schoolName,
      motto: brand.motto,
      location: brand.location,
      poBox: brand.poBox,
      telephone: brand.telephone,
      crestUrl: brand.crestUrl,
    },
    student: {
      fullName: data.student.fullName,
      studentCode: data.student.studentCode,
      admissionNumber: data.student.admissionNumber,
      gender: data.student.gender,
      photoUrl: data.student.photoFileId ? `/api/files/${data.student.photoFileId}` : null,
    },
    academic: {
      className: data.klass.name, // HISTORICAL class
      academicYear: data.year.name,
      term: data.term.name,
      classSize: data.classSize,
    },
    results: data.results,
    totals: {
      totalScore: data.totalScore,
      averageScore: data.averageScore,
      overallPosition: data.overallPosition,
      aggregate: data.aggregate,
      aggregateBreakdown: data.aggregateBreakdown,
    },
    remarks: {
      teacher: report.teacherRemarks,
      headteacher: report.headteacherRemarks,
    },
  };

  await db.transaction(async (tx) => {
    await tx
      .update(terminalReports)
      .set({
        status: "published",
        snapshot,
        totalScore: String(data.totalScore),
        averageScore: String(data.averageScore),
        overallPosition: data.overallPosition,
        classSize: data.classSize,
        aggregate: data.aggregate,
        classId: data.klass.id,
        publishedAt: new Date(),
        publishedBy: actor.id,
        updatedAt: new Date(),
      })
      .where(eq(terminalReports.id, reportId));

    // Freeze the contributing assessments
    await tx
      .update(assessments)
      .set({ status: "locked", updatedAt: new Date() })
      .where(
        and(eq(assessments.studentId, report.studentId), eq(assessments.termId, report.termId)),
      );
  });

  await logAudit({
    userId: actor.id,
    action: "report.published",
    entity: "terminal_report",
    entityId: reportId,
    details: {
      studentCode: data.student.studentCode,
      historicalClass: data.klass.name,
      academicYear: data.year.name,
      term: data.term.name,
      snapshotSchoolName: brand.schoolName,
      snapshotMotto: brand.motto,
      average: data.averageScore,
    },
    ipAddress: ip,
  });

  revalidatePath("/reports");
  revalidatePath(`/reports/${reportId}`);
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Lock / unlock                                                       */
/* ------------------------------------------------------------------ */

export async function lockReportAction(reportId: string): Promise<FormState> {
  const actor = await requirePermission("reports.publish");
  const ip = await getClientIp();

  const [report] = await db
    .select()
    .from(terminalReports)
    .where(eq(terminalReports.id, reportId))
    .limit(1);
  if (!report) return { error: "Report not found." };
  if (report.status === "draft") {
    return { error: "Publish the report before locking it." };
  }
  if (report.status === "locked") return { error: "This report is already locked." };
  if (!report.snapshot) return { error: "Cannot lock a report without a published snapshot." };

  await db
    .update(terminalReports)
    .set({ status: "locked", lockedAt: new Date(), lockedBy: actor.id, updatedAt: new Date() })
    .where(eq(terminalReports.id, reportId));

  await logAudit({
    userId: actor.id,
    action: "report.locked",
    entity: "terminal_report",
    entityId: reportId,
    details: { studentCode: report.studentCode },
    ipAddress: ip,
  });

  revalidatePath("/reports");
  revalidatePath(`/reports/${reportId}`);
  return { ok: true };
}

/** Unlocking requires the dedicated permission and is always audited. */
export async function unlockReportAction(reportId: string, reason: string): Promise<FormState> {
  const actor = await requirePermission("reports.unlock");
  const ip = await getClientIp();

  const trimmed = (reason ?? "").trim();
  if (trimmed.length < 5) {
    return { error: "Please give a reason (at least 5 characters) for unlocking this report." };
  }

  const [report] = await db
    .select()
    .from(terminalReports)
    .where(eq(terminalReports.id, reportId))
    .limit(1);
  if (!report) return { error: "Report not found." };
  if (report.status !== "locked") return { error: "Only locked reports can be unlocked." };

  await db
    .update(terminalReports)
    .set({ status: "published", lockedAt: null, lockedBy: null, updatedAt: new Date() })
    .where(eq(terminalReports.id, reportId));

  await logAudit({
    userId: actor.id,
    action: "report.unlocked",
    entity: "terminal_report",
    entityId: reportId,
    details: {
      studentCode: report.studentCode,
      reason: trimmed.slice(0, 300),
      previouslyLockedBy: report.lockedBy,
    },
    ipAddress: ip,
  });

  revalidatePath("/reports");
  revalidatePath(`/reports/${reportId}`);
  return { ok: true };
}

/** Revert a published (not locked) report to draft so scores can change. */
export async function revertReportToDraftAction(reportId: string): Promise<FormState> {
  const actor = await requirePermission("reports.publish");
  const ip = await getClientIp();

  const [report] = await db
    .select()
    .from(terminalReports)
    .where(eq(terminalReports.id, reportId))
    .limit(1);
  if (!report) return { error: "Report not found." };
  if (report.status !== "published") {
    return { error: "Only published reports can be reverted to draft." };
  }

  await db.transaction(async (tx) => {
    await tx
      .update(terminalReports)
      .set({ status: "draft", updatedAt: new Date() })
      .where(eq(terminalReports.id, reportId));
    await tx
      .update(assessments)
      .set({ status: "submitted", updatedAt: new Date() })
      .where(
        and(eq(assessments.studentId, report.studentId), eq(assessments.termId, report.termId)),
      );
  });

  await logAudit({
    userId: actor.id,
    action: "report.reverted_to_draft",
    entity: "terminal_report",
    entityId: reportId,
    details: { studentCode: report.studentCode, snapshotRetained: Boolean(report.snapshot) },
    ipAddress: ip,
  });

  revalidatePath("/reports");
  revalidatePath(`/reports/${reportId}`);
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Remarks                                                             */
/* ------------------------------------------------------------------ */

export async function saveReportRemarksAction(
  reportId: string,
  teacherRemarks: string,
  headteacherRemarks: string,
): Promise<FormState> {
  const actor = await requirePermission("reports.manage");
  const ip = await getClientIp();

  const [report] = await db
    .select()
    .from(terminalReports)
    .where(eq(terminalReports.id, reportId))
    .limit(1);
  if (!report) return { error: "Report not found." };
  if (report.status !== "draft") {
    return { error: `This report is ${report.status}; remarks can only be edited on drafts.` };
  }

  await db
    .update(terminalReports)
    .set({
      teacherRemarks: teacherRemarks.trim().slice(0, 500) || null,
      headteacherRemarks: headteacherRemarks.trim().slice(0, 500) || null,
      updatedAt: new Date(),
    })
    .where(eq(terminalReports.id, reportId));

  await logAudit({
    userId: actor.id,
    action: "report.remarks_updated",
    entity: "terminal_report",
    entityId: reportId,
    details: { studentCode: report.studentCode },
    ipAddress: ip,
  });

  revalidatePath(`/reports/${reportId}`);
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Bulk generation for a whole class/term                              */
/* ------------------------------------------------------------------ */

export async function bulkGenerateReportsAction(
  classId: string,
  termId: string,
): Promise<FormState & { generated?: number; skipped?: Array<{ name: string; reason: string }> }> {
  const actor = await requirePermission("reports.manage");
  const ip = await getClientIp();

  const unrestricted = isSuperAdmin(actor) || userHasPermission(actor, "reports.publish");
  const scope = await loadTeacherScope(actor.id, unrestricted);
  if (!scopeAllowsClass(scope, classId)) {
    return { error: "You are not assigned to this class." };
  }

  // Students who actually have assessments for this class+term (historical)
  const rows = await db
    .selectDistinct({ studentId: assessments.studentId })
    .from(assessments)
    .where(and(eq(assessments.classId, classId), eq(assessments.termId, termId)));

  if (rows.length === 0) {
    return { error: "No assessment results found for this class and term." };
  }

  const names = await db
    .select({ id: students.id, fullName: students.fullName })
    .from(students)
    .where(inArray(students.id, rows.map((r) => r.studentId)));
  const nameById = new Map(names.map((n) => [n.id, n.fullName]));

  let generated = 0;
  const skipped: Array<{ name: string; reason: string }> = [];
  for (const row of rows) {
    const result = await generateReportAction(row.studentId, termId);
    if (result.ok) generated += 1;
    else skipped.push({ name: nameById.get(row.studentId) ?? "Unknown", reason: result.error! });
  }

  await logAudit({
    userId: actor.id,
    action: "report.bulk_generated",
    entity: "terminal_report",
    details: { classId, termId, generated, skipped: skipped.length },
    ipAddress: ip,
  });

  revalidatePath("/reports");
  return { ok: true, generated, skipped };
}
