"use server";

import { revalidatePath } from "next/cache";
import { eq, desc } from "drizzle-orm";
import { db } from "@/db";
import { fileMetadata, schoolSettings } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/http";
import { revalidateBranding } from "@/lib/school";
import { validateCrestUpload, storeFile } from "@/lib/files";
import type { FormState } from "@/lib/actions/auth-actions";

function clean(v: FormDataEntryValue | null): string {
  return String(v ?? "").trim();
}

/** Load the single current settings row id (creates none — seed guarantees it). */
async function getCurrentSettingsRow() {
  const [row] = await db
    .select()
    .from(schoolSettings)
    .where(eq(schoolSettings.isCurrent, true))
    .orderBy(desc(schoolSettings.updatedAt))
    .limit(1);
  return row ?? null;
}

/* ------------------------------------------------------------------ */
/* Update school identity fields (name, motto, location, PO box, tel)  */
/* ------------------------------------------------------------------ */

export async function updateSchoolSettingsAction(
  _prev: FormState | null,
  formData: FormData,
): Promise<FormState> {
  const actor = await requirePermission("settings.edit");
  const ip = await getClientIp();

  const schoolName = clean(formData.get("schoolName"));
  const motto = clean(formData.get("motto"));
  const location = clean(formData.get("location"));
  const poBox = clean(formData.get("poBox"));
  const telephone = clean(formData.get("telephone"));

  if (schoolName.length < 2 || schoolName.length > 160) {
    return { error: "School name is required (2–160 characters)." };
  }
  if (motto.length > 200) return { error: "Motto must be at most 200 characters." };
  if (location.length > 200) return { error: "Location must be at most 200 characters." };
  if (poBox.length > 60) return { error: "P.O. Box must be at most 60 characters." };
  if (telephone && !/^[0-9+()\-.\s]{5,40}$/.test(telephone)) {
    return { error: "Telephone may only contain digits, spaces and + ( ) - ." };
  }

  const before = await getCurrentSettingsRow();
  if (!before) return { error: "School settings record not found. Please reseed the database." };

  await db
    .update(schoolSettings)
    .set({
      schoolName,
      motto: motto || null,
      location: location || null,
      poBox: poBox || null,
      telephone: telephone || null,
      updatedAt: new Date(),
      updatedBy: actor.id,
    })
    .where(eq(schoolSettings.id, before.id));

  const changes: Array<{ field: string; from: string | null; to: string | null }> = [];
  const diff = (field: string, from: string | null, to: string | null) => {
    if ((from ?? "") !== (to ?? "")) changes.push({ field, from, to });
  };
  diff("school_name", before.schoolName, schoolName);
  diff("motto", before.motto, motto || null);
  diff("location", before.location, location || null);
  diff("po_box", before.poBox, poBox || null);
  diff("telephone", before.telephone, telephone || null);

  if (changes.length > 0) {
    await logAudit({
      userId: actor.id,
      action: "settings.updated",
      entity: "school_settings",
      entityId: before.id,
      details: { changes },
      ipAddress: ip,
    });

    // Dedicated, easily-filterable events for the headline identity fields
    const nameChange = changes.find((c) => c.field === "school_name");
    if (nameChange) {
      await logAudit({
        userId: actor.id,
        action: "settings.school_name_changed",
        entity: "school_settings",
        entityId: before.id,
        details: { from: nameChange.from, to: nameChange.to },
        ipAddress: ip,
      });
    }
    const mottoChange = changes.find((c) => c.field === "motto");
    if (mottoChange) {
      await logAudit({
        userId: actor.id,
        action: "settings.motto_changed",
        entity: "school_settings",
        entityId: before.id,
        details: { from: mottoChange.from, to: mottoChange.to },
        ipAddress: ip,
      });
    }
  }

  revalidateBranding();
  revalidatePath("/", "layout");
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Upload + bind a new school crest                                    */
/* ------------------------------------------------------------------ */

export async function uploadCrestAction(
  _prev: FormState | null,
  formData: FormData,
): Promise<FormState> {
  const actor = await requirePermission("settings.edit");
  await requirePermission("files.upload");
  const ip = await getClientIp();

  const file = formData.get("crest");
  if (!(file instanceof File)) {
    return { error: "Please choose a crest image to upload." };
  }

  const validation = await validateCrestUpload(file);
  if (!validation.ok) return { error: validation.error };

  const stored = await storeFile(validation.ext!, validation.buffer!);

  let metaId: string;
  try {
    const [meta] = await db
      .insert(fileMetadata)
      .values({
        originalFilename: validation.originalFilename!,
        storedFilename: stored.storedFilename,
        storagePath: stored.storagePath,
        mimeType: file.type,
        sizeBytes: validation.buffer!.length,
        checksum: stored.checksum,
        purpose: "crest",
        uploadedBy: actor.id,
      })
      .returning({ id: fileMetadata.id });
    metaId = meta.id;
  } catch (error) {
    console.error("[crest] metadata insert failed:", error);
    return { error: "Could not record the crest file. Please try again." };
  }

  const row = await getCurrentSettingsRow();
  if (!row) return { error: "School settings record not found." };

  await db
    .update(schoolSettings)
    .set({ crestFileId: metaId, updatedAt: new Date(), updatedBy: actor.id })
    .where(eq(schoolSettings.id, row.id));

  await logAudit({
    userId: actor.id,
    action: "settings.crest_changed",
    entity: "school_settings",
    entityId: row.id,
    details: {
      fileId: metaId,
      originalFilename: validation.originalFilename,
      sizeBytes: validation.buffer!.length,
      mimeType: file.type,
      previousCrestFileId: row.crestFileId,
    },
    ipAddress: ip,
  });

  revalidateBranding();
  revalidatePath("/", "layout");
  return { ok: true };
}
