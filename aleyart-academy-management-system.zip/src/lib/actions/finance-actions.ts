"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  academicYears,
  classes,
  feeCategories,
  feeCharges,
  feePayments,
  feeStructures,
  students,
  studentFeeAccounts,
  terms,
} from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/http";
import { getSchoolBranding } from "@/lib/school";
import { validateMoneyInput, addMoney, fromMinor, toMinor, ZERO } from "@/lib/money";
import { ensureAccount, issueReceiptNumber, recomputeAccount } from "@/lib/finance";
import { PAYMENT_METHODS } from "@/lib/finance-constants";
import { academicYearStartYear } from "@/lib/students";
import type { FormState } from "@/lib/actions/auth-actions";

function revalidateFinance(studentId?: string) {
  revalidatePath("/finance");
  revalidatePath("/finance/payments");
  revalidatePath("/finance/reports");
  revalidatePath("/dashboard");
  if (studentId) revalidatePath(`/students/${studentId}`);
}

/* ------------------------------------------------------------------ */
/* Fee categories                                                      */
/* ------------------------------------------------------------------ */

export async function createFeeCategoryAction(
  _prev: FormState | null,
  formData: FormData,
): Promise<FormState> {
  const actor = await requirePermission("fees.manage");
  const ip = await getClientIp();

  const name = String(formData.get("name") ?? "").trim().replace(/\s+/g, " ");
  const code = String(formData.get("code") ?? "").trim().toUpperCase();
  const description = String(formData.get("description") ?? "").trim().slice(0, 300) || null;
  const isRecurring = formData.get("isRecurring") === "on";

  if (name.length < 2 || name.length > 80) {
    return { error: "Category name is required (2–80 characters)." };
  }
  if (!/^[A-Z0-9_]{2,20}$/.test(code)) {
    return { error: "Code must be 2–20 characters: A–Z, 0–9 or underscore." };
  }

  const [dupName] = await db
    .select({ id: feeCategories.id })
    .from(feeCategories)
    .where(eq(feeCategories.name, name))
    .limit(1);
  if (dupName) return { error: `A category named "${name}" already exists.` };
  const [dupCode] = await db
    .select({ id: feeCategories.id })
    .from(feeCategories)
    .where(eq(feeCategories.code, code))
    .limit(1);
  if (dupCode) return { error: `Code "${code}" is already in use.` };

  const [created] = await db
    .insert(feeCategories)
    .values({ name, code, description, isRecurring, isActive: true })
    .returning({ id: feeCategories.id });

  await logAudit({
    userId: actor.id,
    action: "fee_category.created",
    entity: "fee_category",
    entityId: created.id,
    details: { name, code, isRecurring },
    ipAddress: ip,
  });

  revalidateFinance();
  return { ok: true };
}

export async function toggleFeeCategoryAction(categoryId: string): Promise<FormState> {
  const actor = await requirePermission("fees.manage");
  const ip = await getClientIp();

  const [cat] = await db
    .select()
    .from(feeCategories)
    .where(eq(feeCategories.id, categoryId))
    .limit(1);
  if (!cat) return { error: "Fee category not found." };

  await db
    .update(feeCategories)
    .set({ isActive: !cat.isActive, updatedAt: new Date() })
    .where(eq(feeCategories.id, categoryId));

  await logAudit({
    userId: actor.id,
    action: cat.isActive ? "fee_category.deactivated" : "fee_category.activated",
    entity: "fee_category",
    entityId: categoryId,
    details: { name: cat.name },
    ipAddress: ip,
  });

  revalidateFinance();
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Fee structures                                                      */
/* ------------------------------------------------------------------ */

export async function saveFeeStructureAction(
  _prev: FormState | null,
  formData: FormData,
): Promise<FormState> {
  const actor = await requirePermission("fees.manage");
  const ip = await getClientIp();

  const categoryId = String(formData.get("categoryId") ?? "");
  const classId = String(formData.get("classId") ?? "");
  const termId = String(formData.get("termId") ?? "");
  const amountRaw = formData.get("amount");

  if (!categoryId || !classId || !termId) {
    return { error: "Category, class and term are all required." };
  }
  const money = validateMoneyInput(amountRaw, { label: "Amount", max: "999999.99" });
  if (!money.ok) return { error: money.error };

  const [term] = await db.select().from(terms).where(eq(terms.id, termId)).limit(1);
  if (!term) return { error: "Term not found." };
  const [klass] = await db.select().from(classes).where(eq(classes.id, classId)).limit(1);
  if (!klass) return { error: "Class not found." };
  const [cat] = await db
    .select()
    .from(feeCategories)
    .where(eq(feeCategories.id, categoryId))
    .limit(1);
  if (!cat) return { error: "Fee category not found." };
  if (!cat.isActive) return { error: `${cat.name} is inactive.` };

  const [existing] = await db
    .select()
    .from(feeStructures)
    .where(
      and(
        eq(feeStructures.categoryId, categoryId),
        eq(feeStructures.classId, classId),
        eq(feeStructures.academicYearId, term.academicYearId),
        eq(feeStructures.termId, termId),
      ),
    )
    .limit(1);

  if (existing) {
    await db
      .update(feeStructures)
      .set({ amount: money.value!, isActive: true, updatedAt: new Date() })
      .where(eq(feeStructures.id, existing.id));
  } else {
    await db.insert(feeStructures).values({
      categoryId,
      classId,
      academicYearId: term.academicYearId,
      termId,
      amount: money.value!,
      isActive: true,
      createdBy: actor.id,
    });
  }

  await logAudit({
    userId: actor.id,
    action: existing ? "fee_structure.updated" : "fee_structure.created",
    entity: "fee_structure",
    entityId: existing?.id ?? `${cat.code}/${klass.name}`,
    details: {
      category: cat.name,
      class: klass.name,
      term: term.name,
      amount: money.value,
      previousAmount: existing?.amount ?? null,
    },
    ipAddress: ip,
  });

  revalidateFinance();
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Charges                                                             */
/* ------------------------------------------------------------------ */

/** Post a single charge line to a student's account for a term. */
export async function createChargeAction(
  _prev: FormState | null,
  formData: FormData,
): Promise<FormState> {
  const actor = await requirePermission("fees.manage");
  const ip = await getClientIp();

  const studentId = String(formData.get("studentId") ?? "");
  const termId = String(formData.get("termId") ?? "");
  const categoryId = String(formData.get("categoryId") ?? "") || null;
  const description = String(formData.get("description") ?? "").trim().slice(0, 200);
  const money = validateMoneyInput(formData.get("amount"), { label: "Amount", max: "999999.99" });
  if (!money.ok) return { error: money.error };
  if (!studentId || !termId) return { error: "Student and term are required." };

  const [student] = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!student) return { error: "Student not found." };
  const [term] = await db.select().from(terms).where(eq(terms.id, termId)).limit(1);
  if (!term) return { error: "Term not found." };

  let categoryName = "Custom charge";
  if (categoryId) {
    const [cat] = await db
      .select()
      .from(feeCategories)
      .where(eq(feeCategories.id, categoryId))
      .limit(1);
    if (!cat) return { error: "Fee category not found." };
    categoryName = cat.name;
  }

  const accountId = await db.transaction(async (tx) => {
    const id = await ensureAccount(tx as unknown as typeof db, {
      studentId,
      studentCode: student.studentCode,
      academicYearId: term.academicYearId,
      termId,
      classId: student.classId,
    });
    await tx.insert(feeCharges).values({
      accountId: id,
      studentId,
      categoryId,
      description: description || categoryName,
      amount: money.value!,
      kind: "charge",
      status: "active",
      createdBy: actor.id,
    });
    await recomputeAccount(tx as unknown as typeof db, id);
    return id;
  });

  await logAudit({
    userId: actor.id,
    action: "fee_charge.created",
    entity: "fee_charge",
    entityId: accountId,
    details: {
      studentCode: student.studentCode,
      category: categoryName,
      description: description || categoryName,
      amount: money.value,
      term: term.name,
    },
    ipAddress: ip,
  });

  revalidateFinance(studentId);
  return { ok: true };
}

/** Apply the whole fee structure for the student's class/term in one go. */
export async function applyFeeStructureAction(
  studentId: string,
  termId: string,
): Promise<FormState & { applied?: number; total?: string }> {
  const actor = await requirePermission("fees.manage");
  const ip = await getClientIp();

  const [student] = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!student) return { error: "Student not found." };
  if (!student.classId) return { error: "Student has no class assigned." };
  const [term] = await db.select().from(terms).where(eq(terms.id, termId)).limit(1);
  if (!term) return { error: "Term not found." };

  const lines = await db
    .select({
      amount: feeStructures.amount,
      categoryId: feeStructures.categoryId,
      categoryName: feeCategories.name,
    })
    .from(feeStructures)
    .innerJoin(feeCategories, eq(feeCategories.id, feeStructures.categoryId))
    .where(
      and(
        eq(feeStructures.classId, student.classId),
        eq(feeStructures.academicYearId, term.academicYearId),
        eq(feeStructures.termId, termId),
        eq(feeStructures.isActive, true),
      ),
    );

  if (lines.length === 0) {
    return { error: "No fee structure is defined for this class, year and term." };
  }

  let total = ZERO;
  const accountId = await db.transaction(async (tx) => {
    const id = await ensureAccount(tx as unknown as typeof db, {
      studentId,
      studentCode: student.studentCode,
      academicYearId: term.academicYearId,
      termId,
      classId: student.classId,
    });

    const existing = await tx
      .select({ description: feeCharges.description })
      .from(feeCharges)
      .where(and(eq(feeCharges.accountId, id), eq(feeCharges.status, "active")));
    const already = new Set(existing.map((e) => e.description));

    for (const line of lines) {
      if (already.has(line.categoryName)) continue; // don't double-charge
      await tx.insert(feeCharges).values({
        accountId: id,
        studentId,
        categoryId: line.categoryId,
        description: line.categoryName,
        amount: line.amount,
        kind: "charge",
        status: "active",
        createdBy: actor.id,
      });
      total = addMoney(total, line.amount);
    }
    await recomputeAccount(tx as unknown as typeof db, id);
    return id;
  });

  await logAudit({
    userId: actor.id,
    action: "fee_charge.structure_applied",
    entity: "fee_charge",
    entityId: accountId,
    details: { studentCode: student.studentCode, term: term.name, total, lines: lines.length },
    ipAddress: ip,
  });

  revalidateFinance(studentId);
  return { ok: true, applied: lines.length, total };
}

/** Reverse a charge — never deletes; posts a negative counter-entry. */
export async function reverseChargeAction(
  chargeId: string,
  reason: string,
): Promise<FormState> {
  const actor = await requirePermission("payments.reverse");
  const ip = await getClientIp();

  const trimmed = (reason ?? "").trim();
  if (trimmed.length < 5) return { error: "Provide a reason (at least 5 characters)." };

  const [charge] = await db.select().from(feeCharges).where(eq(feeCharges.id, chargeId)).limit(1);
  if (!charge) return { error: "Charge not found." };
  if (charge.status !== "active") return { error: "This charge has already been reversed." };

  await db.transaction(async (tx) => {
    await tx
      .update(feeCharges)
      .set({ status: "reversed" })
      .where(eq(feeCharges.id, chargeId));
    await tx.insert(feeCharges).values({
      accountId: charge.accountId,
      studentId: charge.studentId,
      categoryId: charge.categoryId,
      description: `Reversal — ${charge.description}`,
      amount: fromMinor(-toMinor(charge.amount)),
      kind: "reversal",
      reversalOfId: charge.id,
      status: "active",
      note: trimmed.slice(0, 300),
      createdBy: actor.id,
    });
    await recomputeAccount(tx as unknown as typeof db, charge.accountId);
  });

  await logAudit({
    userId: actor.id,
    action: "fee_charge.reversed",
    entity: "fee_charge",
    entityId: chargeId,
    details: { amount: charge.amount, description: charge.description, reason: trimmed },
    ipAddress: ip,
  });

  revalidateFinance(charge.studentId);
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Payments + permanent receipts                                       */
/* ------------------------------------------------------------------ */

export async function recordPaymentAction(
  _prev: FormState | null,
  formData: FormData,
): Promise<FormState & { paymentId?: string; receiptNumber?: string }> {
  const actor = await requirePermission("payments.record");
  const ip = await getClientIp();

  const studentId = String(formData.get("studentId") ?? "");
  const termId = String(formData.get("termId") ?? "");
  const method = String(formData.get("method") ?? "cash").toLowerCase();
  const reference = String(formData.get("reference") ?? "").trim().slice(0, 80) || null;
  const notes = String(formData.get("notes") ?? "").trim().slice(0, 300) || null;
  const paidAtRaw = String(formData.get("paidAt") ?? "").trim();

  const money = validateMoneyInput(formData.get("amount"), { label: "Payment amount", max: "999999.99" });
  if (!money.ok) return { error: money.error };
  if (!studentId || !termId) return { error: "Student and term are required." };
  if (!(PAYMENT_METHODS as readonly string[]).includes(method)) {
    return { error: "Unsupported payment method." };
  }
  let paidAt = new Date();
  if (paidAtRaw) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(paidAtRaw)) return { error: "Payment date is invalid." };
    paidAt = new Date(`${paidAtRaw}T12:00:00Z`);
    if (Number.isNaN(paidAt.getTime())) return { error: "Payment date is invalid." };
    if (paidAt.getTime() > Date.now() + 86400000) {
      return { error: "Payment date cannot be in the future." };
    }
  }

  const [student] = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!student) return { error: "Student not found." };
  const [term] = await db.select().from(terms).where(eq(terms.id, termId)).limit(1);
  if (!term) return { error: "Term not found." };
  const [year] = await db
    .select()
    .from(academicYears)
    .where(eq(academicYears.id, term.academicYearId))
    .limit(1);
  if (!year) return { error: "Academic year not found." };

  const [klass] = student.classId
    ? await db.select().from(classes).where(eq(classes.id, student.classId)).limit(1)
    : [null];

  // Branding frozen onto the receipt at issue time (accounting integrity)
  const brand = await getSchoolBranding();
  const yearStart = academicYearStartYear(year.name) ?? new Date().getFullYear();

  let result: { id: string; receiptNumber: string };
  try {
    result = await db.transaction(async (tx) => {
      const accountId = await ensureAccount(tx as unknown as typeof db, {
        studentId,
        studentCode: student.studentCode,
        academicYearId: term.academicYearId,
        termId,
        classId: student.classId,
      });

      const receiptNumber = await issueReceiptNumber(tx, yearStart);

      const [payment] = await tx
        .insert(feePayments)
        .values({
          receiptNumber,
          accountId,
          studentId,
          studentCode: student.studentCode,
          academicYearId: term.academicYearId,
          termId,
          classId: student.classId,
          amount: money.value!,
          method,
          reference,
          notes,
          paidAt,
          status: "active",
          receivedBy: actor.id,
          receivedByName: actor.fullName,
          snapshot: {
            version: 1,
            capturedAt: new Date().toISOString(),
            school: {
              schoolName: brand.schoolName,
              motto: brand.motto,
              location: brand.location,
              poBox: brand.poBox,
              telephone: brand.telephone,
              crestUrl: brand.crestUrl,
            },
            student: {
              fullName: student.fullName,
              studentCode: student.studentCode,
              className: klass?.name ?? null,
            },
            academic: { academicYear: year.name, term: term.name },
          },
        })
        .returning({ id: feePayments.id, receiptNumber: feePayments.receiptNumber });

      await recomputeAccount(tx as unknown as typeof db, accountId);
      return payment;
    });
  } catch (error) {
    console.error("[finance] payment failed:", error);
    return { error: "Could not record the payment. No changes were saved." };
  }

  await logAudit({
    userId: actor.id,
    action: "payment.recorded",
    entity: "payment",
    entityId: result.id,
    details: {
      receiptNumber: result.receiptNumber,
      studentCode: student.studentCode,
      amount: money.value,
      method,
      term: term.name,
      academicYear: year.name,
    },
    ipAddress: ip,
  });
  await logAudit({
    userId: actor.id,
    action: "receipt.issued",
    entity: "receipt",
    entityId: result.receiptNumber,
    details: { paymentId: result.id, studentCode: student.studentCode, amount: money.value },
    ipAddress: ip,
  });

  revalidateFinance(studentId);
  return { ok: true, paymentId: result.id, receiptNumber: result.receiptNumber };
}

/** Reverse a payment. The original row and its receipt number are preserved. */
export async function reversePaymentAction(
  paymentId: string,
  reason: string,
): Promise<FormState> {
  const actor = await requirePermission("payments.reverse");
  const ip = await getClientIp();

  const trimmed = (reason ?? "").trim();
  if (trimmed.length < 5) {
    return { error: "Provide a reason (at least 5 characters) for the reversal." };
  }

  const [payment] = await db
    .select()
    .from(feePayments)
    .where(eq(feePayments.id, paymentId))
    .limit(1);
  if (!payment) return { error: "Payment not found." };
  if (payment.status !== "active") return { error: "This payment has already been reversed." };

  await db.transaction(async (tx) => {
    await tx
      .update(feePayments)
      .set({
        status: "reversed",
        reversedAt: new Date(),
        reversedBy: actor.id,
        reversalReason: trimmed.slice(0, 300),
        updatedAt: new Date(),
      })
      .where(eq(feePayments.id, paymentId));
    await recomputeAccount(tx as unknown as typeof db, payment.accountId);
  });

  await logAudit({
    userId: actor.id,
    action: "payment.reversed",
    entity: "payment",
    entityId: paymentId,
    details: {
      receiptNumber: payment.receiptNumber,
      studentCode: payment.studentCode,
      amount: payment.amount,
      reason: trimmed,
    },
    ipAddress: ip,
  });

  revalidateFinance(payment.studentId);
  return { ok: true };
}

/** Count a receipt reprint — the receipt number itself never changes. */
export async function registerReceiptPrintAction(paymentId: string): Promise<FormState> {
  const actor = await requirePermission("payments.record");
  const ip = await getClientIp();

  const [payment] = await db
    .select()
    .from(feePayments)
    .where(eq(feePayments.id, paymentId))
    .limit(1);
  if (!payment) return { error: "Payment not found." };

  await db
    .update(feePayments)
    .set({ printCount: payment.printCount + 1 })
    .where(eq(feePayments.id, paymentId));

  await logAudit({
    userId: actor.id,
    action: payment.printCount === 0 ? "receipt.printed" : "receipt.reprinted",
    entity: "receipt",
    entityId: payment.receiptNumber,
    details: {
      studentCode: payment.studentCode,
      printNumber: payment.printCount + 1,
      receiptNumberUnchanged: payment.receiptNumber,
    },
    ipAddress: ip,
  });

  return { ok: true };
}
