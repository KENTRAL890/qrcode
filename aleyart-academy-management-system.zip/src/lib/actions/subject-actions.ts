"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { classes, classSubjects, subjects } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/http";
import type { FormState } from "@/lib/actions/auth-actions";

function revalidateSubjects() {
  revalidatePath("/academic/subjects");
  revalidatePath("/academic/classes");
}

/* ------------------------------------------------------------------ */
/* Create subject (+ optional class assignments)                       */
/* ------------------------------------------------------------------ */

export async function createSubjectAction(
  _prev: FormState | null,
  formData: FormData,
): Promise<FormState> {
  const actor = await requirePermission("subjects.manage");
  const ip = await getClientIp();

  const name = String(formData.get("name") ?? "").trim().replace(/\s+/g, " ");
  const description = String(formData.get("description") ?? "").trim();
  const classIds = formData.getAll("classIds").map(String);
  const asCore = formData.get("isCore") === "on" || formData.get("isCore") === "true";

  if (name.length < 2 || name.length > 120) {
    return { error: "Subject name is required (2–120 characters)." };
  }
  if (/\bICT\b/i.test(name)) {
    return { error: 'Use "Computing" instead of "ICT" for the computing subject.' };
  }

  const [dup] = await db
    .select({ id: subjects.id })
    .from(subjects)
    .where(eq(subjects.name, name))
    .limit(1);
  if (dup) return { error: `A subject named "${name}" already exists.` };

  const subjectId = await db.transaction(async (tx) => {
    const [created] = await tx
      .insert(subjects)
      .values({ name, description: description || null })
      .returning({ id: subjects.id });

    if (classIds.length > 0) {
      const validClasses = await tx
        .select({ id: classes.id })
        .from(classes);
      const validSet = new Set(validClasses.map((c) => c.id));
      const rows = classIds
        .filter((id) => validSet.has(id))
        .map((classId) => ({ classId, subjectId: created.id, isCore: asCore }));
      if (rows.length > 0) await tx.insert(classSubjects).values(rows);
    }
    return created.id;
  });

  await logAudit({
    userId: actor.id,
    action: "subject.created",
    entity: "subject",
    entityId: subjectId,
    details: { name, assignedClassCount: classIds.length, isCore: asCore },
    ipAddress: ip,
  });

  revalidateSubjects();
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Rename / describe                                                   */
/* ------------------------------------------------------------------ */

export async function updateSubjectAction(
  subjectId: string,
  updates: { name: string; description?: string | null },
): Promise<FormState> {
  const actor = await requirePermission("subjects.manage");
  const ip = await getClientIp();

  const name = updates.name.trim().replace(/\s+/g, " ");
  if (name.length < 2 || name.length > 120) {
    return { error: "Subject name is required (2–120 characters)." };
  }
  if (/\bICT\b/i.test(name)) {
    return { error: 'Use "Computing" instead of "ICT" for the computing subject.' };
  }

  const [subject] = await db.select().from(subjects).where(eq(subjects.id, subjectId)).limit(1);
  if (!subject) return { error: "Subject not found." };

  const [dup] = await db
    .select({ id: subjects.id })
    .from(subjects)
    .where(eq(subjects.name, name))
    .limit(1);
  if (dup && dup.id !== subjectId) return { error: `Another subject named "${name}" already exists.` };

  await db
    .update(subjects)
    .set({ name, description: updates.description?.trim() || null, updatedAt: new Date() })
    .where(eq(subjects.id, subjectId));

  if (subject.name !== name) {
    await logAudit({
      userId: actor.id,
      action: "subject.renamed",
      entity: "subject",
      entityId: subjectId,
      details: { from: subject.name, to: name },
      ipAddress: ip,
    });
  }

  revalidateSubjects();
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Activate / deactivate (never hard-delete referenced subjects)       */
/* ------------------------------------------------------------------ */

export async function toggleSubjectActiveAction(subjectId: string): Promise<FormState> {
  const actor = await requirePermission("subjects.manage");
  const ip = await getClientIp();

  const [subject] = await db.select().from(subjects).where(eq(subjects.id, subjectId)).limit(1);
  if (!subject) return { error: "Subject not found." };

  await db
    .update(subjects)
    .set({ isActive: !subject.isActive, updatedAt: new Date() })
    .where(eq(subjects.id, subjectId));

  await logAudit({
    userId: actor.id,
    action: subject.isActive ? "subject.deactivated" : "subject.activated",
    entity: "subject",
    entityId: subjectId,
    details: { name: subject.name },
    ipAddress: ip,
  });

  revalidateSubjects();
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Class assignments                                                   */
/* ------------------------------------------------------------------ */

export async function assignSubjectToClassAction(
  subjectId: string,
  classId: string,
  isCore: boolean,
): Promise<FormState> {
  const actor = await requirePermission("subjects.manage");
  const ip = await getClientIp();

  const [subject] = await db.select().from(subjects).where(eq(subjects.id, subjectId)).limit(1);
  const [klass] = await db.select().from(classes).where(eq(classes.id, classId)).limit(1);
  if (!subject || !klass) return { error: "Subject or class not found." };

  const [existing] = await db
    .select({ id: classSubjects.id })
    .from(classSubjects)
    .where(and(eq(classSubjects.subjectId, subjectId), eq(classSubjects.classId, classId)))
    .limit(1);
  if (existing) return { error: `${subject.name} is already assigned to ${klass.name}.` };

  await db.insert(classSubjects).values({ subjectId, classId, isCore });

  await logAudit({
    userId: actor.id,
    action: "subject.assigned_to_class",
    entity: "subject",
    entityId: subjectId,
    details: { subject: subject.name, class: klass.name, isCore },
    ipAddress: ip,
  });

  revalidateSubjects();
  return { ok: true };
}

export async function removeClassSubjectAction(classSubjectId: string): Promise<FormState> {
  const actor = await requirePermission("subjects.manage");
  const ip = await getClientIp();

  const [row] = await db
    .select({
      id: classSubjects.id,
      subjectName: subjects.name,
      className: classes.name,
    })
    .from(classSubjects)
    .innerJoin(subjects, eq(subjects.id, classSubjects.subjectId))
    .innerJoin(classes, eq(classes.id, classSubjects.classId))
    .where(eq(classSubjects.id, classSubjectId))
    .limit(1);
  if (!row) return { error: "Assignment not found." };

  await db.delete(classSubjects).where(eq(classSubjects.id, classSubjectId));

  await logAudit({
    userId: actor.id,
    action: "subject.unassigned_from_class",
    entity: "subject",
    entityId: classSubjectId,
    details: { subject: row.subjectName, class: row.className },
    ipAddress: ip,
  });

  revalidateSubjects();
  return { ok: true };
}

export async function toggleClassSubjectCoreAction(classSubjectId: string): Promise<FormState> {
  const actor = await requirePermission("subjects.manage");
  const ip = await getClientIp();

  const [row] = await db
    .select({
      id: classSubjects.id,
      isCore: classSubjects.isCore,
      subjectName: subjects.name,
      className: classes.name,
    })
    .from(classSubjects)
    .innerJoin(subjects, eq(subjects.id, classSubjects.subjectId))
    .innerJoin(classes, eq(classes.id, classSubjects.classId))
    .where(eq(classSubjects.id, classSubjectId))
    .limit(1);
  if (!row) return { error: "Assignment not found." };

  await db
    .update(classSubjects)
    .set({ isCore: !row.isCore })
    .where(eq(classSubjects.id, classSubjectId));

  await logAudit({
    userId: actor.id,
    action: "subject.class_core_toggled",
    entity: "subject",
    entityId: classSubjectId,
    details: { subject: row.subjectName, class: row.className, isCore: !row.isCore },
    ipAddress: ip,
  });

  revalidateSubjects();
  return { ok: true };
}
