"use server";

import { revalidatePath } from "next/cache";
import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { roles, userRoles, users } from "@/db/schema";
import { requirePermission, isSuperAdmin, userHasPermission } from "@/lib/auth";
import { hashPassword, checkPasswordStrength } from "@/lib/passwords";
import { destroyAllUserSessions } from "@/lib/session";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/http";
import { ROLE_NAMES, ROLE_LABELS, type RoleName } from "@/lib/permissions";
import type { FormState } from "@/lib/actions/auth-actions";

const USERNAME_RE = /^[a-z0-9._-]{3,40}$/;

async function getTargetUserRoles(userId: string): Promise<string[]> {
  const rows = await db
    .select({ name: roles.name })
    .from(userRoles)
    .innerJoin(roles, eq(roles.id, userRoles.roleId))
    .where(eq(userRoles.userId, userId));
  return rows.map((r) => r.name);
}

async function ensureCanTouchTarget(actorId: string, actorIsSuper: boolean, targetId: string) {
  const targetRoles = await getTargetUserRoles(targetId);
  if (targetRoles.includes("super_admin") && !actorIsSuper) {
    throw new Error("Only a Super Administrator can modify a Super Administrator account.");
  }
  return targetRoles;
}

/* ------------------------------------------------------------------ */
/* Create user                                                         */
/* ------------------------------------------------------------------ */

export async function createUserAction(_prev: FormState | null, formData: FormData): Promise<FormState> {
  const actor = await requirePermission("users.manage");
  const ip = await getClientIp();

  const username = String(formData.get("username") ?? "").trim().toLowerCase();
  const fullName = String(formData.get("fullName") ?? "").trim();
  const password = String(formData.get("password") ?? "");
  const requestedRoles = formData
    .getAll("roles")
    .map((r) => String(r))
    .filter((r): r is RoleName => (ROLE_NAMES as readonly string[]).includes(r));

  if (!USERNAME_RE.test(username)) {
    return { error: "Username must be 3–40 chars: lowercase letters, numbers, dot, dash or underscore." };
  }
  if (fullName.length < 2 || fullName.length > 120) {
    return { error: "Full name is required (2–120 characters)." };
  }
  const strength = checkPasswordStrength(password, { username });
  if (!strength.ok) return { error: strength.error };
  if (requestedRoles.length === 0) {
    return { error: "Assign at least one role to the new account." };
  }
  if (requestedRoles.includes("super_admin") && !userHasPermission(actor, "roles.manage") && !isSuperAdmin(actor)) {
    return { error: "Only a Super Administrator can create Super Administrator accounts." };
  }

  const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.username, username)).limit(1);
  if (existing) return { error: `The username "${username}" is already taken.` };

  const [created] = await db
    .insert(users)
    .values({
      username,
      fullName,
      passwordHash: hashPassword(password),
      status: "active",
      mustChangePassword: true, // credentials are temporary until first login
      createdBy: actor.id,
    })
    .returning({ id: users.id });

  const roleRows = await db.select().from(roles).where(inArray(roles.name, requestedRoles));
  if (roleRows.length > 0) {
    await db.insert(userRoles).values(
      roleRows.map((r) => ({ userId: created.id, roleId: r.id, assignedBy: actor.id })),
    );
  }

  await logAudit({
    userId: actor.id,
    action: "user.created",
    entity: "user",
    entityId: created.id,
    details: { username, fullName, roles: requestedRoles.map((r) => ROLE_LABELS[r] ?? r) },
    ipAddress: ip,
  });

  revalidatePath("/admin/users");
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Activate / deactivate                                               */
/* ------------------------------------------------------------------ */

export async function setUserStatusAction(userId: string, status: "active" | "disabled"): Promise<FormState> {
  const actor = await requirePermission("users.manage");
  const ip = await getClientIp();

  if (actor.id === userId) {
    return { error: "You cannot deactivate your own account." };
  }
  const [target] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!target) return { error: "User not found." };

  try {
    await ensureCanTouchTarget(actor.id, isSuperAdmin(actor), userId);
  } catch (e) {
    return { error: (e as Error).message };
  }

  await db.update(users).set({ status, updatedAt: new Date() }).where(eq(users.id, userId));
  if (status === "disabled") await destroyAllUserSessions(userId);

  await logAudit({
    userId: actor.id,
    action: status === "active" ? "user.activated" : "user.deactivated",
    entity: "user",
    entityId: userId,
    details: { username: target.username },
    ipAddress: ip,
  });

  revalidatePath("/admin/users");
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Role assignment                                                     */
/* ------------------------------------------------------------------ */

export async function updateUserRolesAction(
  userId: string,
  nextRoleNames: string[],
): Promise<FormState> {
  const actor = await requirePermission("users.manage");
  const ip = await getClientIp();

  const validNames = nextRoleNames.filter((r): r is RoleName =>
    (ROLE_NAMES as readonly string[]).includes(r),
  );
  if (validNames.length === 0) {
    return { error: "A user must keep at least one role." };
  }

  const [target] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!target) return { error: "User not found." };

  let currentRoles: string[];
  try {
    currentRoles = await ensureCanTouchTarget(actor.id, isSuperAdmin(actor), userId);
  } catch (e) {
    return { error: (e as Error).message };
  }

  const touchesSuper =
    validNames.includes("super_admin") || currentRoles.includes("super_admin");
  if (touchesSuper && !isSuperAdmin(actor)) {
    return { error: "Only a Super Administrator can grant or revoke the Super Administrator role." };
  }
  if (actor.id === userId && currentRoles.includes("super_admin") && !validNames.includes("super_admin")) {
    return { error: "You cannot remove your own Super Administrator role." };
  }

  await db.transaction(async (tx) => {
    await tx.delete(userRoles).where(eq(userRoles.userId, userId));
    const roleRows = await tx.select().from(roles).where(inArray(roles.name, validNames));
    if (roleRows.length > 0) {
      await tx.insert(userRoles).values(
        roleRows.map((r) => ({ userId, roleId: r.id, assignedBy: actor.id })),
      );
    }
  });

  await logAudit({
    userId: actor.id,
    action: "user.roles_updated",
    entity: "user",
    entityId: userId,
    details: {
      username: target.username,
      from: currentRoles,
      to: validNames,
    },
    ipAddress: ip,
  });

  revalidatePath("/admin/users");
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Administrative password reset                                       */
/* ------------------------------------------------------------------ */

export async function resetUserPasswordAction(userId: string, newPassword: string): Promise<FormState> {
  const actor = await requirePermission("users.manage");
  const ip = await getClientIp();

  const [target] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!target) return { error: "User not found." };

  try {
    await ensureCanTouchTarget(actor.id, isSuperAdmin(actor), userId);
  } catch (e) {
    return { error: (e as Error).message };
  }

  const strength = checkPasswordStrength(newPassword, { username: target.username });
  if (!strength.ok) return { error: strength.error };

  await db
    .update(users)
    .set({
      passwordHash: hashPassword(newPassword),
      mustChangePassword: true,
      failedAttempts: 0,
      lockedUntil: null,
      updatedAt: new Date(),
    })
    .where(eq(users.id, userId));
  await destroyAllUserSessions(userId);

  await logAudit({
    userId: actor.id,
    action: "user.password_reset",
    entity: "user",
    entityId: userId,
    details: { username: target.username },
    ipAddress: ip,
  });

  revalidatePath("/admin/users");
  return { ok: true };
}
