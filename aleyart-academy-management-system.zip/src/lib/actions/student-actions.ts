"use server";

import { revalidatePath } from "next/cache";
import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  academicYears,
  classes,
  fileMetadata,
  studentAcademicHistory,
  students,
} from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/http";
import { validateStudentPhotoUpload, storeFile } from "@/lib/files";
import {
  buildFullName,
  classifyMovement,
  academicYearStartYear,
  generateQrToken,
  issueStudentCodes,
} from "@/lib/students";
import type { FormState } from "@/lib/actions/auth-actions";

function revalidateStudents() {
  revalidatePath("/students");
  revalidatePath("/dashboard");
}

/* ------------------------------------------------------------------ */
/* Shared field parsing                                                */
/* ------------------------------------------------------------------ */

interface StudentFields {
  firstName: string;
  middleName: string | null;
  lastName: string;
  gender: string;
  dateOfBirth: string | null;
  admissionNumber: string | null;
  classId: string;
  academicYearId: string;
  admissionDate: string | null;
  guardianName: string | null;
  guardianRelation: string | null;
  guardianPhone: string | null;
  contactPhone: string | null;
  address: string | null;
  notes: string | null;
}

function opt(v: FormDataEntryValue | null, max = 300): string | null {
  const s = String(v ?? "").trim().replace(/\s+/g, " ");
  if (!s) return null;
  return s.slice(0, max);
}

const ISO_DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const PHONE_RE = /^[0-9+()\-.\s]{5,40}$/;

function parseStudentForm(formData: FormData): { fields?: StudentFields; error?: string } {
  const firstName = String(formData.get("firstName") ?? "").trim().replace(/\s+/g, " ");
  const lastName = String(formData.get("lastName") ?? "").trim().replace(/\s+/g, " ");
  const middleName = opt(formData.get("middleName"), 80);
  const gender = String(formData.get("gender") ?? "").trim().toLowerCase();
  const dateOfBirth = String(formData.get("dateOfBirth") ?? "").trim() || null;
  const admissionNumber = opt(formData.get("admissionNumber"), 30);
  const classId = String(formData.get("classId") ?? "").trim();
  const academicYearId = String(formData.get("academicYearId") ?? "").trim();
  const admissionDate = String(formData.get("admissionDate") ?? "").trim() || null;
  const guardianName = opt(formData.get("guardianName"), 160);
  const guardianRelation = opt(formData.get("guardianRelation"), 60);
  const guardianPhone = opt(formData.get("guardianPhone"), 40);
  const contactPhone = opt(formData.get("contactPhone"), 40);
  const address = String(formData.get("address") ?? "").trim().slice(0, 500) || null;
  const notes = String(formData.get("notes") ?? "").trim().slice(0, 2000) || null;

  if (firstName.length < 2 || firstName.length > 80) return { error: "First name is required (2–80 chars)." };
  if (lastName.length < 2 || lastName.length > 80) return { error: "Last name is required (2–80 chars)." };
  if (!["male", "female", "other"].includes(gender)) return { error: "Please select a valid gender." };
  if (dateOfBirth && !ISO_DATE_RE.test(dateOfBirth)) return { error: "Date of birth must be a valid date." };
  if (admissionDate && !ISO_DATE_RE.test(admissionDate)) return { error: "Admission date must be a valid date." };
  if (!classId || !academicYearId) return { error: "Please choose the class and the admission academic year." };
  if (guardianPhone && !PHONE_RE.test(guardianPhone)) return { error: "Guardian phone contains invalid characters." };
  if (contactPhone && !PHONE_RE.test(contactPhone)) return { error: "Contact phone contains invalid characters." };

  return {
    fields: {
      firstName,
      middleName,
      lastName,
      gender,
      dateOfBirth,
      admissionNumber,
      classId,
      academicYearId,
      admissionDate,
      guardianName,
      guardianRelation,
      guardianPhone,
      contactPhone,
      address,
      notes,
    },
  };
}

async function validateClassAndYear(classId: string, academicYearId: string) {
  const [klass] = await db.select().from(classes).where(eq(classes.id, classId)).limit(1);
  if (!klass) return { error: "Selected class does not exist." } as const;
  if (!klass.isActive) return { error: `${klass.name} is inactive and cannot admit students.` } as const;
  const [year] = await db.select().from(academicYears).where(eq(academicYears.id, academicYearId)).limit(1);
  if (!year) return { error: "Selected academic year does not exist." } as const;
  if (year.isArchived) return { error: `Academic year ${year.name} is archived.` } as const;
  return { klass, year } as const;
}

/** Store a validated photo, returning file_metadata id. Throws on storage failure. */
async function persistPhoto(file: File, uploadedBy: string, purpose: string) {
  const validation = await validateStudentPhotoUpload(file);
  if (!validation.ok) return { error: validation.error } as const;
  const stored = await storeFile(validation.ext!, validation.buffer!);
  const [meta] = await db
    .insert(fileMetadata)
    .values({
      originalFilename: validation.originalFilename!,
      storedFilename: stored.storedFilename,
      storagePath: stored.storagePath,
      mimeType: file.type,
      sizeBytes: validation.buffer!.length,
      checksum: stored.checksum,
      purpose,
      uploadedBy,
    })
    .returning({ id: fileMetadata.id });
  return { meta } as const;
}

/* ------------------------------------------------------------------ */
/* Create student (with optional photo, history + QR in one transaction) */
/* ------------------------------------------------------------------ */

export async function createStudentAction(
  _prev: FormState | null,
  formData: FormData,
): Promise<FormState & { studentId?: string }> {
  const actor = await requirePermission("students.manage");
  const ip = await getClientIp();

  const parsed = parseStudentForm(formData);
  if (!parsed.fields) return { error: parsed.error };
  const f = parsed.fields;

  const check = await validateClassAndYear(f.classId, f.academicYearId);
  if ("error" in check) return { error: check.error };
  const yearStart = academicYearStartYear(check.year.name);
  if (!yearStart) return { error: "Selected academic year name is invalid." };

  if (f.admissionNumber) {
    const [dup] = await db
      .select({ id: students.id })
      .from(students)
      .where(eq(students.admissionNumber, f.admissionNumber))
      .limit(1);
    if (dup) return { error: `Admission number "${f.admissionNumber}" is already in use.` };
  }

  // Validate photo (if any) BEFORE touching the database
  const photoFile = formData.get("photo");
  const hasPhoto = photoFile instanceof File && photoFile.size > 0;
  let photoValidation: Awaited<ReturnType<typeof validateStudentPhotoUpload>> | null = null;
  if (hasPhoto) {
    photoValidation = await validateStudentPhotoUpload(photoFile as File);
    if (!photoValidation.ok) return { error: photoValidation.error };
  }

  const fullName = buildFullName(f.firstName, f.middleName, f.lastName);
  const qrToken = generateQrToken();

  let created: { id: string; studentCode: string };
  try {
    created = await db.transaction(async (tx) => {
      const codes = await issueStudentCodes(tx, yearStart);

      const [row] = await tx
        .insert(students)
        .values({
          studentCode: codes.studentCode,
          admissionNumber: f.admissionNumber ?? codes.admissionNumber,
          firstName: f.firstName,
          middleName: f.middleName,
          lastName: f.lastName,
          fullName,
          gender: f.gender,
          dateOfBirth: f.dateOfBirth,
          classId: f.classId,
          currentAcademicYearId: f.academicYearId,
          admissionDate: f.admissionDate,
          status: "active",
          guardianName: f.guardianName,
          guardianRelation: f.guardianRelation,
          guardianPhone: f.guardianPhone,
          contactPhone: f.contactPhone,
          address: f.address,
          notes: f.notes,
          qrToken,
          qrIssuedAt: new Date(),
          createdBy: actor.id,
        })
        .returning({ id: students.id, studentCode: students.studentCode });

      await tx.insert(studentAcademicHistory).values({
        studentId: row.id,
        academicYearId: f.academicYearId,
        classId: f.classId,
        action: "enrolled",
        note: `Admitted to ${check.klass.name} (${check.year.name})`,
        performedBy: actor.id,
      });
      return row;
    });
  } catch (error) {
    console.error("[students] create failed:", error);
    return { error: "Could not create the student record. Please try again." };
  }

  // Photo persistence after the core record exists
  if (photoValidation?.ok) {
    try {
      const stored = await storeFile(photoValidation.ext!, photoValidation.buffer!);
      const [meta] = await db
        .insert(fileMetadata)
        .values({
          originalFilename: photoValidation.originalFilename!,
          storedFilename: stored.storedFilename,
          storagePath: stored.storagePath,
          mimeType: (photoFile as File).type,
          sizeBytes: photoValidation.buffer!.length,
          checksum: stored.checksum,
          purpose: "student_photo",
          uploadedBy: actor.id,
        })
        .returning({ id: fileMetadata.id });
      await db.update(students).set({ photoFileId: meta.id }).where(eq(students.id, created.id));
    } catch (error) {
      console.error("[students] photo persist failed:", error);
      // Non-fatal: record exists without photo; can be added via edit.
    }
  }

  await logAudit({
    userId: actor.id,
    action: "student.created",
    entity: "student",
    entityId: created.id,
    details: {
      studentCode: created.studentCode,
      fullName,
      class: check.klass.name,
      academicYear: check.year.name,
      photo: Boolean(photoValidation?.ok),
    },
    ipAddress: ip,
  });

  revalidateStudents();
  return { ok: true, studentId: created.id };
}

/* ------------------------------------------------------------------ */
/* Update student bio-data (class/year changes go through promotion)   */
/* ------------------------------------------------------------------ */

export async function updateStudentAction(
  studentId: string,
  _prev: FormState | null,
  formData: FormData,
): Promise<FormState> {
  const actor = await requirePermission("students.manage");
  const ip = await getClientIp();

  const [existing] = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!existing) return { error: "Student not found." };

  // Reuse the same parser; classId/academicYearId are submitted but ignored here
  const parsed = parseStudentForm(formData);
  if (!parsed.fields) return { error: parsed.error };
  const f = parsed.fields;

  const targetAdmissionNumber = f.admissionNumber ?? "";
  if (targetAdmissionNumber) {
    const [dup] = await db
      .select({ id: students.id })
      .from(students)
      .where(and(eq(students.admissionNumber, targetAdmissionNumber), sql`${students.id} != ${studentId}`))
      .limit(1);
    if (dup) return { error: `Admission number "${targetAdmissionNumber}" is already in use.` };
  }

  const fullName = buildFullName(f.firstName, f.middleName, f.lastName);

  // Optional new photo
  const photoFile = formData.get("photo");
  const hasPhoto = photoFile instanceof File && (photoFile as File).size > 0;
  let photoMetaId: string | null = null;
  if (hasPhoto) {
    const result = await persistPhoto(photoFile as File, actor.id, "student_photo");
    if ("error" in result) return { error: result.error };
    photoMetaId = result.meta.id;
  }

  await db
    .update(students)
    .set({
      firstName: f.firstName,
      middleName: f.middleName,
      lastName: f.lastName,
      fullName,
      gender: f.gender,
      dateOfBirth: f.dateOfBirth,
      admissionNumber: f.admissionNumber ?? existing.admissionNumber,
      admissionDate: f.admissionDate,
      guardianName: f.guardianName,
      guardianRelation: f.guardianRelation,
      guardianPhone: f.guardianPhone,
      contactPhone: f.contactPhone,
      address: f.address,
      notes: f.notes,
      ...(photoMetaId ? { photoFileId: photoMetaId } : {}),
      updatedAt: new Date(),
    })
    .where(eq(students.id, studentId));

  await logAudit({
    userId: actor.id,
    action: "student.updated",
    entity: "student",
    entityId: studentId,
    details: {
      studentCode: existing.studentCode,
      changes: {
        fullName: existing.fullName !== fullName ? { from: existing.fullName, to: fullName } : undefined,
        gender: existing.gender !== f.gender ? { from: existing.gender, to: f.gender } : undefined,
        photo: photoMetaId ? "replaced" : undefined,
      },
    },
    ipAddress: ip,
  });
  if (photoMetaId) {
    await logAudit({
      userId: actor.id,
      action: "student.photo_changed",
      entity: "student",
      entityId: studentId,
      details: { studentCode: existing.studentCode, fileId: photoMetaId },
      ipAddress: ip,
    });
  }

  revalidateStudents();
  revalidatePath(`/students/${studentId}`);
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Archive / restore                                                   */
/* ------------------------------------------------------------------ */

export async function archiveStudentAction(studentId: string): Promise<FormState> {
  const actor = await requirePermission("students.manage");
  const ip = await getClientIp();
  const [student] = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!student) return { error: "Student not found." };
  if (student.status === "archived") return { error: "Student is already archived." };

  await db
    .update(students)
    .set({ status: "archived", archivedAt: new Date(), updatedAt: new Date() })
    .where(eq(students.id, studentId));

  await logAudit({
    userId: actor.id,
    action: "student.archived",
    entity: "student",
    entityId: studentId,
    details: { studentCode: student.studentCode, fullName: student.fullName },
    ipAddress: ip,
  });
  revalidateStudents();
  revalidatePath(`/students/${studentId}`);
  return { ok: true };
}

export async function restoreStudentAction(studentId: string): Promise<FormState> {
  const actor = await requirePermission("students.manage");
  const ip = await getClientIp();
  const [student] = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!student) return { error: "Student not found." };
  if (student.status !== "archived") return { error: "Only archived students can be restored." };

  await db
    .update(students)
    .set({ status: "active", archivedAt: null, updatedAt: new Date() })
    .where(eq(students.id, studentId));

  await logAudit({
    userId: actor.id,
    action: "student.restored",
    entity: "student",
    entityId: studentId,
    details: { studentCode: student.studentCode, fullName: student.fullName },
    ipAddress: ip,
  });
  revalidateStudents();
  revalidatePath(`/students/${studentId}`);
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Promotion — individual (transactional)                              */
/* ------------------------------------------------------------------ */

export async function promoteStudentAction(
  studentId: string,
  targetClassId: string,
  targetYearId: string,
  note: string | null,
): Promise<FormState> {
  const actor = await requirePermission("students.promote");
  const ip = await getClientIp();
  const result = await promoteOne(studentId, targetClassId, targetYearId, note, actor.id, ip);
  revalidateStudents();
  revalidatePath(`/students/${studentId}`);
  return result;
}

/** Core single-student promotion used by both individual and bulk flows. */
async function promoteOne(
  studentId: string,
  targetClassId: string,
  targetYearId: string,
  note: string | null,
  actorId: string,
  ip: string | null,
): Promise<FormState> {
  const [student] = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!student) return { error: "Student not found." };
  if (student.status === "archived") return { error: `${student.fullName} is archived — restore before promoting.` };
  if (student.status === "graduated") return { error: `${student.fullName} has graduated and cannot be promoted.` };

  const check = await validateClassAndYear(targetClassId, targetYearId);
  if ("error" in check) return { error: check.error };

  // Pre-compute movement label outside the transaction
  let currentSort: number | null = null;
  if (student.classId) {
    const [cur] = await db.select().from(classes).where(eq(classes.id, student.classId)).limit(1);
    currentSort = cur?.sortOrder ?? null;
  }
  const sameYear = student.currentAcademicYearId === targetYearId;
  const sameClass = student.classId === targetClassId;
  if (sameYear && sameClass) {
    return { error: `${student.fullName} is already in ${check.klass.name} for ${check.year.name}.` };
  }

  const action = classifyMovement(currentSort, check.klass.sortOrder, sameYear);

  try {
    await db.transaction(async (tx) => {
      if (sameYear) {
        // Mid-year class transfer: adjust the existing history row for this year
        const [existingHistory] = await tx
          .select()
          .from(studentAcademicHistory)
          .where(
            and(
              eq(studentAcademicHistory.studentId, studentId),
              eq(studentAcademicHistory.academicYearId, targetYearId),
            ),
          )
          .limit(1);
        if (existingHistory) {
          await tx
            .update(studentAcademicHistory)
            .set({ classId: targetClassId, action: "transferred", note: note ?? existingHistory.note })
            .where(eq(studentAcademicHistory.id, existingHistory.id));
        }
      } else {
        await tx.insert(studentAcademicHistory).values({
          studentId,
          academicYearId: targetYearId,
          classId: targetClassId,
          action,
          note: note?.trim() || null,
          performedBy: actorId,
        });
      }

      await tx
        .update(students)
        .set({
          classId: targetClassId,
          currentAcademicYearId: targetYearId,
          updatedAt: new Date(),
        })
        .where(eq(students.id, studentId));
    });
  } catch (error) {
    const message = (error as Error).message ?? "";
    if (message.includes("student_history_unique_year")) {
      return { error: `${student.fullName} already has an academic record in ${check.year.name}.` };
    }
    console.error("[students] promotion failed:", error);
    return { error: "Promotion failed. No changes were saved." };
  }

  await logAudit({
    userId: actorId,
    action: sameYear ? "student.transferred" : "student.promoted",
    entity: "student",
    entityId: studentId,
    details: {
      studentCode: student.studentCode,
      movement: action,
      to: `${check.klass.name} / ${check.year.name}`,
      permanentIdPreserved: student.studentCode,
      qrPreserved: true,
    },
    ipAddress: ip,
  });

  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Promotion — bulk                                                    */
/* ------------------------------------------------------------------ */

export interface BulkPromoteResult extends FormState {
  promoted?: Array<{ studentCode: string; fullName: string }>;
  failed?: Array<{ studentCode: string; fullName: string; reason: string }>;
}

export async function bulkPromoteStudentsAction(
  studentIds: string[],
  targetClassId: string,
  targetYearId: string,
  note: string | null,
): Promise<BulkPromoteResult> {
  const actor = await requirePermission("students.promote");
  const ip = await getClientIp();

  if (!Array.isArray(studentIds) || studentIds.length === 0) {
    return { error: "Select at least one student to promote." };
  }
  if (studentIds.length > 200) return { error: "Bulk promotion is limited to 200 students at a time." };

  const check = await validateClassAndYear(targetClassId, targetYearId);
  if ("error" in check) return { error: check.error };

  const promoted: BulkPromoteResult["promoted"] = [];
  const failed: BulkPromoteResult["failed"] = [];

  for (const id of studentIds) {
    const [before] = await db
      .select({ studentCode: students.studentCode, fullName: students.fullName })
      .from(students)
      .where(eq(students.id, id))
      .limit(1);
    const name = before?.fullName ?? "Unknown";
    const code = before?.studentCode ?? "—";

    const result = await promoteOne(id, targetClassId, targetYearId, note, actor.id, ip);
    if (result.ok) promoted!.push({ studentCode: code, fullName: name });
    else failed!.push({ studentCode: code, fullName: name, reason: result.error ?? "Unknown error" });
  }

  await logAudit({
    userId: actor.id,
    action: "student.bulk_promoted",
    entity: "student",
    details: {
      target: `${check.klass.name} / ${check.year.name}`,
      attempted: studentIds.length,
      succeeded: promoted!.length,
      failed: failed!.length,
    },
    ipAddress: ip,
  });

  revalidateStudents();
  return { ok: true, promoted, failed };
}

/* ------------------------------------------------------------------ */
/* Directory data helpers used by pages                                */
/* ------------------------------------------------------------------ */

export async function logIdCardGenerated(studentIds: string[], batch: boolean) {
  const actor = await requirePermission("students.view");
  const ip = await getClientIp();
  const rows = await db
    .select({ studentCode: students.studentCode })
    .from(students)
    .where(inArray(students.id, studentIds.slice(0, 200)));
  await logAudit({
    userId: actor.id,
    action: "student.id_card_generated",
    entity: "student",
    details: { count: rows.length, codes: rows.map((r) => r.studentCode), batch },
    ipAddress: ip,
  });
}
