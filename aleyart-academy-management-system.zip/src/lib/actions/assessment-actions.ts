"use server";

import { revalidatePath } from "next/cache";
import { and, asc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import {
  academicYears,
  assessments,
  classes,
  classSubjects,
  students,
  subjects,
  terminalReports,
  terms,
} from "@/db/schema";
import { requirePermission, userHasPermission, isSuperAdmin } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/http";
import {
  validateScores,
  loadBands,
  bandForScore,
  loadTeacherScope,
  scopeAllowsSubject,
  scopeAllowsClass,
} from "@/lib/grading";
import type { FormState } from "@/lib/actions/auth-actions";

export interface SaveScoreRow {
  studentId: string;
  classScore: string | number;
  examScore: string | number;
  remarks?: string | null;
}

export interface SaveScoresResult extends FormState {
  saved?: number;
  rejected?: Array<{ studentId: string; reason: string }>;
}

/**
 * Save a full subject mark-sheet for one class/term/subject.
 * Server-validates every score (0–50 / 0–50), recomputes totals and grades
 * from the database grading scheme, enforces teacher scoping, and refuses to
 * touch results whose terminal report is already published or locked.
 */
export async function saveSubjectScoresAction(
  params: {
    classId: string;
    termId: string;
    subjectId: string;
  },
  rows: SaveScoreRow[],
): Promise<SaveScoresResult> {
  const actor = await requirePermission("assessments.manage");
  const ip = await getClientIp();
  const { classId, termId, subjectId } = params;

  // --- Server-side teacher scoping -------------------------------
  const unrestricted =
    isSuperAdmin(actor) || userHasPermission(actor, "reports.publish");
  const scope = await loadTeacherScope(actor.id, unrestricted);
  if (!scopeAllowsSubject(scope, classId, subjectId)) {
    return { error: "You are not assigned to this class/subject." };
  }

  // --- Validate structural references -----------------------------
  const [term] = await db.select().from(terms).where(eq(terms.id, termId)).limit(1);
  if (!term) return { error: "Term not found." };
  const [klass] = await db.select().from(classes).where(eq(classes.id, classId)).limit(1);
  if (!klass) return { error: "Class not found." };
  const [subject] = await db.select().from(subjects).where(eq(subjects.id, subjectId)).limit(1);
  if (!subject) return { error: "Subject not found." };
  if (!subject.isActive) return { error: `${subject.name} is inactive.` };

  const [link] = await db
    .select({ id: classSubjects.id })
    .from(classSubjects)
    .where(and(eq(classSubjects.classId, classId), eq(classSubjects.subjectId, subjectId)))
    .limit(1);
  if (!link) return { error: `${subject.name} is not assigned to ${klass.name}.` };

  const [year] = await db
    .select()
    .from(academicYears)
    .where(eq(academicYears.id, term.academicYearId))
    .limit(1);
  if (!year) return { error: "Academic year not found." };
  if (year.isArchived) return { error: `Academic year ${year.name} is archived.` };

  const bands = await loadBands("competency");

  const studentIds = rows.map((r) => r.studentId);
  if (studentIds.length === 0) return { error: "No scores submitted." };

  const studentRows = await db
    .select({ id: students.id, studentCode: students.studentCode, fullName: students.fullName })
    .from(students)
    .where(inArray(students.id, studentIds));
  const studentById = new Map(studentRows.map((s) => [s.id, s]));

  // Reports already published/locked for this year+term block edits
  const lockedReports = await db
    .select({ studentId: terminalReports.studentId, status: terminalReports.status })
    .from(terminalReports)
    .where(
      and(
        eq(terminalReports.termId, termId),
        eq(terminalReports.academicYearId, term.academicYearId),
        inArray(terminalReports.studentId, studentIds),
      ),
    );
  const blocked = new Map(
    lockedReports.filter((r) => r.status !== "draft").map((r) => [r.studentId, r.status]),
  );

  const rejected: Array<{ studentId: string; reason: string }> = [];
  let saved = 0;

  for (const row of rows) {
    const student = studentById.get(row.studentId);
    if (!student) {
      rejected.push({ studentId: row.studentId, reason: "Student not found." });
      continue;
    }
    if (blocked.has(row.studentId)) {
      rejected.push({
        studentId: row.studentId,
        reason: `Report already ${blocked.get(row.studentId)} — unlock it before editing scores.`,
      });
      continue;
    }

    const validation = validateScores(row.classScore, row.examScore);
    if (!validation.ok) {
      rejected.push({ studentId: row.studentId, reason: validation.error! });
      continue;
    }

    const band = bandForScore(bands, validation.total!);
    const remarks = (row.remarks ?? "").trim().slice(0, 200) || band?.remark || null;

    await db
      .insert(assessments)
      .values({
        studentId: row.studentId,
        studentCode: student.studentCode,
        academicYearId: term.academicYearId,
        termId,
        classId, // HISTORICAL class at assessment time
        subjectId,
        classScore: String(validation.classScore),
        examScore: String(validation.examScore),
        total: String(validation.total),
        grade: band?.grade ?? "B",
        gradeLabel: band?.label ?? "Beginning",
        remarks,
        teacherId: actor.id,
        status: "submitted",
      })
      .onConflictDoUpdate({
        target: [assessments.studentId, assessments.termId, assessments.subjectId],
        set: {
          classScore: String(validation.classScore),
          examScore: String(validation.examScore),
          total: String(validation.total),
          grade: band?.grade ?? "B",
          gradeLabel: band?.label ?? "Beginning",
          remarks,
          teacherId: actor.id,
          classId,
          academicYearId: term.academicYearId,
          status: "submitted",
          updatedAt: new Date(),
        },
      });
    saved += 1;
  }

  await logAudit({
    userId: actor.id,
    action: "assessment.scores_saved",
    entity: "assessment",
    entityId: `${klass.name}/${subject.name}/${term.name}`,
    details: {
      class: klass.name,
      subject: subject.name,
      term: term.name,
      academicYear: year.name,
      saved,
      rejected: rejected.length,
    },
    ipAddress: ip,
  });

  revalidatePath("/assessments");
  revalidatePath("/reports");
  return { ok: true, saved, rejected };
}

/** Options for the mark-sheet pickers, already narrowed by teacher scope. */
export async function getMarkSheetOptions() {
  const actor = await requirePermission("assessments.view");
  const unrestricted = isSuperAdmin(actor) || userHasPermission(actor, "reports.publish");
  const scope = await loadTeacherScope(actor.id, unrestricted);

  const classRows = await db.select().from(classes).orderBy(asc(classes.sortOrder));
  const allowedClasses = classRows.filter((c) => scopeAllowsClass(scope, c.id));

  return allowedClasses.map((c) => ({ id: c.id, name: c.name }));
}
