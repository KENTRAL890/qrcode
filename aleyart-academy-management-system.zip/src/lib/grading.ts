import { and, asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { aggregateRules, gradeBands, gradingSchemes, teacherAssignments } from "@/db/schema";

export const MAX_CLASS_SCORE = 50;
export const MAX_EXAM_SCORE = 50;
export const MAX_TOTAL = 100;

/* ------------------------------------------------------------------ */
/* Default (seeded) configuration                                      */
/* ------------------------------------------------------------------ */

export const DEFAULT_COMPETENCY_BANDS = [
  { minScore: 80, maxScore: 100, grade: "A", label: "Advance", remark: "Excellent" },
  { minScore: 68, maxScore: 79, grade: "P", label: "Proficient", remark: "Very good" },
  { minScore: 54, maxScore: 67, grade: "AP", label: "Approaching Proficiency", remark: "Good" },
  { minScore: 40, maxScore: 53, grade: "D", label: "Developing", remark: "Fair — needs support" },
  { minScore: 0, maxScore: 39, grade: "B", label: "Beginning", remark: "Needs serious improvement" },
] as const;

export const DEFAULT_AGGREGATE_BANDS = [
  { minScore: 90, maxScore: 100, points: 1 },
  { minScore: 80, maxScore: 89, points: 2 },
  { minScore: 70, maxScore: 79, points: 3 },
  { minScore: 60, maxScore: 69, points: 4 },
  { minScore: 50, maxScore: 59, points: 5 },
  { minScore: 40, maxScore: 49, points: 6 },
  { minScore: 30, maxScore: 39, points: 7 },
  { minScore: 20, maxScore: 29, points: 8 },
  { minScore: 0, maxScore: 19, points: 9 },
] as const;

export const AGGREGATE_CORE_SUBJECTS = [
  "English Language",
  "Mathematics",
  "Integrated Science",
  "Social Studies",
];

export const AGGREGATE_ELECTIVE_SUBJECTS = [
  "Computing",
  "Creative Arts",
  "RME",
  "French",
  "GA/Twi",
  "Career Technology",
];

/* ------------------------------------------------------------------ */
/* Score validation                                                    */
/* ------------------------------------------------------------------ */

export interface ScoreValidation {
  ok: boolean;
  error?: string;
  classScore?: number;
  examScore?: number;
  total?: number;
}

/** Server-side validation of a single subject result. */
export function validateScores(rawClass: unknown, rawExam: unknown): ScoreValidation {
  const classScore = Number(rawClass);
  const examScore = Number(rawExam);

  if (!Number.isFinite(classScore) || !Number.isFinite(examScore)) {
    return { ok: false, error: "Class score and exam score must be numbers." };
  }
  if (classScore < 0 || classScore > MAX_CLASS_SCORE) {
    return { ok: false, error: `Class score must be between 0 and ${MAX_CLASS_SCORE}.` };
  }
  if (examScore < 0 || examScore > MAX_EXAM_SCORE) {
    return { ok: false, error: `Exam score must be between 0 and ${MAX_EXAM_SCORE}.` };
  }

  const round2 = (n: number) => Math.round(n * 100) / 100;
  const cs = round2(classScore);
  const es = round2(examScore);
  const total = round2(cs + es);

  if (total > MAX_TOTAL) {
    return { ok: false, error: `Total cannot exceed ${MAX_TOTAL}.` };
  }
  return { ok: true, classScore: cs, examScore: es, total };
}

/* ------------------------------------------------------------------ */
/* Grading scheme resolution                                           */
/* ------------------------------------------------------------------ */

export interface ResolvedBand {
  minScore: number;
  maxScore: number;
  grade: string;
  label: string;
  points: number | null;
  remark: string | null;
}

/** Load the active default scheme bands of a kind, ordered high→low. */
export async function loadBands(kind: "competency" | "aggregate"): Promise<ResolvedBand[]> {
  const rows = await db
    .select({
      minScore: gradeBands.minScore,
      maxScore: gradeBands.maxScore,
      grade: gradeBands.grade,
      label: gradeBands.label,
      points: gradeBands.points,
      remark: gradeBands.remark,
    })
    .from(gradeBands)
    .innerJoin(gradingSchemes, eq(gradingSchemes.id, gradeBands.schemeId))
    .where(
      and(
        eq(gradingSchemes.kind, kind),
        eq(gradingSchemes.isDefault, true),
        eq(gradingSchemes.isActive, true),
      ),
    )
    .orderBy(asc(gradeBands.sortOrder));

  if (rows.length > 0) return rows;

  // Hard fallback keeps grading functional before seeding completes
  return kind === "competency"
    ? DEFAULT_COMPETENCY_BANDS.map((b) => ({ ...b, points: null, remark: b.remark }))
    : DEFAULT_AGGREGATE_BANDS.map((b) => ({
        ...b,
        grade: String(b.points),
        label: `Aggregate ${b.points}`,
        remark: null,
      }));
}

export function bandForScore(bands: ResolvedBand[], total: number): ResolvedBand | null {
  return bands.find((b) => total >= b.minScore && total <= b.maxScore) ?? null;
}

/** Reject overlapping / gapped / inverted ranges when configuring a scheme. */
export function validateBandRanges(
  bands: Array<{ minScore: number; maxScore: number; grade: string }>,
): { ok: boolean; error?: string } {
  if (bands.length === 0) return { ok: false, error: "At least one grade band is required." };

  for (const b of bands) {
    if (!Number.isInteger(b.minScore) || !Number.isInteger(b.maxScore)) {
      return { ok: false, error: "Band boundaries must be whole numbers." };
    }
    if (b.minScore < 0 || b.maxScore > MAX_TOTAL) {
      return { ok: false, error: `Bands must stay within 0–${MAX_TOTAL}.` };
    }
    if (b.minScore > b.maxScore) {
      return { ok: false, error: `Band "${b.grade}" has a minimum greater than its maximum.` };
    }
    if (!b.grade.trim()) return { ok: false, error: "Every band needs a grade symbol." };
  }

  const sorted = [...bands].sort((a, b) => a.minScore - b.minScore);
  for (let i = 1; i < sorted.length; i++) {
    const prev = sorted[i - 1];
    const cur = sorted[i];
    if (cur.minScore <= prev.maxScore) {
      return {
        ok: false,
        error: `Grade ranges overlap: ${prev.grade} (${prev.minScore}–${prev.maxScore}) and ${cur.grade} (${cur.minScore}–${cur.maxScore}).`,
      };
    }
    if (cur.minScore !== prev.maxScore + 1) {
      return {
        ok: false,
        error: `Gap between ${prev.grade} (ends ${prev.maxScore}) and ${cur.grade} (starts ${cur.minScore}). Ranges must be contiguous.`,
      };
    }
  }
  if (sorted[0].minScore !== 0 || sorted[sorted.length - 1].maxScore !== MAX_TOTAL) {
    return { ok: false, error: `Bands must cover the full 0–${MAX_TOTAL} range.` };
  }
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Positions / ranking                                                 */
/* ------------------------------------------------------------------ */

/**
 * Competition ranking (1, 2, 2, 4) by default; dense ranking (1, 2, 2, 3)
 * when configured. Input must be descending by score.
 */
export function rankScores(
  scores: number[],
  method: "competition" | "dense" = "competition",
): number[] {
  const indexed = scores.map((score, index) => ({ score, index }));
  indexed.sort((a, b) => b.score - a.score);

  const positions = new Array<number>(scores.length).fill(0);
  let currentRank = 0;
  let lastScore: number | null = null;

  indexed.forEach((item, i) => {
    if (lastScore === null || item.score !== lastScore) {
      currentRank = method === "dense" ? currentRank + 1 : i + 1;
      lastScore = item.score;
    }
    positions[item.index] = currentRank;
  });
  return positions;
}

export function ordinal(n: number): string {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return n + (s[(v - 20) % 10] ?? s[v] ?? s[0]);
}

/* ------------------------------------------------------------------ */
/* Aggregate computation (Basic 7–9)                                   */
/* ------------------------------------------------------------------ */

export interface AggregateConfig {
  coreSubjectNames: string[];
  electiveSubjectNames: string[];
  electiveCount: number;
  rankingMethod: "competition" | "dense";
}

export async function loadAggregateConfig(levelGroup: string): Promise<AggregateConfig> {
  const [rule] = await db
    .select()
    .from(aggregateRules)
    .where(and(eq(aggregateRules.levelGroup, levelGroup), eq(aggregateRules.isActive, true)))
    .limit(1);

  if (!rule) {
    return {
      coreSubjectNames: AGGREGATE_CORE_SUBJECTS,
      electiveSubjectNames: AGGREGATE_ELECTIVE_SUBJECTS,
      electiveCount: 2,
      rankingMethod: "competition",
    };
  }
  return {
    coreSubjectNames: (rule.coreSubjectNames as string[]) ?? AGGREGATE_CORE_SUBJECTS,
    electiveSubjectNames: (rule.electiveSubjectNames as string[]) ?? AGGREGATE_ELECTIVE_SUBJECTS,
    electiveCount: rule.electiveCount,
    rankingMethod: (rule.rankingMethod as "competition" | "dense") ?? "competition",
  };
}

export interface AggregateInput {
  subjectName: string;
  total: number;
}

export interface AggregateResult {
  aggregate: number | null;
  breakdown: Array<{ subjectName: string; total: number; points: number; role: "core" | "elective" }>;
  note?: string;
}

/**
 * Aggregate = sum of grade points for all core subjects plus the N best
 * eligible electives (default 4 core + 2 electives). Lower is better.
 */
export function computeAggregate(
  results: AggregateInput[],
  config: AggregateConfig,
  aggregateBands: ResolvedBand[],
): AggregateResult {
  const pointsFor = (total: number): number => {
    const band = bandForScore(aggregateBands, total);
    return band?.points ?? 9;
  };

  const byName = new Map(results.map((r) => [r.subjectName, r.total]));

  const core = config.coreSubjectNames
    .filter((name) => byName.has(name))
    .map((name) => ({
      subjectName: name,
      total: byName.get(name)!,
      points: pointsFor(byName.get(name)!),
      role: "core" as const,
    }));

  if (core.length < config.coreSubjectNames.length) {
    return {
      aggregate: null,
      breakdown: core,
      note: "Aggregate unavailable — results missing for one or more core subjects.",
    };
  }

  const electives = config.electiveSubjectNames
    .filter((name) => byName.has(name))
    .map((name) => ({
      subjectName: name,
      total: byName.get(name)!,
      points: pointsFor(byName.get(name)!),
      role: "elective" as const,
    }))
    .sort((a, b) => a.points - b.points || b.total - a.total)
    .slice(0, config.electiveCount);

  if (electives.length < config.electiveCount) {
    return {
      aggregate: null,
      breakdown: [...core, ...electives],
      note: `Aggregate unavailable — at least ${config.electiveCount} elective results are required.`,
    };
  }

  const breakdown = [...core, ...electives];
  const aggregate = breakdown.reduce((sum, b) => sum + b.points, 0);
  return { aggregate, breakdown };
}

/* ------------------------------------------------------------------ */
/* Teacher scoping (server-enforced)                                   */
/* ------------------------------------------------------------------ */

export interface TeacherScope {
  /** true when the user is not restricted (admin/super admin). */
  unrestricted: boolean;
  classIds: Set<string>;
  /** classId -> allowed subject ids; empty set means "all subjects". */
  subjectsByClass: Map<string, Set<string>>;
}

export async function loadTeacherScope(
  userId: string,
  unrestricted: boolean,
): Promise<TeacherScope> {
  if (unrestricted) {
    return { unrestricted: true, classIds: new Set(), subjectsByClass: new Map() };
  }
  const rows = await db
    .select()
    .from(teacherAssignments)
    .where(eq(teacherAssignments.teacherId, userId));

  const classIds = new Set<string>();
  const subjectsByClass = new Map<string, Set<string>>();
  for (const row of rows) {
    classIds.add(row.classId);
    if (!subjectsByClass.has(row.classId)) subjectsByClass.set(row.classId, new Set());
    if (row.subjectId && !row.isClassTeacher) {
      subjectsByClass.get(row.classId)!.add(row.subjectId);
    } else {
      // class teacher: clear restriction for this class
      subjectsByClass.set(row.classId, new Set());
    }
  }
  return { unrestricted: false, classIds, subjectsByClass };
}

export function scopeAllowsClass(scope: TeacherScope, classId: string): boolean {
  return scope.unrestricted || scope.classIds.has(classId);
}

export function scopeAllowsSubject(
  scope: TeacherScope,
  classId: string,
  subjectId: string,
): boolean {
  if (scope.unrestricted) return true;
  if (!scope.classIds.has(classId)) return false;
  const subjects = scope.subjectsByClass.get(classId);
  // empty set = class teacher = all subjects allowed
  return !subjects || subjects.size === 0 || subjects.has(subjectId);
}

/** Drizzle condition helper to narrow queries by teacher scope. */
export function scopeClassFilter(scope: TeacherScope) {
  if (scope.unrestricted) return undefined;
  return Array.from(scope.classIds);
}
