import crypto from "node:crypto";
import { cookies } from "next/headers";
import { db } from "@/db";
import { sessions } from "@/db/schema";
import { and, eq, gt, lt, ne } from "drizzle-orm";

export const SESSION_COOKIE = "aa_session";
/** Absolute session lifetime. */
const SESSION_TTL_MS = 12 * 60 * 60 * 1000; // 12 hours
/** Idle timeout — a session untouched for longer than this is expired. */
const IDLE_TTL_MS = 60 * 60 * 1000; // 60 minutes
/** Throttle last-seen writes. */
const TOUCH_THROTTLE_MS = 60 * 1000;

function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

export function generateToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

export interface SessionRecord {
  sessionId: string;
  userId: string;
  expiresAt: Date;
}

export async function createSession(
  userId: string,
  meta?: { ipAddress?: string | null; userAgent?: string | null },
): Promise<{ token: string; expiresAt: Date }> {
  const token = generateToken();
  const expiresAt = new Date(Date.now() + SESSION_TTL_MS);
  const now = new Date();

  await db.insert(sessions).values({
    tokenHash: hashToken(token),
    userId,
    ipAddress: meta?.ipAddress ?? null,
    userAgent: meta?.userAgent ? meta.userAgent.slice(0, 300) : null,
    createdAt: now,
    lastSeenAt: now,
    expiresAt,
  });

  return { token, expiresAt };
}

export async function setSessionCookie(token: string, expiresAt: Date, secure: boolean) {
  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure,
    sameSite: "lax",
    path: "/",
    expires: expiresAt,
  });
}

export async function clearSessionCookie() {
  const jar = await cookies();
  jar.set(SESSION_COOKIE, "", {
    httpOnly: true,
    secure: false,
    sameSite: "lax",
    path: "/",
    expires: new Date(0),
  });
}

/**
 * Resolve the session cookie to a live session row.
 * Enforces absolute expiry + idle timeout, and slides lastSeenAt forward.
 */
export async function getValidSession(): Promise<SessionRecord | null> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;

  const now = new Date();
  const [row] = await db
    .select({
      id: sessions.id,
      userId: sessions.userId,
      expiresAt: sessions.expiresAt,
      lastSeenAt: sessions.lastSeenAt,
    })
    .from(sessions)
    .where(and(eq(sessions.tokenHash, hashToken(token)), gt(sessions.expiresAt, now)))
    .limit(1);

  if (!row) return null;

  // Idle timeout
  if (now.getTime() - row.lastSeenAt.getTime() > IDLE_TTL_MS) {
    await db.delete(sessions).where(eq(sessions.id, row.id));
    return null;
  }

  // Throttled touch (sliding inactivity window)
  if (now.getTime() - row.lastSeenAt.getTime() > TOUCH_THROTTLE_MS) {
    db.update(sessions)
      .set({ lastSeenAt: now })
      .where(eq(sessions.id, row.id))
      .execute()
      .catch(() => {});
  }

  return { sessionId: row.id, userId: row.userId, expiresAt: row.expiresAt };
}

export async function destroySession(sessionId: string) {
  await db.delete(sessions).where(eq(sessions.id, sessionId));
}

/** Invalidate every session of a user (e.g. after password reset). */
export async function destroyAllUserSessions(userId: string, exceptSessionId?: string) {
  await db
    .delete(sessions)
    .where(
      exceptSessionId
        ? and(eq(sessions.userId, userId), ne(sessions.id, exceptSessionId))
        : eq(sessions.userId, userId),
    );
}

/** Remove expired sessions (lazy hygiene). */
export async function pruneExpiredSessions() {
  await db.delete(sessions).where(lt(sessions.expiresAt, new Date()));
}
