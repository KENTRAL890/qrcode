import { headers } from "next/headers";

/** Best-effort client IP from proxy headers (server-side only). */
export async function getClientIp(): Promise<string | null> {
  const h = await headers();
  const fwd = h.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0]!.trim().slice(0, 64);
  return h.get("x-real-ip")?.slice(0, 64) ?? null;
}

/** Detect whether the external request is HTTPS (behind proxy). */
export async function isSecureRequest(): Promise<boolean> {
  const h = await headers();
  const proto = h.get("x-forwarded-proto");
  if (proto) return proto === "https";
  return process.env.NODE_ENV === "production" && process.env.INSECURE_DEV_COOKIES !== "1";
}
