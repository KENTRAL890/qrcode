import { NextResponse, type NextRequest } from "next/server";

const PROTECTED_PREFIXES = [
  "/dashboard",
  "/settings",
  "/admin",
  "/academic",
  "/change-password",
];

/**
 * Fast cookie-presence gate at the edge. The authoritative authentication +
 * authorization checks always happen server-side in the (app) layout and in
 * every server action — a forged cookie alone grants nothing.
 */
export function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const isProtected = PROTECTED_PREFIXES.some(
    (p) => pathname === p || pathname.startsWith(`${p}/`),
  );
  if (!isProtected) return NextResponse.next();

  const token = request.cookies.get("aa_session")?.value;
  if (!token || !/^[a-f0-9]{64}$/.test(token)) {
    const loginUrl = new URL("/login", request.url);
    if (pathname !== "/change-password") {
      loginUrl.searchParams.set("next", pathname);
    }
    return NextResponse.redirect(loginUrl);
  }
  return NextResponse.next();
}

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/settings/:path*",
    "/admin/:path*",
    "/academic/:path*",
    "/change-password",
  ],
};
