import type { CSSProperties } from "react";
import { initials } from "@/lib/format";

export interface IdCardStudent {
  fullName: string;
  studentCode: string;
  admissionNumber: string;
  className: string | null;
  yearName: string | null;
  photoUrl: string | null;
  gender: string;
}

export interface IdCardBranding {
  schoolName: string;
  motto: string;
  crestUrl: string | null;
  telephone: string;
  location: string;
}

const CARD: CSSProperties = {
  width: "85.6mm",
  height: "54mm",
};

/**
 * Physical student ID card — 85.6mm × 54mm landscape (CR80).
 * ALL school identity (name, motto, crest, contacts) comes from the central
 * School Settings record via props. Nothing is hard-coded: rebranding the
 * school instantly restyles every newly printed card.
 */
export function IdCardFront({
  student,
  brand,
}: {
  student: IdCardStudent;
  brand: IdCardBranding;
}) {
  return (
    <div
      className="id-card-face relative overflow-hidden bg-white text-neutral-900"
      style={{ ...CARD, borderRadius: "3mm", fontFamily: "var(--font-sans)" }}
    >
      {/* Brand band */}
      <div
        className="absolute inset-x-0 top-0"
        style={{
          height: "12.5mm",
          background: "linear-gradient(100deg,#f97316 0%,#f8730f 45%,#ec4899 100%)",
        }}
      >
        <div className="flex items-center" style={{ height: "100%", padding: "0 3mm", gap: "2.2mm" }}>
          <div
            className="flex items-center justify-center overflow-hidden bg-white"
            style={{ width: "9.5mm", height: "9.5mm", borderRadius: "1.8mm", padding: "0.7mm" }}
          >
            {brand.crestUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={brand.crestUrl} alt="" style={{ maxWidth: "100%", maxHeight: "100%", objectFit: "contain" }} />
            ) : (
              <span style={{ fontSize: "7pt", fontWeight: 800, color: "#f97316" }}>
                {brand.schoolName.charAt(0)}
              </span>
            )}
          </div>
          <div style={{ minWidth: 0, flex: 1, lineHeight: 1.05 }}>
            <p
              style={{
                fontSize: "8pt",
                fontWeight: 800,
                color: "#fff",
                letterSpacing: "0.04em",
                textTransform: "uppercase",
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
                fontFamily: "var(--font-display)",
              }}
            >
              {brand.schoolName}
            </p>
            {brand.motto ? (
              <p style={{ fontSize: "4.8pt", fontStyle: "italic", color: "rgba(255,255,255,0.92)", marginTop: "0.6mm" }}>
                &ldquo;{brand.motto}&rdquo;
              </p>
            ) : null}
          </div>
          <p style={{ fontSize: "4pt", fontWeight: 700, color: "rgba(255,255,255,0.85)", letterSpacing: "0.2em", textAlign: "right" }}>
            STUDENT
            <br />
            ID CARD
          </p>
        </div>
        <div className="absolute inset-x-0 bottom-0" style={{ height: "0.7mm", background: "#1c1917" }} />
      </div>

      {/* Photo */}
      <div
        className="absolute overflow-hidden"
        style={{
          left: "4mm",
          top: "16mm",
          width: "21.5mm",
          height: "27mm",
          borderRadius: "2mm",
          border: "0.45mm solid #f97316",
          background: "linear-gradient(135deg,#ffedd5,#fce7f3)",
        }}
      >
        {student.photoUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={student.photoUrl} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        ) : (
          <div className="flex h-full w-full items-center justify-center">
            <span style={{ fontSize: "14pt", fontWeight: 800, color: "#f97316", fontFamily: "var(--font-display)" }}>
              {initials(student.fullName)}
            </span>
          </div>
        )}
      </div>

      {/* Facts */}
      <div className="absolute" style={{ left: "29mm", right: "3.5mm", top: "15.8mm" }}>
        <p style={{ fontSize: "4.2pt", fontWeight: 700, letterSpacing: "0.14em", color: "#a8a29e", textTransform: "uppercase" }}>
          Student Name
        </p>
        <p
          style={{
            fontSize: "9.2pt",
            fontWeight: 800,
            color: "#1c1917",
            lineHeight: 1.08,
            marginTop: "0.4mm",
            fontFamily: "var(--font-display)",
            display: "-webkit-box",
            WebkitLineClamp: 2,
            WebkitBoxOrient: "vertical",
            overflow: "hidden",
          }}
        >
          {student.fullName}
        </p>

        <div style={{ marginTop: "2.2mm", borderTop: "0.2mm solid #f5f5f4", paddingTop: "1.6mm" }}>
          <p style={{ fontSize: "4.2pt", fontWeight: 700, letterSpacing: "0.14em", color: "#a8a29e", textTransform: "uppercase" }}>
            Student ID (Permanent)
          </p>
          <p style={{ fontSize: "7.2pt", fontWeight: 800, color: "#ea580c", fontFamily: "monospace", marginTop: "0.3mm" }}>
            {student.studentCode}
          </p>
        </div>

        <div className="flex" style={{ gap: "4mm", marginTop: "1.8mm" }}>
          <div>
            <p style={{ fontSize: "4.2pt", fontWeight: 700, letterSpacing: "0.14em", color: "#a8a29e", textTransform: "uppercase" }}>
              Class
            </p>
            <p style={{ fontSize: "6.6pt", fontWeight: 700, color: "#1c1917", marginTop: "0.3mm" }}>
              {student.className ?? "—"}
            </p>
          </div>
          <div>
            <p style={{ fontSize: "4.2pt", fontWeight: 700, letterSpacing: "0.14em", color: "#a8a29e", textTransform: "uppercase" }}>
              Academic Year
            </p>
            <p style={{ fontSize: "6.6pt", fontWeight: 700, color: "#1c1917", fontFamily: "monospace", marginTop: "0.3mm" }}>
              {student.yearName ?? "—"}
            </p>
          </div>
          <div>
            <p style={{ fontSize: "4.2pt", fontWeight: 700, letterSpacing: "0.14em", color: "#a8a29e", textTransform: "uppercase" }}>
              Gender
            </p>
            <p style={{ fontSize: "6.6pt", fontWeight: 700, color: "#1c1917", textTransform: "capitalize", marginTop: "0.3mm" }}>
              {student.gender}
            </p>
          </div>
        </div>

        <p style={{ fontSize: "4pt", color: "#a8a29e", marginTop: "2mm", fontFamily: "monospace" }}>
          {student.admissionNumber}
        </p>
      </div>

      {/* Footer strip */}
      <div
        className="absolute inset-x-0 bottom-0 flex items-center justify-between"
        style={{ height: "4mm", background: "#1c1917", padding: "0 4mm" }}
      >
        <p style={{ fontSize: "3.6pt", fontWeight: 700, letterSpacing: "0.24em", color: "#fdba74", textTransform: "uppercase" }}>
          Official Student Identification
        </p>
        <p style={{ fontSize: "3.6pt", color: "rgba(255,255,255,0.6)", letterSpacing: "0.08em" }}>
          VALID BASIC 1 – 9
        </p>
      </div>
    </div>
  );
}

export function IdCardBack({
  student,
  brand,
  qrMarkup,
}: {
  student: IdCardStudent;
  brand: IdCardBranding;
  qrMarkup: string | null;
}) {
  return (
    <div
      className="id-card-face relative overflow-hidden bg-white text-neutral-900"
      style={{ ...CARD, borderRadius: "3mm", fontFamily: "var(--font-sans)" }}
    >
      {/* Top strip */}
      <div className="absolute inset-x-0 top-0" style={{ height: "1.8mm", background: "linear-gradient(90deg,#f97316,#ec4899)" }} />

      {/* QR block */}
      <div className="absolute flex flex-col items-center" style={{ left: "4mm", top: "6mm", width: "30mm" }}>
        <div
          className="flex items-center justify-center border border-neutral-200 bg-white"
          style={{ width: "27mm", height: "27mm", borderRadius: "1.5mm", padding: "1.2mm" }}
        >
          {qrMarkup ? (
            <div
              style={{ width: "100%", height: "100%", lineHeight: 0 }}
              // SVG is generated server-side by the `qrcode` library from the
              // opaque verification URL — safe to inline.
              dangerouslySetInnerHTML={{ __html: qrMarkup }}
            />
          ) : (
            <span style={{ fontSize: "4.5pt", color: "#a8a29e", textAlign: "center" }}>QR not issued</span>
          )}
        </div>
        <p style={{ fontSize: "4.6pt", fontWeight: 800, letterSpacing: "0.12em", color: "#ea580c", textTransform: "uppercase", marginTop: "1.4mm", textAlign: "center" }}>
          Scan to verify student
        </p>
        <p style={{ fontSize: "5.4pt", fontWeight: 700, color: "#1c1917", fontFamily: "monospace", marginTop: "0.5mm" }}>
          {student.studentCode}
        </p>
        <p style={{ fontSize: "3.6pt", color: "#a8a29e", marginTop: "0.4mm" }}>
          Same QR for Basic 1 – 9
        </p>
      </div>

      {/* School block */}
      <div className="absolute" style={{ left: "38.5mm", right: "4mm", top: "6mm" }}>
        <div className="flex items-center" style={{ gap: "1.8mm" }}>
          {brand.crestUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={brand.crestUrl} alt="" style={{ height: "7mm", width: "7mm", objectFit: "contain" }} />
          ) : null}
          <p style={{ fontSize: "6.8pt", fontWeight: 800, color: "#1c1917", lineHeight: 1.1, fontFamily: "var(--font-display)", textTransform: "uppercase", letterSpacing: "0.02em" }}>
            {brand.schoolName}
          </p>
        </div>
        {brand.motto ? (
          <p style={{ fontSize: "4.6pt", fontStyle: "italic", color: "#ea580c", marginTop: "1mm" }}>
            &ldquo;{brand.motto}&rdquo;
          </p>
        ) : null}

        <div style={{ marginTop: "2.6mm", borderTop: "0.2mm solid #f5f5f4", paddingTop: "1.8mm" }}>
          <p style={{ fontSize: "4.2pt", fontWeight: 700, letterSpacing: "0.14em", color: "#a8a29e", textTransform: "uppercase" }}>
            This card belongs to
          </p>
          <p style={{ fontSize: "6.4pt", fontWeight: 700, color: "#1c1917", marginTop: "0.4mm" }}>{student.fullName}</p>
          <p style={{ fontSize: "4.6pt", color: "#57534e", marginTop: "0.7mm" }}>
            {student.className ?? "—"} · {student.yearName ?? "—"}
          </p>
        </div>

        <div style={{ marginTop: "2.4mm" }}>
          <p style={{ fontSize: "4.2pt", fontWeight: 700, letterSpacing: "0.14em", color: "#a8a29e", textTransform: "uppercase" }}>
            If found — please return
          </p>
          <p style={{ fontSize: "4.8pt", color: "#44403c", lineHeight: 1.45, marginTop: "0.5mm" }}>
            {brand.schoolName}
            {brand.location ? `, ${brand.location}` : ""}.
            {brand.telephone ? (
              <>
                {" "}
                Tel: <span style={{ fontWeight: 700, color: "#ea580c" }}>{brand.telephone}</span>
              </>
            ) : null}
          </p>
        </div>

        {/* Signature */}
        <div className="absolute" style={{ right: "0.5mm", bottom: "-46mm", textAlign: "center" }}>
          <p style={{ fontSize: "4pt", color: "#78716c" }}>____________________________</p>
          <p style={{ fontSize: "4pt", fontWeight: 700, color: "#57534e", letterSpacing: "0.1em", marginTop: "0.3mm" }}>HEAD OF SCHOOL</p>
        </div>
      </div>

      {/* Bottom strip */}
      <div
        className="absolute inset-x-0 bottom-0 flex items-center justify-center"
        style={{ height: "2.2mm", background: "#1c1917" }}
      >
        <p style={{ fontSize: "3.2pt", letterSpacing: "0.22em", color: "rgba(253,186,116,0.9)", textTransform: "uppercase", fontWeight: 700 }}>
          {brand.schoolName} · Official card
        </p>
      </div>
    </div>
  );
}
