"use client";

import { useEffect, useState, type ComponentType, type ReactNode } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  CalendarRange,
  GraduationCap,
  BookOpen,
  Users as UsersIcon,
  ScrollText,
  Settings2,
  Menu,
  LogOut,
  CalendarDays,
  X,
  ContactRound,
  ArrowUpRight,
  ClipboardList,
  FileText,
  Banknote,
  TrendingUp,
  Wallet,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { initials } from "@/lib/format";
import { logoutAction } from "@/lib/actions/auth-actions";

export interface ShellNavItem {
  href: string;
  label: string;
  icon:
    | "dashboard"
    | "years"
    | "classes"
    | "subjects"
    | "users"
    | "audit"
    | "settings"
    | "students"
    | "promote"
    | "assessments"
    | "reports"
    | "payments"
    | "finance"
    | "wallet";
}

const ICONS: Record<ShellNavItem["icon"], ComponentType<{ className?: string }>> = {
  dashboard: LayoutDashboard,
  years: CalendarRange,
  classes: GraduationCap,
  subjects: BookOpen,
  users: UsersIcon,
  audit: ScrollText,
  settings: Settings2,
  students: ContactRound,
  promote: ArrowUpRight,
  assessments: ClipboardList,
  reports: FileText,
  payments: Banknote,
  finance: TrendingUp,
  wallet: Wallet,
};

const SECTION_ORDER = ["Overview", "Students", "Academics", "Finance", "Administration", "School"] as const;

export interface ShellProps {
  brandName: string;
  brandMotto: string;
  crestUrl: string | null;
  userName: string;
  userRoleLabel: string;
  currentYear: string | null;
  sections: Array<{ title: string; items: ShellNavItem[] }>;
  children: ReactNode;
}

function CrestImg({ crestUrl, brandName, size }: { crestUrl: string | null; brandName: string; size: number }) {
  if (!crestUrl) {
    return (
      <div
        className="flex shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-orange-500 to-pink-500 font-display font-bold text-white"
        style={{ width: size, height: size, fontSize: size * 0.45 }}
      >
        {brandName.trim().charAt(0).toUpperCase() || "A"}
      </div>
    );
  }
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={crestUrl}
      alt={`${brandName} crest`}
      className="shrink-0 object-contain"
      style={{ width: size, height: size }}
    />
  );
}

function isActive(pathname: string, href: string) {
  if (href === "/dashboard") return pathname === "/dashboard" || pathname === "/";
  return pathname === href || pathname.startsWith(`${href}/`);
}

function SidebarContent({
  props,
  pathname,
  onNavigate,
}: {
  props: ShellProps;
  pathname: string;
  onNavigate?: () => void;
}) {
  const sectionByTitle = new Map(props.sections.map((s) => [s.title, s.items]));
  return (
    <div className="flex h-full flex-col">
      {/* Brand block — always reflects central settings */}
      <div className="flex items-center gap-3 px-5 pb-5 pt-6">
        <div className="rounded-xl bg-white p-1 shadow-sm shadow-black/20">
          <CrestImg crestUrl={props.crestUrl} brandName={props.brandName} size={34} />
        </div>
        <div className="min-w-0">
          <p className="truncate font-display text-[13.5px] font-bold leading-tight tracking-tight text-white">
            {props.brandName}
          </p>
          <p className="truncate text-[10.5px] italic text-orange-300/90">
            {props.brandMotto}
          </p>
        </div>
      </div>

      <div className="mx-5 border-t border-white/10" />

      {/* Navigation */}
      <nav className="flex-1 space-y-5 overflow-y-auto px-3 py-5">
        {SECTION_ORDER.map((section) => {
          const items = sectionByTitle.get(section) ?? [];
          if (items.length === 0) return null;
          return (
            <div key={section}>
              <p className="mb-1.5 px-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-neutral-500">
                {section}
              </p>
              <ul className="space-y-0.5">
                {items.map((item) => {
                  const Icon = ICONS[item.icon];
                  const active = isActive(pathname, item.href);
                  return (
                    <li key={item.href}>
                      <Link
                        href={item.href}
                        onClick={onNavigate}
                        aria-current={active ? "page" : undefined}
                        className={cn(
                          "group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13.5px] font-medium transition-all duration-200",
                          active
                            ? "bg-gradient-to-r from-orange-500 to-orange-500/80 text-white shadow-[0_8px_20px_-8px_rgba(249,115,22,0.8)]"
                            : "text-neutral-400 hover:bg-white/[0.06] hover:text-white",
                        )}
                      >
                        <Icon
                          className={cn(
                            "size-[18px] shrink-0 transition-transform duration-200 group-hover:scale-110",
                            active ? "text-white" : "text-neutral-500 group-hover:text-orange-300",
                          )}
                        />
                        <span className="truncate">{item.label}</span>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          );
        })}
      </nav>

      {/* User footer */}
      <div className="border-t border-white/10 p-4">
        <div className="flex items-center gap-3 rounded-2xl bg-white/[0.05] p-3">
          <div className="flex size-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-orange-500 to-pink-500 text-xs font-bold text-white">
            {initials(props.userName)}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-[13px] font-semibold text-white">{props.userName}</p>
            <p className="truncate text-[11px] text-orange-300/80">{props.userRoleLabel}</p>
          </div>
          <form action={logoutAction}>
            <button
              type="submit"
              title="Sign out"
              className="rounded-xl p-2 text-neutral-400 transition-colors hover:bg-white/10 hover:text-white"
            >
              <LogOut className="size-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export function AppShell(props: ShellProps) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <div className="app-shell-root min-h-dvh lg:pl-[17.5rem]">
      {/* Desktop sidebar */}
      <aside className="no-print fixed inset-y-0 left-0 z-30 hidden w-[17.5rem] bg-neutral-950 lg:block">
        <SidebarContent props={props} pathname={pathname} />
      </aside>

      {/* Mobile sidebar */}
      <div
        className={cn(
          "no-print fixed inset-0 z-40 transition-opacity duration-300 lg:hidden",
          open ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-0",
        )}
      >
        <div
          className="absolute inset-0 bg-neutral-950/50 backdrop-blur-[2px]"
          onClick={() => setOpen(false)}
        />
        <aside
          className={cn(
            "absolute inset-y-0 left-0 w-[18rem] max-w-[85vw] bg-neutral-950 shadow-2xl transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]",
            open ? "translate-x-0" : "-translate-x-full",
          )}
        >
          <button
            onClick={() => setOpen(false)}
            aria-label="Close menu"
            className="absolute right-3 top-4 z-10 rounded-lg p-1.5 text-neutral-400 hover:bg-white/10 hover:text-white"
          >
            <X className="size-5" />
          </button>
          <SidebarContent props={props} pathname={pathname} onNavigate={() => setOpen(false)} />
        </aside>
      </div>

      {/* Top bar */}
      <header className="no-print sticky top-0 z-20 border-b border-neutral-200/70 bg-paper/85 backdrop-blur-md">
        <div className="flex h-16 items-center gap-3 px-4 sm:px-6 lg:px-10">
          <button
            onClick={() => setOpen(true)}
            aria-label="Open menu"
            className="rounded-xl border border-neutral-200 bg-white p-2 text-neutral-600 shadow-sm transition-colors hover:border-orange-300 hover:text-orange-600 lg:hidden"
          >
            <Menu className="size-5" />
          </button>

          {/* Mobile/mini brand */}
          <div className="flex min-w-0 items-center gap-2.5 lg:hidden">
            <CrestImg crestUrl={props.crestUrl} brandName={props.brandName} size={30} />
            <div className="min-w-0">
              <p className="truncate font-display text-[13px] font-bold leading-tight">
                {props.brandName}
              </p>
              <p className="truncate text-[10px] italic text-orange-600">{props.brandMotto}</p>
            </div>
          </div>

          <div className="ml-auto flex items-center gap-2.5 sm:gap-3.5">
            {props.currentYear ? (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-orange-200 bg-orange-50 px-3 py-1.5 text-xs font-semibold text-orange-700">
                <CalendarDays className="size-3.5" aria-hidden />
                <span className="hidden xs:inline sm:inline">Academic Year&nbsp;</span>
                {props.currentYear}
              </span>
            ) : null}

            <div className="hidden h-6 w-px bg-neutral-200 sm:block" />

            <div className="hidden items-center gap-2.5 sm:flex">
              <div className="flex size-9 items-center justify-center rounded-full bg-gradient-to-br from-orange-500 to-pink-500 text-xs font-bold text-white shadow-sm">
                {initials(props.userName)}
              </div>
              <div className="hidden leading-tight min-[400px]:block">
                <p className="text-[13px] font-semibold text-neutral-800">{props.userName}</p>
                <p className="text-[11px] text-neutral-400">{props.userRoleLabel}</p>
              </div>
            </div>

            <form action={logoutAction}>
              <button
                type="submit"
                title="Sign out"
                className="rounded-xl border border-neutral-200 bg-white p-2 text-neutral-500 shadow-sm transition-all hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <LogOut className="size-4" />
              </button>
            </form>
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-[1500px] px-4 py-6 sm:px-6 lg:px-10 lg:py-8">
        {props.children}
      </main>
    </div>
  );
}
