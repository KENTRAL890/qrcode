import { Globe, Info, History } from "lucide-react";

export { Globe, Info };

export function UpdatedAtIconNote({
  updatedAt,
  updatedBy,
}: {
  updatedAt: string | null;
  updatedBy: string | null;
}) {
  return (
    <div className="flex items-start gap-3">
      <span className="rounded-xl bg-white/80 p-2 text-orange-500 shadow-sm">
        <History className="size-4" aria-hidden />
      </span>
      <div className="min-w-0 text-xs leading-relaxed text-neutral-600">
        <p className="font-semibold text-neutral-800">Branding history</p>
        <p className="mt-1">
          {updatedAt ? (
            <>Last updated {updatedAt}{updatedBy ? <> by <span className="font-semibold">{updatedBy}</span></> : null}.</>
          ) : (
            "No updates recorded yet."
          )}
        </p>
        <p className="mt-1 text-neutral-500">
          Every branding change is written to the audit log with the previous and new values.
        </p>
      </div>
    </div>
  );
}
