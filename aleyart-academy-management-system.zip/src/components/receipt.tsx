import { formatMoney, formatDateTime } from "@/lib/format";

export interface ReceiptBranding {
  schoolName: string;
  motto: string;
  location: string;
  poBox: string;
  telephone: string;
  crestUrl: string | null;
}

export interface ReceiptData {
  receiptNumber: string;
  studentName: string;
  studentCode: string;
  className: string | null;
  academicYear: string;
  term: string;
  amount: string;
  method: string;
  paidAt: Date | string;
  receivedByName: string | null;
  reference: string | null;
  notes: string | null;
  status: string;
  printCount: number;
  balance: { totalCharged: string; totalPaid: string; outstanding: string } | null;
}

/**
 * A5-ish payment receipt (148mm × 105mm landscape) for official printing.
 * School identity comes from `brand`, which is either the live central
 * School Settings (for a fresh issue) or the snapshot frozen on the payment
 * row. Nothing about the school is hard-coded here.
 */
export function ReceiptDoc({
  brand,
  data,
  isReprint,
}: {
  brand: ReceiptBranding;
  data: ReceiptData;
  isReprint: boolean;
}) {
  const reversed = data.status === "reversed";

  return (
    <article
      className="receipt-page relative overflow-hidden bg-white text-neutral-900"
      style={{
        width: "148mm",
        minHeight: "105mm",
        padding: "7mm 8mm",
        fontFamily: "var(--font-sans)",
      }}
    >
      {reversed ? (
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 flex items-center justify-center"
          style={{ zIndex: 0 }}
        >
          <span
            style={{
              fontSize: "36pt",
              fontWeight: 800,
              color: "rgba(225,29,72,0.12)",
              transform: "rotate(-24deg)",
              letterSpacing: "0.12em",
            }}
          >
            REVERSED
          </span>
        </div>
      ) : null}

      <div style={{ position: "relative", zIndex: 1 }}>
        {/* Header */}
        <header
          style={{
            display: "flex",
            alignItems: "center",
            gap: "3.5mm",
            borderBottom: "0.8mm solid #f97316",
            paddingBottom: "3mm",
          }}
        >
          {brand.crestUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={brand.crestUrl}
              alt=""
              style={{ width: "15mm", height: "15mm", objectFit: "contain", flexShrink: 0 }}
            />
          ) : (
            <div
              style={{
                width: "15mm",
                height: "15mm",
                borderRadius: "2mm",
                background: "linear-gradient(135deg,#f97316,#ec4899)",
                color: "#fff",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "11pt",
                fontWeight: 800,
                flexShrink: 0,
              }}
            >
              {brand.schoolName.charAt(0)}
            </div>
          )}
          <div style={{ flex: 1, minWidth: 0 }}>
            <h1
              style={{
                fontSize: "12.5pt",
                fontWeight: 800,
                textTransform: "uppercase",
                letterSpacing: "0.02em",
                lineHeight: 1.1,
                fontFamily: "var(--font-display)",
              }}
            >
              {brand.schoolName}
            </h1>
            {brand.motto ? (
              <p style={{ fontSize: "7pt", fontStyle: "italic", color: "#ea580c", marginTop: "0.6mm" }}>
                &ldquo;{brand.motto}&rdquo;
              </p>
            ) : null}
            <p style={{ fontSize: "6pt", color: "#57534e", marginTop: "0.8mm" }}>
              {[brand.location, brand.poBox, brand.telephone ? `Tel: ${brand.telephone}` : null]
                .filter(Boolean)
                .join(" · ")}
            </p>
          </div>
          <div style={{ textAlign: "right", flexShrink: 0 }}>
            <p
              style={{
                fontSize: "6pt",
                fontWeight: 800,
                letterSpacing: "0.16em",
                textTransform: "uppercase",
                color: "#a8a29e",
              }}
            >
              Payment Receipt
            </p>
            <p
              style={{
                fontSize: "9.5pt",
                fontWeight: 800,
                fontFamily: "monospace",
                color: "#ea580c",
                marginTop: "0.8mm",
              }}
            >
              {data.receiptNumber}
            </p>
            {isReprint ? (
              <p style={{ fontSize: "5.5pt", color: "#78716c", marginTop: "0.5mm" }}>
                REPRINT #{data.printCount} · same receipt number
              </p>
            ) : null}
          </div>
        </header>

        {/* Student + payment details */}
        <section
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: "2mm",
            marginTop: "3.5mm",
          }}
        >
          {[
            ["Student", data.studentName],
            ["Student ID", data.studentCode],
            ["Class", data.className ?? "—"],
            ["Academic Year", data.academicYear],
            ["Term", data.term],
            ["Date", formatDateTime(data.paidAt)],
          ].map(([label, value]) => (
            <div key={label} style={{ borderBottom: "0.2mm solid #e7e5e4", paddingBottom: "1.2mm" }}>
              <p
                style={{
                  fontSize: "5.4pt",
                  fontWeight: 700,
                  letterSpacing: "0.1em",
                  textTransform: "uppercase",
                  color: "#a8a29e",
                }}
              >
                {label}
              </p>
              <p
                style={{
                  fontSize: "7.6pt",
                  fontWeight: 700,
                  marginTop: "0.5mm",
                  fontFamily: label === "Student ID" ? "monospace" : undefined,
                  color: label === "Student ID" ? "#ea580c" : "#1c1917",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                }}
              >
                {value}
              </p>
            </div>
          ))}
        </section>

        {/* Amount block */}
        <section
          style={{
            marginTop: "4mm",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: "4mm",
            background: "#fff7ed",
            border: "0.3mm solid #fed7aa",
            borderRadius: "2mm",
            padding: "3mm 4mm",
          }}
        >
          <div>
            <p
              style={{
                fontSize: "5.6pt",
                fontWeight: 800,
                letterSpacing: "0.14em",
                textTransform: "uppercase",
                color: "#9a3412",
              }}
            >
              Amount Received
            </p>
            <p style={{ fontSize: "17pt", fontWeight: 800, color: "#1c1917", lineHeight: 1.1 }}>
              {formatMoney(data.amount)}
            </p>
          </div>
          <div style={{ textAlign: "right" }}>
            <p style={{ fontSize: "6pt", color: "#78716c" }}>
              Method: <b style={{ textTransform: "capitalize", color: "#1c1917" }}>{data.method}</b>
            </p>
            {data.reference ? (
              <p style={{ fontSize: "6pt", color: "#78716c", marginTop: "0.6mm" }}>
                Ref: <b style={{ color: "#1c1917" }}>{data.reference}</b>
              </p>
            ) : null}
            <p style={{ fontSize: "6pt", color: "#78716c", marginTop: "0.6mm" }}>
              Received by: <b style={{ color: "#1c1917" }}>{data.receivedByName ?? "—"}</b>
            </p>
          </div>
        </section>

        {/* Balance */}
        {data.balance ? (
          <section
            style={{
              marginTop: "3mm",
              display: "grid",
              gridTemplateColumns: "repeat(3, 1fr)",
              gap: "2mm",
            }}
          >
            {[
              ["Total Charged", data.balance.totalCharged],
              ["Total Paid", data.balance.totalPaid],
              ["Outstanding", data.balance.outstanding],
            ].map(([label, value], i) => (
              <div
                key={label}
                style={{
                  border: "0.25mm solid #e7e5e4",
                  borderRadius: "1.5mm",
                  padding: "1.8mm 2.2mm",
                  textAlign: "center",
                  background: i === 2 ? "#fef2f2" : "#fff",
                }}
              >
                <p
                  style={{
                    fontSize: "5.2pt",
                    fontWeight: 700,
                    letterSpacing: "0.1em",
                    textTransform: "uppercase",
                    color: "#a8a29e",
                  }}
                >
                  {label}
                </p>
                <p
                  style={{
                    fontSize: "8.4pt",
                    fontWeight: 800,
                    marginTop: "0.5mm",
                    color: i === 2 ? "#be123c" : "#1c1917",
                  }}
                >
                  {formatMoney(value)}
                </p>
              </div>
            ))}
          </section>
        ) : null}

        {data.notes ? (
          <p style={{ fontSize: "6pt", color: "#57534e", marginTop: "2.5mm" }}>
            <b>Note:</b> {data.notes}
          </p>
        ) : null}

        {/* Footer */}
        <footer
          style={{
            marginTop: "5mm",
            display: "flex",
            alignItems: "flex-end",
            justifyContent: "space-between",
            gap: "6mm",
          }}
        >
          <p style={{ fontSize: "5.4pt", color: "#a8a29e", maxWidth: "70mm", lineHeight: 1.4 }}>
            This receipt is computer generated and remains valid with its permanent number{" "}
            <b style={{ color: "#78716c" }}>{data.receiptNumber}</b>. Reprints never change the
            receipt number. Please retain for your records.
          </p>
          <div style={{ textAlign: "center", minWidth: "40mm" }}>
            <div style={{ borderTop: "0.3mm solid #78716c", paddingTop: "1mm" }}>
              <p
                style={{
                  fontSize: "5.6pt",
                  fontWeight: 700,
                  letterSpacing: "0.1em",
                  textTransform: "uppercase",
                  color: "#57534e",
                }}
              >
                Cashier / Accountant
              </p>
            </div>
          </div>
        </footer>
      </div>
    </article>
  );
}
