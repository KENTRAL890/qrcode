import { initials, formatDate } from "@/lib/format";
import { ordinal } from "@/lib/grading";

export interface ReportDocBranding {
  schoolName: string;
  motto: string;
  location: string;
  poBox: string;
  telephone: string;
  crestUrl: string | null;
}

export interface ReportDocStudent {
  fullName: string;
  studentCode: string;
  admissionNumber: string;
  gender: string;
  photoUrl: string | null;
}

export interface ReportDocAcademic {
  className: string;
  academicYear: string;
  term: string;
  classSize: number | null;
}

export interface ReportDocResult {
  subject: string;
  classScore: number;
  examScore: number;
  total: number;
  grade: string;
  gradeLabel: string | null;
  remarks: string | null;
  position: number | null;
}

export interface ReportDocProps {
  brand: ReportDocBranding;
  student: ReportDocStudent;
  academic: ReportDocAcademic;
  results: ReportDocResult[];
  totals: {
    totalScore: number;
    averageScore: number;
    overallPosition: number | null;
    aggregate: number | null;
  };
  remarks: { teacher: string | null; headteacher: string | null };
  gradeKey: Array<{ grade: string; label: string; minScore: number; maxScore: number }>;
  status: "draft" | "published" | "locked";
  isSnapshot: boolean;
  publishedAt?: Date | string | null;
}

/**
 * A4 terminal report (210mm × 297mm).
 * Every school identity value arrives via `brand` — either live central
 * settings (drafts) or the frozen publication snapshot (published/locked).
 * Nothing about the school is hard-coded here.
 */
export function TerminalReportDoc({
  brand,
  student,
  academic,
  results,
  totals,
  remarks,
  gradeKey,
  status,
  isSnapshot,
  publishedAt,
}: ReportDocProps) {
  return (
    <article
      className="report-page relative bg-white text-neutral-900"
      style={{
        width: "210mm",
        minHeight: "297mm",
        padding: "12mm 12mm 10mm",
        fontFamily: "var(--font-sans)",
      }}
    >
      {status !== "published" && status !== "locked" ? (
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 flex items-center justify-center"
          style={{ zIndex: 0 }}
        >
          <span
            style={{
              fontSize: "60pt",
              fontWeight: 800,
              color: "rgba(249,115,22,0.07)",
              transform: "rotate(-28deg)",
              letterSpacing: "0.1em",
            }}
          >
            DRAFT
          </span>
        </div>
      ) : null}

      <div style={{ position: "relative", zIndex: 1 }}>
        {/* ---------------- Header ---------------- */}
        <header
          style={{
            display: "flex",
            alignItems: "center",
            gap: "5mm",
            borderBottom: "1.2mm solid #f97316",
            paddingBottom: "4mm",
          }}
        >
          {brand.crestUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={brand.crestUrl}
              alt=""
              style={{ width: "22mm", height: "22mm", objectFit: "contain", flexShrink: 0 }}
            />
          ) : (
            <div
              style={{
                width: "22mm",
                height: "22mm",
                borderRadius: "3mm",
                background: "linear-gradient(135deg,#f97316,#ec4899)",
                color: "#fff",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "16pt",
                fontWeight: 800,
                flexShrink: 0,
              }}
            >
              {brand.schoolName.charAt(0)}
            </div>
          )}

          <div style={{ flex: 1, minWidth: 0, textAlign: "center" }}>
            <h1
              style={{
                fontSize: "17pt",
                fontWeight: 800,
                letterSpacing: "0.03em",
                textTransform: "uppercase",
                lineHeight: 1.1,
                fontFamily: "var(--font-display)",
              }}
            >
              {brand.schoolName}
            </h1>
            {brand.motto ? (
              <p style={{ fontSize: "9pt", fontStyle: "italic", color: "#ea580c", marginTop: "1mm" }}>
                &ldquo;{brand.motto}&rdquo;
              </p>
            ) : null}
            <p style={{ fontSize: "7.5pt", color: "#57534e", marginTop: "1.2mm" }}>
              {[brand.location, brand.poBox, brand.telephone ? `Tel: ${brand.telephone}` : null]
                .filter(Boolean)
                .join(" · ")}
            </p>
          </div>

          <div style={{ width: "22mm", flexShrink: 0, textAlign: "right" }}>
            {student.photoUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={student.photoUrl}
                alt=""
                style={{
                  width: "22mm",
                  height: "26mm",
                  objectFit: "cover",
                  border: "0.4mm solid #f97316",
                  borderRadius: "1.5mm",
                }}
              />
            ) : (
              <div
                style={{
                  width: "22mm",
                  height: "26mm",
                  border: "0.4mm dashed #d6d3d1",
                  borderRadius: "1.5mm",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "11pt",
                  fontWeight: 700,
                  color: "#a8a29e",
                }}
              >
                {initials(student.fullName)}
              </div>
            )}
          </div>
        </header>

        <p
          style={{
            textAlign: "center",
            fontSize: "10.5pt",
            fontWeight: 800,
            letterSpacing: "0.22em",
            textTransform: "uppercase",
            background: "#1c1917",
            color: "#fff",
            padding: "1.8mm",
            marginTop: "4mm",
          }}
        >
          Terminal Report
        </p>

        {/* ---------------- Student bar ---------------- */}
        <section
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(4, 1fr)",
            gap: "2mm",
            marginTop: "4mm",
          }}
        >
          {[
            ["Student Name", student.fullName],
            ["Student ID", student.studentCode],
            ["Class", academic.className],
            ["Gender", student.gender],
            ["Academic Year", academic.academicYear],
            ["Term", academic.term],
            ["Admission No.", student.admissionNumber],
            ["Class Size", academic.classSize ? String(academic.classSize) : "—"],
          ].map(([label, value]) => (
            <div
              key={label}
              style={{ border: "0.25mm solid #e7e5e4", borderRadius: "1.5mm", padding: "1.8mm 2.2mm" }}
            >
              <p
                style={{
                  fontSize: "5.6pt",
                  fontWeight: 700,
                  letterSpacing: "0.1em",
                  textTransform: "uppercase",
                  color: "#a8a29e",
                }}
              >
                {label}
              </p>
              <p
                style={{
                  fontSize: "8.4pt",
                  fontWeight: 700,
                  marginTop: "0.6mm",
                  textTransform: label === "Gender" ? "capitalize" : "none",
                  fontFamily: label === "Student ID" ? "monospace" : undefined,
                  color: label === "Student ID" ? "#ea580c" : "#1c1917",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                }}
              >
                {value}
              </p>
            </div>
          ))}
        </section>

        {/* ---------------- Results table ---------------- */}
        <table
          style={{
            width: "100%",
            borderCollapse: "collapse",
            marginTop: "5mm",
            fontSize: "8.4pt",
          }}
        >
          <thead>
            <tr style={{ background: "#fff7ed" }}>
              {[
                ["Subject", "left", "auto"],
                ["Class (50)", "center", "16mm"],
                ["Exam (50)", "center", "16mm"],
                ["Total (100)", "center", "17mm"],
                ["Grade", "center", "13mm"],
                ["Position", "center", "15mm"],
                ["Remarks", "left", "38mm"],
              ].map(([label, align, width]) => (
                <th
                  key={label}
                  style={{
                    border: "0.25mm solid #d6d3d1",
                    padding: "1.8mm 2mm",
                    textAlign: align as "left" | "center",
                    width: width as string,
                    fontSize: "7pt",
                    fontWeight: 800,
                    letterSpacing: "0.06em",
                    textTransform: "uppercase",
                    color: "#9a3412",
                  }}
                >
                  {label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {results.map((r, i) => (
              <tr key={r.subject} style={{ background: i % 2 ? "#fafaf9" : "#fff" }}>
                <td style={{ border: "0.25mm solid #e7e5e4", padding: "1.6mm 2mm", fontWeight: 600 }}>
                  {r.subject}
                </td>
                <td style={{ border: "0.25mm solid #e7e5e4", padding: "1.6mm 2mm", textAlign: "center" }}>
                  {r.classScore.toFixed(1)}
                </td>
                <td style={{ border: "0.25mm solid #e7e5e4", padding: "1.6mm 2mm", textAlign: "center" }}>
                  {r.examScore.toFixed(1)}
                </td>
                <td
                  style={{
                    border: "0.25mm solid #e7e5e4",
                    padding: "1.6mm 2mm",
                    textAlign: "center",
                    fontWeight: 800,
                  }}
                >
                  {r.total.toFixed(1)}
                </td>
                <td
                  style={{
                    border: "0.25mm solid #e7e5e4",
                    padding: "1.6mm 2mm",
                    textAlign: "center",
                    fontWeight: 800,
                    color: "#ea580c",
                  }}
                >
                  {r.grade}
                </td>
                <td style={{ border: "0.25mm solid #e7e5e4", padding: "1.6mm 2mm", textAlign: "center" }}>
                  {r.position ? ordinal(r.position) : "—"}
                </td>
                <td
                  style={{
                    border: "0.25mm solid #e7e5e4",
                    padding: "1.6mm 2mm",
                    fontSize: "7.6pt",
                    color: "#57534e",
                  }}
                >
                  {r.remarks ?? r.gradeLabel ?? "—"}
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr style={{ background: "#1c1917", color: "#fff" }}>
              <td style={{ padding: "2mm", fontWeight: 800, fontSize: "8pt" }}>TOTAL</td>
              <td colSpan={2} />
              <td style={{ padding: "2mm", textAlign: "center", fontWeight: 800 }}>
                {totals.totalScore.toFixed(1)}
              </td>
              <td colSpan={3} style={{ padding: "2mm", fontSize: "7.6pt" }}>
                Average: <b>{totals.averageScore.toFixed(2)}</b>
              </td>
            </tr>
          </tfoot>
        </table>

        {/* ---------------- Summary ---------------- */}
        <section
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: "3mm",
            marginTop: "4mm",
          }}
        >
          {[
            ["Overall Position", totals.overallPosition ? ordinal(totals.overallPosition) : "—"],
            ["Average Score", `${totals.averageScore.toFixed(2)}%`],
            ["Aggregate", totals.aggregate !== null ? String(totals.aggregate) : "N/A"],
          ].map(([label, value]) => (
            <div
              key={label}
              style={{
                border: "0.3mm solid #fed7aa",
                background: "#fff7ed",
                borderRadius: "2mm",
                padding: "2.5mm",
                textAlign: "center",
              }}
            >
              <p
                style={{
                  fontSize: "6pt",
                  fontWeight: 700,
                  letterSpacing: "0.12em",
                  textTransform: "uppercase",
                  color: "#9a3412",
                }}
              >
                {label}
              </p>
              <p style={{ fontSize: "13pt", fontWeight: 800, color: "#1c1917", marginTop: "0.8mm" }}>
                {value}
              </p>
            </div>
          ))}
        </section>

        {/* ---------------- Grade key ---------------- */}
        <section style={{ marginTop: "4mm" }}>
          <p
            style={{
              fontSize: "6.4pt",
              fontWeight: 800,
              letterSpacing: "0.12em",
              textTransform: "uppercase",
              color: "#a8a29e",
              marginBottom: "1.2mm",
            }}
          >
            Grading key
          </p>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "1.5mm" }}>
            {gradeKey.map((g) => (
              <span
                key={g.grade}
                style={{
                  border: "0.25mm solid #e7e5e4",
                  borderRadius: "1.2mm",
                  padding: "1mm 2mm",
                  fontSize: "6.8pt",
                  color: "#57534e",
                }}
              >
                <b style={{ color: "#ea580c" }}>{g.grade}</b> {g.minScore}–{g.maxScore} · {g.label}
              </span>
            ))}
          </div>
        </section>

        {/* ---------------- Remarks ---------------- */}
        <section style={{ marginTop: "5mm", display: "grid", gap: "3mm" }}>
          {[
            ["Class Teacher's Remarks", remarks.teacher],
            ["Headteacher's Remarks", remarks.headteacher],
          ].map(([label, text]) => (
            <div
              key={label as string}
              style={{ border: "0.25mm solid #e7e5e4", borderRadius: "2mm", padding: "2.5mm 3mm" }}
            >
              <p
                style={{
                  fontSize: "6.4pt",
                  fontWeight: 800,
                  letterSpacing: "0.1em",
                  textTransform: "uppercase",
                  color: "#a8a29e",
                }}
              >
                {label}
              </p>
              <p style={{ fontSize: "8.4pt", color: "#1c1917", marginTop: "1.2mm", minHeight: "7mm" }}>
                {text || "—"}
              </p>
            </div>
          ))}
        </section>

        {/* ---------------- Signatures / footer ---------------- */}
        <footer style={{ marginTop: "7mm" }}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: "8mm" }}>
            {["Class Teacher", "Headteacher"].map((role) => (
              <div key={role} style={{ flex: 1, textAlign: "center" }}>
                <div style={{ borderTop: "0.3mm solid #78716c", paddingTop: "1.2mm" }}>
                  <p
                    style={{
                      fontSize: "6.8pt",
                      fontWeight: 700,
                      letterSpacing: "0.1em",
                      textTransform: "uppercase",
                      color: "#57534e",
                    }}
                  >
                    {role}&apos;s Signature
                  </p>
                </div>
              </div>
            ))}
          </div>

          <p
            style={{
              marginTop: "5mm",
              textAlign: "center",
              fontSize: "6pt",
              color: "#a8a29e",
              borderTop: "0.25mm solid #e7e5e4",
              paddingTop: "2mm",
            }}
          >
            {isSnapshot
              ? `Historical document — branding and results frozen at publication${publishedAt ? ` on ${formatDate(publishedAt)}` : ""}.`
              : "Live preview — reflects current school settings and recorded results."}{" "}
            · {brand.schoolName} · {academic.academicYear} · {academic.term} ·{" "}
            {student.studentCode}
          </p>
        </footer>
      </div>
    </article>
  );
}
