import type { ReactNode } from "react";
import { AlertTriangle, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

/* Server-safe UI primitives (no hooks) -------------------------------- */

type ButtonVariants = "primary" | "secondary" | "danger" | "ghost";

export function buttonClasses(variant: ButtonVariants = "primary", extra?: string) {
  return cn(
    "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-xl px-4 py-2.5 text-sm font-semibold transition-all duration-200 disabled:cursor-not-allowed disabled:opacity-60",
    variant === "primary" &&
      "bg-orange-500 text-white shadow-[0_8px_20px_-8px_rgba(249,115,22,0.65)] hover:bg-orange-600 active:scale-[0.98]",
    variant === "secondary" &&
      "border border-neutral-200 bg-white text-neutral-700 hover:border-orange-300 hover:text-orange-600 active:scale-[0.98]",
    variant === "danger" && "bg-rose-600 text-white hover:bg-rose-700 active:scale-[0.98]",
    variant === "ghost" && "text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900",
    extra,
  );
}

export function Alert({
  tone = "error",
  children,
  className,
}: {
  tone?: "error" | "success" | "info";
  children: ReactNode;
  className?: string;
}) {
  const Icon = tone === "error" ? AlertTriangle : CheckCircle2;
  return (
    <div
      role={tone === "error" ? "alert" : "status"}
      className={cn(
        "flex items-start gap-2.5 rounded-xl border px-3.5 py-3 text-sm",
        tone === "error" && "border-rose-200 bg-rose-50 text-rose-700",
        tone === "success" && "border-emerald-200 bg-emerald-50 text-emerald-700",
        tone === "info" && "border-orange-200 bg-orange-50 text-orange-800",
        className,
      )}
    >
      <Icon className="mt-0.5 size-4 shrink-0" aria-hidden />
      <div className="min-w-0">{children}</div>
    </div>
  );
}

export function Field({
  label,
  hint,
  children,
  className,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={cn("block", className)}>
      <span className="mb-1.5 block text-[13px] font-semibold text-neutral-700">{label}</span>
      {children}
      {hint ? <span className="mt-1.5 block text-xs text-neutral-400">{hint}</span> : null}
    </label>
  );
}

export const inputClasses =
  "w-full rounded-xl border border-neutral-200 bg-white px-3.5 py-2.5 text-sm text-neutral-900 placeholder:text-neutral-400 shadow-[inset_0_1px_2px_rgba(0,0,0,0.02)] transition-colors focus:border-orange-400 focus:ring-4 focus:ring-orange-100 focus:outline-none";

export function Badge({
  children,
  tone = "neutral",
  className,
}: {
  children: ReactNode;
  tone?: "neutral" | "orange" | "pink" | "green" | "rose" | "amber";
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11px] font-semibold tracking-wide",
        tone === "neutral" && "bg-neutral-100 text-neutral-600",
        tone === "orange" && "bg-orange-100 text-orange-700",
        tone === "pink" && "bg-pink-100 text-pink-700",
        tone === "green" && "bg-emerald-100 text-emerald-700",
        tone === "rose" && "bg-rose-100 text-rose-700",
        tone === "amber" && "bg-amber-100 text-amber-700",
        className,
      )}
    >
      {children}
    </span>
  );
}

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={cn(
        "rounded-2xl border border-neutral-200/70 bg-white shadow-[0_1px_2px_rgba(28,25,23,0.04),0_12px_32px_-16px_rgba(28,25,23,0.14)]",
        className,
      )}
    >
      {children}
    </div>
  );
}
