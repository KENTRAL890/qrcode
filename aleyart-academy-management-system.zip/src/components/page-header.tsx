import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function PageHeader({
  title,
  description,
  children,
  className,
}: {
  title: string;
  description?: string;
  children?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("mb-6 flex flex-wrap items-end justify-between gap-4", className)}>
      <div className="min-w-0">
        <h1 className="font-display text-[1.65rem] font-bold tracking-tight text-neutral-900 sm:text-3xl">
          {title}
        </h1>
        {description ? (
          <p className="mt-1 max-w-2xl text-sm text-neutral-500">{description}</p>
        ) : null}
      </div>
      {children ? <div className="flex w-full min-w-0 flex-wrap items-center gap-2 sm:w-auto">{children}</div> : null}
    </div>
  );
}
