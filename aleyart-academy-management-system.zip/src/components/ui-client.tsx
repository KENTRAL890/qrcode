"use client";

import type { ReactNode, ButtonHTMLAttributes } from "react";
import { useFormStatus } from "react-dom";
import { Loader2 } from "lucide-react";
import { buttonClasses } from "@/components/ui";

type ButtonVariants = "primary" | "secondary" | "danger" | "ghost";

export function SubmitButton({
  children,
  pendingText = "Working…",
  variant = "primary",
  className,
  name,
  value,
}: {
  children: ReactNode;
  pendingText?: string;
  variant?: ButtonVariants;
  className?: string;
  name?: string;
  value?: string;
} & Omit<ButtonHTMLAttributes<HTMLButtonElement>, "className" | "name" | "value">) {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      name={name}
      value={value}
      disabled={pending}
      className={buttonClasses(variant, className)}
    >
      {pending ? (
        <>
          <Loader2 className="size-4 animate-spin" aria-hidden />
          {pendingText}
        </>
      ) : (
        children
      )}
    </button>
  );
}
