import { getSchoolBranding } from "@/lib/school";
import { cn } from "@/lib/utils";

/**
 * The official crest — rendered from the central settings record so a new
 * upload propagates everywhere automatically.
 */
export async function SchoolCrest({
  size = 40,
  className,
}: {
  size?: number;
  className?: string;
}) {
  const brand = await getSchoolBranding();
  const letter = brand.schoolName.trim().charAt(0).toUpperCase() || "A";

  if (!brand.crestUrl) {
    return (
      <div
        className={cn(
          "flex shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-500 to-pink-500 font-display font-bold text-white",
          className,
        )}
        style={{ width: size, height: size, fontSize: size * 0.45 }}
        aria-label={`${brand.schoolName} crest`}
      >
        {letter}
      </div>
    );
  }

  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={brand.crestUrl}
      alt={`${brand.schoolName} crest`}
      width={size}
      height={size}
      className={cn("shrink-0 object-contain", className)}
      style={{ width: size, height: size }}
    />
  );
}

/** Crest + school name + motto lockup, always in sync with central settings. */
export async function SchoolBrandLockup({
  size = 40,
  dark = false,
  motto = true,
  className,
}: {
  size?: number;
  dark?: boolean;
  motto?: boolean;
  className?: string;
}) {
  const brand = await getSchoolBranding();
  return (
    <div className={cn("flex min-w-0 items-center gap-3", className)}>
      <SchoolCrest size={size} className="rounded-xl" />
      <div className="min-w-0">
        <p
          className={cn(
            "truncate font-display font-semibold leading-tight tracking-tight",
            dark ? "text-white" : "text-neutral-900",
            size >= 48 ? "text-lg" : "text-sm",
          )}
        >
          {brand.schoolName}
        </p>
        {motto && brand.motto ? (
          <p
            className={cn(
              "truncate text-[11px] italic leading-tight",
              dark ? "text-orange-200/90" : "text-orange-600",
            )}
          >
            {brand.motto}
          </p>
        ) : null}
      </div>
    </div>
  );
}
