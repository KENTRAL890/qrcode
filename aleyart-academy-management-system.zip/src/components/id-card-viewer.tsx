"use client";

import { useState, type ReactNode } from "react";
import { Printer, ZoomIn, ZoomOut, Ruler } from "lucide-react";

/**
 * Screen preview wrapper for physical ID cards: zoom controls for inspection
 * and a print trigger. Print output is always the true 85.6mm × 54mm size
 * (browsers print CSS mm at 100%); the screen zoom is reset by print rules.
 */
export function IdCardViewer({
  children,
  side,
  printNote = true,
}: {
  children: ReactNode;
  side: "single" | "batch";
  printNote?: boolean;
}) {
  const [zoom, setZoom] = useState(1.2);

  return (
    <div className="space-y-4">
      <div className="no-print flex flex-wrap items-center gap-2.5">
        <div className="flex items-center gap-1 rounded-xl border border-neutral-200 bg-white p-1 shadow-sm">
          <button
            type="button"
            onClick={() => setZoom((z) => Math.max(0.6, +(z - 0.15).toFixed(2)))}
            className="rounded-lg p-1.5 text-neutral-500 transition-colors hover:bg-neutral-100"
            aria-label="Zoom out"
          >
            <ZoomOut className="size-4" />
          </button>
          <span className="w-14 text-center text-xs font-semibold tabular-nums text-neutral-600">
            {Math.round(zoom * 100)}%
          </span>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.min(2.5, +(z + 0.15).toFixed(2)))}
            className="rounded-lg p-1.5 text-neutral-500 transition-colors hover:bg-neutral-100"
            aria-label="Zoom in"
          >
            <ZoomIn className="size-4" />
          </button>
        </div>

        <button
          type="button"
          onClick={() => window.print()}
          className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white shadow-[0_8px_20px_-8px_rgba(249,115,22,0.7)] transition-colors hover:bg-orange-600 active:scale-[0.98]"
        >
          <Printer className="size-4" aria-hidden />
          {side === "single" ? "Print ID card" : "Print all cards"}
        </button>

        {printNote ? (
          <p className="inline-flex items-center gap-1.5 text-[11px] font-medium text-neutral-400">
            <Ruler className="size-3.5" aria-hidden />
            Print at <b className="text-neutral-600">100% · Actual Size</b> — 85.6 × 54 mm. Do not use
            “Fit to page”.
          </p>
        ) : null}
      </div>

      <div className="card-zoom space-y-6" style={{ zoom } as never}>
        {children}
      </div>
    </div>
  );
}

/** One physical face. Screen shows a cut-line + shadow; print is exact mm. */
export function CardSheet({ children, label }: { children: ReactNode; label?: string }) {
  return (
    <section className="card-sheet">
      {label ? (
        <p className="no-print mb-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-neutral-400">
          {label}
        </p>
      ) : null}
      <div className="card-frame w-fit rounded-[3mm] border border-dashed border-neutral-300 shadow-[0_20px_50px_-20px_rgba(28,25,23,0.35)]">
        {children}
      </div>
    </section>
  );
}
