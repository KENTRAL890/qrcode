import { sql } from "drizzle-orm";
import {
  pgTable,
  uuid,
  varchar,
  text,
  boolean,
  timestamp,
  integer,
  numeric,
  jsonb,
  date,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

const timestamps = {
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
};

/* ------------------------------------------------------------------ */
/* RBAC                                                                */
/* ------------------------------------------------------------------ */

export const roles = pgTable("roles", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 50 }).notNull().unique(),
  label: varchar("label", { length: 80 }).notNull(),
  description: text("description"),
  isSystem: boolean("is_system").notNull().default(false),
  createdAt: timestamps.createdAt,
});

export const permissions = pgTable("permissions", {
  id: uuid("id").defaultRandom().primaryKey(),
  code: varchar("code", { length: 80 }).notNull().unique(),
  name: varchar("name", { length: 120 }).notNull(),
  module: varchar("module", { length: 40 }).notNull(),
  createdAt: timestamps.createdAt,
});

export const users = pgTable(
  "users",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    username: varchar("username", { length: 60 }).notNull(),
    passwordHash: text("password_hash").notNull(),
    fullName: varchar("full_name", { length: 120 }).notNull(),
    status: varchar("status", { length: 20 }).notNull().default("active"), // active | disabled
    mustChangePassword: boolean("must_change_password")
      .notNull()
      .default(true),
    failedAttempts: integer("failed_attempts").notNull().default(0),
    lockedUntil: timestamp("locked_until", { withTimezone: true }),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
    createdBy: uuid("created_by"),
    createdAt: timestamps.createdAt,
    updatedAt: timestamps.updatedAt,
  },
  (t) => [
    uniqueIndex("users_username_unique").on(sql`lower(${t.username})`),
    index("users_status_idx").on(t.status),
  ],
);

export const userRoles = pgTable(
  "user_roles",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    roleId: uuid("role_id")
      .notNull()
      .references(() => roles.id, { onDelete: "cascade" }),
    assignedBy: uuid("assigned_by").references(() => users.id, {
      onDelete: "set null",
    }),
    createdAt: timestamps.createdAt,
  },
  (t) => [uniqueIndex("user_roles_unique").on(t.userId, t.roleId), index("user_roles_user_idx").on(t.userId)],
);

export const rolePermissions = pgTable(
  "role_permissions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    roleId: uuid("role_id")
      .notNull()
      .references(() => roles.id, { onDelete: "cascade" }),
    permissionId: uuid("permission_id")
      .notNull()
      .references(() => permissions.id, { onDelete: "cascade" }),
    createdAt: timestamps.createdAt,
  },
  (t) => [
    uniqueIndex("role_permissions_unique").on(t.roleId, t.permissionId),
    index("role_permissions_role_idx").on(t.roleId),
  ],
);

/* ------------------------------------------------------------------ */
/* Sessions                                                            */
/* ------------------------------------------------------------------ */

export const sessions = pgTable(
  "sessions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    tokenHash: varchar("token_hash", { length: 64 }).notNull().unique(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    ipAddress: varchar("ip_address", { length: 64 }),
    userAgent: varchar("user_agent", { length: 300 }),
    createdAt: timestamps.createdAt,
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  },
  (t) => [index("sessions_user_idx").on(t.userId)],
);

/* ------------------------------------------------------------------ */
/* File storage metadata                                               */
/* ------------------------------------------------------------------ */

export const fileMetadata = pgTable("file_metadata", {
  id: uuid("id").defaultRandom().primaryKey(),
  originalFilename: varchar("original_filename", { length: 255 }).notNull(),
  storedFilename: varchar("stored_filename", { length: 255 }).notNull(),
  storagePath: varchar("storage_path", { length: 512 }).notNull().unique(),
  mimeType: varchar("mime_type", { length: 100 }).notNull(),
  sizeBytes: integer("size_bytes").notNull(),
  checksum: varchar("checksum", { length: 64 }).notNull(),
  purpose: varchar("purpose", { length: 40 }).notNull().default("general"),
  uploadedBy: uuid("uploaded_by").references(() => users.id, {
    onDelete: "set null",
  }),
  createdAt: timestamps.createdAt,
});

/* ------------------------------------------------------------------ */
/* Central School Settings (single current row)                        */
/* ------------------------------------------------------------------ */

export const schoolSettings = pgTable("school_settings", {
  id: uuid("id").defaultRandom().primaryKey(),
  schoolName: varchar("school_name", { length: 160 }).notNull(),
  motto: varchar("motto", { length: 200 }),
  location: varchar("location", { length: 200 }),
  poBox: varchar("po_box", { length: 60 }),
  telephone: varchar("telephone", { length: 40 }),
  crestFileId: uuid("crest_file_id").references(() => fileMetadata.id, {
    onDelete: "set null",
  }),
  isCurrent: boolean("is_current").notNull().default(true),
  createdAt: timestamps.createdAt,
  updatedAt: timestamps.updatedAt,
  updatedBy: uuid("updated_by").references(() => users.id, {
    onDelete: "set null",
  }),
});

/* ------------------------------------------------------------------ */
/* Academic structure                                                  */
/* ------------------------------------------------------------------ */

export const classes = pgTable("classes", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 60 }).notNull().unique(),
  levelGroup: varchar("level_group", { length: 10 }).notNull(), // lower | upper
  sortOrder: integer("sort_order").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamps.createdAt,
  updatedAt: timestamps.updatedAt,
});

export const subjects = pgTable("subjects", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 120 }).notNull().unique(),
  description: text("description"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamps.createdAt,
  updatedAt: timestamps.updatedAt,
});

export const classSubjects = pgTable(
  "class_subjects",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    classId: uuid("class_id")
      .notNull()
      .references(() => classes.id, { onDelete: "cascade" }),
    subjectId: uuid("subject_id")
      .notNull()
      .references(() => subjects.id, { onDelete: "cascade" }),
    isCore: boolean("is_core").notNull().default(true),
    createdAt: timestamps.createdAt,
  },
  (t) => [
    uniqueIndex("class_subjects_unique").on(t.classId, t.subjectId),
    index("class_subjects_subject_idx").on(t.subjectId),
  ],
);

export const academicYears = pgTable("academic_years", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 20 }).notNull().unique(), // e.g. 2026/2027
  startDate: date("start_date", { mode: "string" }),
  endDate: date("end_date", { mode: "string" }),
  isCurrent: boolean("is_current").notNull().default(false),
  isArchived: boolean("is_archived").notNull().default(false),
  createdBy: uuid("created_by").references(() => users.id, {
    onDelete: "set null",
  }),
  createdAt: timestamps.createdAt,
  updatedAt: timestamps.updatedAt,
});

export const terms = pgTable(
  "terms",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    name: varchar("name", { length: 40 }).notNull(),
    academicYearId: uuid("academic_year_id")
      .notNull()
      .references(() => academicYears.id, { onDelete: "cascade" }),
    startDate: date("start_date", { mode: "string" }),
    endDate: date("end_date", { mode: "string" }),
    isCurrent: boolean("is_current").notNull().default(false),
    createdAt: timestamps.createdAt,
    updatedAt: timestamps.updatedAt,
  },
  (t) => [
    uniqueIndex("terms_name_year_unique").on(t.name, t.academicYearId),
    index("terms_year_idx").on(t.academicYearId),
  ],
);

/* ------------------------------------------------------------------ */
/* Audit log (append-only)                                             */
/* ------------------------------------------------------------------ */

export const auditLogs = pgTable(
  "audit_logs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
    action: varchar("action", { length: 80 }).notNull(),
    entity: varchar("entity", { length: 60 }).notNull(),
    entityId: varchar("entity_id", { length: 80 }),
    details: jsonb("details"),
    ipAddress: varchar("ip_address", { length: 64 }),
    createdAt: timestamps.createdAt,
  },
  (t) => [
    index("audit_created_idx").on(t.createdAt),
    index("audit_entity_idx").on(t.entity, t.entityId),
  ],
);

/* ------------------------------------------------------------------ */
/* Phase-1 data foundations (real sources for dashboard stats)         */
/* ------------------------------------------------------------------ */

export const students = pgTable(
  "students",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    /** PERMANENT Student ID — e.g. ALA-2026-0001. Never changes after issue. */
    studentCode: varchar("student_code", { length: 20 }).notNull().unique(),
    admissionNumber: varchar("admission_number", { length: 30 })
      .notNull()
      .default("")
      .unique(),
    firstName: varchar("first_name", { length: 80 }).notNull(),
    middleName: varchar("middle_name", { length: 80 }),
    lastName: varchar("last_name", { length: 80 }).notNull(),
    /** Denormalised display/search name: "First Middle Last". */
    fullName: varchar("full_name", { length: 240 }).notNull().default(""),
    gender: varchar("gender", { length: 10 }).notNull().default("other"),
    dateOfBirth: date("date_of_birth", { mode: "string" }),
    photoFileId: uuid("photo_file_id").references(() => fileMetadata.id, {
      onDelete: "set null",
    }),
    /** Current class (affinity changes are recorded in student_academic_history). */
    classId: uuid("class_id").references(() => classes.id, {
      onDelete: "set null",
    }),
    currentAcademicYearId: uuid("current_academic_year_id").references(
      () => academicYears.id,
      { onDelete: "set null" },
    ),
    admissionDate: date("admission_date", { mode: "string" }),
    status: varchar("status", { length: 20 }).notNull().default("active"), // active | inactive | graduated | archived
    guardianName: varchar("guardian_name", { length: 160 }),
    guardianRelation: varchar("guardian_relation", { length: 60 }),
    guardianPhone: varchar("guardian_phone", { length: 40 }),
    contactPhone: varchar("contact_phone", { length: 40 }),
    address: text("address"),
    /** Confidential staff notes — never rendered publicly. */
    notes: text("notes"),
    /** Permanent opaque QR verification token (random, 64 chars). Never changes. */
    qrToken: varchar("qr_token", { length: 96 }).unique(),
    qrIssuedAt: timestamp("qr_issued_at", { withTimezone: true }),
    archivedAt: timestamp("archived_at", { withTimezone: true }),
    createdBy: uuid("created_by").references(() => users.id, {
      onDelete: "set null",
    }),
    createdAt: timestamps.createdAt,
    updatedAt: timestamps.updatedAt,
  },
  (t) => [
    index("students_class_idx").on(t.classId),
    index("students_name_idx").on(t.fullName),
    index("students_status_idx").on(t.status),
    index("students_year_idx").on(t.currentAcademicYearId),
  ],
);

/**
 * One row per student per academic year — the permanent academic trail.
 * Promotion appends; it never rewrites or deletes history.
 */
export const studentAcademicHistory = pgTable(
  "student_academic_history",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    studentId: uuid("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "cascade" }),
    academicYearId: uuid("academic_year_id")
      .notNull()
      .references(() => academicYears.id, { onDelete: "cascade" }),
    classId: uuid("class_id").references(() => classes.id, {
      onDelete: "set null",
    }),
    action: varchar("action", { length: 20 }).notNull(), // enrolled | promoted | repeated | demoted | transferred
    note: text("note"),
    performedBy: uuid("performed_by").references(() => users.id, {
      onDelete: "set null",
    }),
    createdAt: timestamps.createdAt,
  },
  (t) => [
    uniqueIndex("student_history_unique_year").on(t.studentId, t.academicYearId),
    index("student_history_student_idx").on(t.studentId),
  ],
);

/** Atomic per-year counters for issuing permanent Student IDs / admission numbers. */
export const studentIdCounters = pgTable("student_id_counters", {
  year: integer("year").primaryKey(),
  nextValue: integer("next_value").notNull().default(1),
});

/* ------------------------------------------------------------------ */
/* Grading schemes (database-driven, configurable)                     */
/* ------------------------------------------------------------------ */

export const gradingSchemes = pgTable("grading_schemes", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 120 }).notNull().unique(),
  description: text("description"),
  /** competency = letter grades; aggregate = numeric 1–9 bands */
  kind: varchar("kind", { length: 20 }).notNull().default("competency"),
  isDefault: boolean("is_default").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamps.createdAt,
  updatedAt: timestamps.updatedAt,
});

/** Non-overlapping score bands belonging to a scheme (validated server-side). */
export const gradeBands = pgTable(
  "grade_bands",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    schemeId: uuid("scheme_id")
      .notNull()
      .references(() => gradingSchemes.id, { onDelete: "cascade" }),
    minScore: integer("min_score").notNull(),
    maxScore: integer("max_score").notNull(),
    grade: varchar("grade", { length: 10 }).notNull(),
    label: varchar("label", { length: 60 }).notNull(),
    /** numeric aggregate value for aggregate schemes (1–9) */
    points: integer("points"),
    remark: varchar("remark", { length: 160 }),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamps.createdAt,
  },
  (t) => [index("grade_bands_scheme_idx").on(t.schemeId)],
);

/** Configurable aggregate rule (core count + elective count + scheme). */
export const aggregateRules = pgTable("aggregate_rules", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 120 }).notNull().unique(),
  /** Applies to classes in this level group (e.g. "upper" = Basic 7–9). */
  levelGroup: varchar("level_group", { length: 10 }).notNull().default("upper"),
  coreSubjectNames: jsonb("core_subject_names").notNull(),
  electiveSubjectNames: jsonb("elective_subject_names").notNull(),
  electiveCount: integer("elective_count").notNull().default(2),
  aggregateSchemeId: uuid("aggregate_scheme_id").references(() => gradingSchemes.id, {
    onDelete: "set null",
  }),
  /** competition | dense — ranking strategy for positions */
  rankingMethod: varchar("ranking_method", { length: 20 }).notNull().default("competition"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamps.createdAt,
  updatedAt: timestamps.updatedAt,
});

/* ------------------------------------------------------------------ */
/* Assessments — one row per student/subject/term                      */
/* ------------------------------------------------------------------ */

export const assessments = pgTable(
  "assessments",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    studentId: uuid("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "cascade" }),
    /** Denormalised permanent Student ID for historical integrity. */
    studentCode: varchar("student_code", { length: 20 }).notNull(),
    academicYearId: uuid("academic_year_id")
      .notNull()
      .references(() => academicYears.id, { onDelete: "cascade" }),
    termId: uuid("term_id")
      .notNull()
      .references(() => terms.id, { onDelete: "cascade" }),
    /** HISTORICAL class at assessment time — never rewritten by promotion. */
    classId: uuid("class_id")
      .notNull()
      .references(() => classes.id, { onDelete: "restrict" }),
    subjectId: uuid("subject_id")
      .notNull()
      .references(() => subjects.id, { onDelete: "restrict" }),
    classScore: numeric("class_score", { precision: 5, scale: 2 }).notNull(),
    examScore: numeric("exam_score", { precision: 5, scale: 2 }).notNull(),
    total: numeric("total", { precision: 5, scale: 2 }).notNull(),
    grade: varchar("grade", { length: 10 }).notNull(),
    gradeLabel: varchar("grade_label", { length: 60 }),
    remarks: varchar("remarks", { length: 200 }),
    teacherId: uuid("teacher_id").references(() => users.id, { onDelete: "set null" }),
    status: varchar("status", { length: 20 }).notNull().default("draft"), // draft | submitted | locked
    createdAt: timestamps.createdAt,
    updatedAt: timestamps.updatedAt,
  },
  (t) => [
    uniqueIndex("assessment_unique").on(t.studentId, t.termId, t.subjectId),
    index("assessment_term_class_idx").on(t.termId, t.classId),
    index("assessment_student_idx").on(t.studentId),
  ],
);

/* ------------------------------------------------------------------ */
/* Terminal reports — identity = student + academic year + term        */
/* ------------------------------------------------------------------ */

export const terminalReports = pgTable(
  "terminal_reports",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    studentId: uuid("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "cascade" }),
    studentCode: varchar("student_code", { length: 20 }).notNull(),
    academicYearId: uuid("academic_year_id")
      .notNull()
      .references(() => academicYears.id, { onDelete: "restrict" }),
    termId: uuid("term_id")
      .notNull()
      .references(() => terms.id, { onDelete: "restrict" }),
    /** HISTORICAL class the report belongs to. */
    classId: uuid("class_id")
      .notNull()
      .references(() => classes.id, { onDelete: "restrict" }),
    title: varchar("title", { length: 160 }).notNull().default("Terminal Report"),
    status: varchar("status", { length: 20 }).notNull().default("draft"), // draft | published | locked
    totalScore: numeric("total_score", { precision: 8, scale: 2 }),
    averageScore: numeric("average_score", { precision: 5, scale: 2 }),
    overallPosition: integer("overall_position"),
    classSize: integer("class_size"),
    aggregate: integer("aggregate"),
    teacherRemarks: varchar("teacher_remarks", { length: 500 }),
    headteacherRemarks: varchar("headteacher_remarks", { length: 500 }),
    attendancePresent: integer("attendance_present"),
    attendanceTotal: integer("attendance_total"),
    /** Immutable snapshot captured at publication (school brand + results). */
    snapshot: jsonb("snapshot"),
    publishedAt: timestamp("published_at", { withTimezone: true }),
    publishedBy: uuid("published_by").references(() => users.id, { onDelete: "set null" }),
    lockedAt: timestamp("locked_at", { withTimezone: true }),
    lockedBy: uuid("locked_by").references(() => users.id, { onDelete: "set null" }),
    createdBy: uuid("created_by").references(() => users.id, { onDelete: "set null" }),
    createdAt: timestamps.createdAt,
    updatedAt: timestamps.updatedAt,
  },
  (t) => [
    // Report identity: student + academic year + term (NOT current class)
    uniqueIndex("report_identity_unique").on(t.studentId, t.academicYearId, t.termId),
    index("report_term_class_idx").on(t.termId, t.classId),
    index("report_status_idx").on(t.status),
  ],
);

/** Teacher scoping — which classes/subjects a teacher may access. */
export const teacherAssignments = pgTable(
  "teacher_assignments",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    teacherId: uuid("teacher_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    classId: uuid("class_id")
      .notNull()
      .references(() => classes.id, { onDelete: "cascade" }),
    /** null subject = class teacher (all subjects of that class) */
    subjectId: uuid("subject_id").references(() => subjects.id, { onDelete: "cascade" }),
    isClassTeacher: boolean("is_class_teacher").notNull().default(false),
    createdAt: timestamps.createdAt,
  },
  (t) => [
    uniqueIndex("teacher_assignment_unique").on(t.teacherId, t.classId, t.subjectId),
    index("teacher_assignment_teacher_idx").on(t.teacherId),
  ],
);

/* ------------------------------------------------------------------ */
/* FINANCE — all money stored as NUMERIC(12,2); never floating point   */
/* ------------------------------------------------------------------ */

export const feeCategories = pgTable("fee_categories", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 80 }).notNull().unique(),
  code: varchar("code", { length: 20 }).notNull().unique(),
  description: text("description"),
  isRecurring: boolean("is_recurring").notNull().default(true),
  isActive: boolean("is_active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamps.createdAt,
  updatedAt: timestamps.updatedAt,
});

/** Per class + year + term + category amount. */
export const feeStructures = pgTable(
  "fee_structures",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    categoryId: uuid("category_id")
      .notNull()
      .references(() => feeCategories.id, { onDelete: "restrict" }),
    classId: uuid("class_id")
      .notNull()
      .references(() => classes.id, { onDelete: "cascade" }),
    academicYearId: uuid("academic_year_id")
      .notNull()
      .references(() => academicYears.id, { onDelete: "cascade" }),
    termId: uuid("term_id").references(() => terms.id, { onDelete: "cascade" }),
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
    isActive: boolean("is_active").notNull().default(true),
    createdBy: uuid("created_by").references(() => users.id, { onDelete: "set null" }),
    createdAt: timestamps.createdAt,
    updatedAt: timestamps.updatedAt,
  },
  (t) => [
    uniqueIndex("fee_structure_unique").on(t.categoryId, t.classId, t.academicYearId, t.termId),
    index("fee_structure_lookup_idx").on(t.classId, t.academicYearId, t.termId),
  ],
);

/** One ledger account per student per academic year + term. */
export const studentFeeAccounts = pgTable(
  "student_fee_accounts",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    studentId: uuid("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "cascade" }),
    studentCode: varchar("student_code", { length: 20 }).notNull(),
    academicYearId: uuid("academic_year_id")
      .notNull()
      .references(() => academicYears.id, { onDelete: "restrict" }),
    termId: uuid("term_id")
      .notNull()
      .references(() => terms.id, { onDelete: "restrict" }),
    /** HISTORICAL class the account belongs to. */
    classId: uuid("class_id").references(() => classes.id, { onDelete: "set null" }),
    totalCharged: numeric("total_charged", { precision: 12, scale: 2 }).notNull().default("0"),
    totalPaid: numeric("total_paid", { precision: 12, scale: 2 }).notNull().default("0"),
    /** Outstanding = totalCharged - totalPaid (recomputed, never guessed). */
    outstanding: numeric("outstanding", { precision: 12, scale: 2 }).notNull().default("0"),
    createdAt: timestamps.createdAt,
    updatedAt: timestamps.updatedAt,
  },
  (t) => [
    uniqueIndex("fee_account_unique").on(t.studentId, t.academicYearId, t.termId),
    index("fee_account_student_idx").on(t.studentId),
    index("fee_account_term_idx").on(t.termId),
  ],
);

/** Individual charge lines posted to an account (append-only in practice). */
export const feeCharges = pgTable(
  "fee_charges",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    accountId: uuid("account_id")
      .notNull()
      .references(() => studentFeeAccounts.id, { onDelete: "cascade" }),
    studentId: uuid("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "cascade" }),
    categoryId: uuid("category_id").references(() => feeCategories.id, { onDelete: "restrict" }),
    description: varchar("description", { length: 200 }).notNull(),
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
    /** charge | adjustment | reversal */
    kind: varchar("kind", { length: 20 }).notNull().default("charge"),
    reversalOfId: uuid("reversal_of_id"),
    status: varchar("status", { length: 20 }).notNull().default("active"), // active | reversed
    note: varchar("note", { length: 300 }),
    createdBy: uuid("created_by").references(() => users.id, { onDelete: "set null" }),
    createdAt: timestamps.createdAt,
  },
  (t) => [
    index("fee_charge_account_idx").on(t.accountId),
    index("fee_charge_student_idx").on(t.studentId),
  ],
);

/** Payments. Receipt numbers are permanent once issued. */
export const feePayments = pgTable(
  "fee_payments",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    receiptNumber: varchar("receipt_number", { length: 30 }).notNull().unique(),
    accountId: uuid("account_id")
      .notNull()
      .references(() => studentFeeAccounts.id, { onDelete: "restrict" }),
    studentId: uuid("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "restrict" }),
    studentCode: varchar("student_code", { length: 20 }).notNull(),
    academicYearId: uuid("academic_year_id")
      .notNull()
      .references(() => academicYears.id, { onDelete: "restrict" }),
    termId: uuid("term_id")
      .notNull()
      .references(() => terms.id, { onDelete: "restrict" }),
    classId: uuid("class_id").references(() => classes.id, { onDelete: "set null" }),
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
    method: varchar("method", { length: 30 }).notNull().default("cash"),
    reference: varchar("reference", { length: 80 }),
    notes: varchar("notes", { length: 300 }),
    paidAt: timestamp("paid_at", { withTimezone: true }).notNull().defaultNow(),
    /** active | reversed — reversals never delete the original row. */
    status: varchar("status", { length: 20 }).notNull().default("active"),
    reversalOfId: uuid("reversal_of_id"),
    reversedAt: timestamp("reversed_at", { withTimezone: true }),
    reversedBy: uuid("reversed_by").references(() => users.id, { onDelete: "set null" }),
    reversalReason: varchar("reversal_reason", { length: 300 }),
    /** Branding + context frozen at issue time for accounting integrity. */
    snapshot: jsonb("snapshot"),
    receivedBy: uuid("received_by").references(() => users.id, { onDelete: "set null" }),
    receivedByName: varchar("received_by_name", { length: 120 }),
    printCount: integer("print_count").notNull().default(0),
    createdAt: timestamps.createdAt,
    updatedAt: timestamps.updatedAt,
  },
  (t) => [
    index("fee_payment_student_idx").on(t.studentId),
    index("fee_payment_term_idx").on(t.termId),
    index("fee_payment_paid_at_idx").on(t.paidAt),
    index("fee_payment_status_idx").on(t.status),
  ],
);

/** Atomic per-year counter for permanent receipt numbers. */
export const receiptCounters = pgTable("receipt_counters", {
  year: integer("year").primaryKey(),
  nextValue: integer("next_value").notNull().default(1),
});

export type User = typeof users.$inferSelect;
export type Role = typeof roles.$inferSelect;
export type SchoolSettings = typeof schoolSettings.$inferSelect;
export type AcademicYear = typeof academicYears.$inferSelect;
export type Term = typeof terms.$inferSelect;
export type Subject = typeof subjects.$inferSelect;
export type ClassRoom = typeof classes.$inferSelect;
export type FeeCategory = typeof feeCategories.$inferSelect;
export type FeeStructure = typeof feeStructures.$inferSelect;
export type StudentFeeAccount = typeof studentFeeAccounts.$inferSelect;
export type FeeCharge = typeof feeCharges.$inferSelect;
export type FeePayment = typeof feePayments.$inferSelect;
export type Student = typeof students.$inferSelect;
export type StudentAcademicHistoryRow = typeof studentAcademicHistory.$inferSelect;
export type Assessment = typeof assessments.$inferSelect;
export type TerminalReport = typeof terminalReports.$inferSelect;
export type GradingScheme = typeof gradingSchemes.$inferSelect;
export type GradeBand = typeof gradeBands.$inferSelect;
export type AggregateRule = typeof aggregateRules.$inferSelect;
