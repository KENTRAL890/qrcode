import { promises as fs } from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { db } from "@/db";
import {
  roles,
  permissions,
  rolePermissions,
  users,
  userRoles,
  fileMetadata,
  schoolSettings,
  classes,
  subjects,
  classSubjects,
  academicYears,
  terms,
  auditLogs,
  gradingSchemes,
  gradeBands,
  aggregateRules,
  feeCategories,
} from "@/db/schema";
import {
  DEFAULT_COMPETENCY_BANDS,
  DEFAULT_AGGREGATE_BANDS,
  AGGREGATE_CORE_SUBJECTS,
  AGGREGATE_ELECTIVE_SUBJECTS,
} from "@/lib/grading";
import { hashPassword } from "@/lib/passwords";
import { PERMISSIONS, ROLE_LABELS, ROLE_PERMISSION_MAP, type RoleName } from "@/lib/permissions";
import { UPLOAD_DIR } from "@/lib/files";

const LOWER_SUBJECTS = [
  "English Language",
  "Mathematics",
  "Science",
  "Computing",
  "Creative Arts",
  "RME",
  "History",
  "French",
  "GA/Twi",
];

const UPPER_SUBJECTS = [
  "English Language",
  "Mathematics",
  "Integrated Science",
  "Social Studies",
  "Computing",
  "Creative Arts",
  "RME",
  "French",
  "GA/Twi",
  "Career Technology",
];

async function seedDefaultCrest(adminId: string): Promise<string | null> {
  try {
    const source = path.join(process.cwd(), "public", "brand", "default-crest.png");
    const buffer = await fs.readFile(source);
    await fs.mkdir(UPLOAD_DIR, { recursive: true });
    const storedFilename = `${crypto.randomUUID()}.png`;
    const storagePath = path.join(UPLOAD_DIR, storedFilename);
    await fs.writeFile(storagePath, buffer);
    const checksum = crypto.createHash("sha256").update(buffer).digest("hex");

    const [meta] = await db
      .insert(fileMetadata)
      .values({
        originalFilename: "default-crest.png",
        storedFilename,
        storagePath,
        mimeType: "image/png",
        sizeBytes: buffer.length,
        checksum,
        purpose: "crest",
        uploadedBy: adminId,
      })
      .returning({ id: fileMetadata.id });
    return meta.id;
  } catch (error) {
    console.error("[seed] default crest could not be stored:", error);
    return null;
  }
}

/**
 * Idempotent bootstrap. Runs on server start (instrumentation) and can be run
 * from the CLI with: npx tsx -e "import('./src/db/seed.ts').then(m => m.ensureSeeded())"
 */
export async function ensureSeeded(): Promise<void> {
  // Bail out gracefully if tables are not pushed yet
  try {
    await db.select({ id: users.id }).from(users).limit(1);
  } catch {
    console.log("[seed] tables not present yet — run `npx drizzle-kit push` first.");
    return;
  }

  let seededAnything = false;

  /* Reconcile permissions + role grants (idempotent upserts so that
     newly introduced permission codes reach existing deployments). -- */
  const existingPerms = await db.select().from(permissions);
  const permByCode = new Map(existingPerms.map((p) => [p.code, p.id]));
  for (const p of PERMISSIONS) {
    if (!permByCode.has(p.code)) {
      const [row] = await db
        .insert(permissions)
        .values({ code: p.code, name: p.name, module: p.module })
        .onConflictDoNothing({ target: permissions.code })
        .returning();
      if (row) {
        permByCode.set(p.code, row.id);
        seededAnything = true;
      } else {
        const [again] = await db.select().from(permissions);
        void again;
      }
    }
  }
  // Fill any codes that raced above
  if (permByCode.size < PERMISSIONS.length) {
    const refreshed = await db.select().from(permissions);
    for (const p of refreshed) permByCode.set(p.code, p.id);
  }

  const allRoleRows = await db.select().from(roles);
  const existingGrants = await db.select().from(rolePermissions);
  const grantKeys = new Set(existingGrants.map((g) => `${g.roleId}:${g.permissionId}`));
  const missing: Array<{ roleId: string; permissionId: string }> = [];
  for (const role of allRoleRows) {
    const codes = ROLE_PERMISSION_MAP[role.name as RoleName] ?? [];
    for (const code of codes) {
      const pid = permByCode.get(code);
      if (pid && !grantKeys.has(`${role.id}:${pid}`)) {
        missing.push({ roleId: role.id, permissionId: pid });
        grantKeys.add(`${role.id}:${pid}`);
      }
    }
  }
  if (missing.length > 0) {
    await db.insert(rolePermissions).values(missing).onConflictDoNothing();
    seededAnything = true;
  }

  /* Roles + permissions ------------------------------------------- */
  const existingRoles = await db.select().from(roles);
  if (existingRoles.length === 0) {
    const roleRows = await db
      .insert(roles)
      .values([
        { name: "super_admin", label: "Super Administrator", description: "Full control over the entire system.", isSystem: true },
        { name: "admin", label: "Administrator", description: "Manages school configuration and daily operations.", isSystem: true },
        { name: "teacher", label: "Teacher", description: "Teaching staff with academic viewing access.", isSystem: true },
        { name: "office_staff", label: "Office Staff", description: "Administrative office personnel.", isSystem: true },
        { name: "viewer", label: "Viewer", description: "Read-only dashboard access.", isSystem: true },
      ])
      .returning();

    const permRows = await db
      .insert(permissions)
      .values(PERMISSIONS.map((p) => ({ code: p.code, name: p.name, module: p.module })))
      .returning();

    const permIdByCode = new Map(permRows.map((p) => [p.code, p.id]));
    const grants: Array<{ roleId: string; permissionId: string }> = [];
    for (const role of roleRows) {
      const codes = ROLE_PERMISSION_MAP[role.name as RoleName] ?? [];
      for (const code of codes) {
        const pid = permIdByCode.get(code);
        if (pid) grants.push({ roleId: role.id, permissionId: pid });
      }
    }
    if (grants.length > 0) await db.insert(rolePermissions).values(grants);
    seededAnything = true;
  }

  /* Default admin user -------------------------------------------- */
  let adminId: string;
  const [existingAdmin] = await db.select().from(users).limit(1);
  if (!existingAdmin) {
    const [admin] = await db
      .insert(users)
      .values({
        username: "admin",
        fullName: "System Administrator",
        passwordHash: hashPassword("admin123"),
        status: "active",
        mustChangePassword: true, // forced change on first login
      })
      .returning({ id: users.id });
    adminId = admin.id;

    const allRoles = await db.select().from(roles);
    const superAdminRole = allRoles.find((r) => r.name === "super_admin");
    if (superAdminRole) {
      await db
        .insert(userRoles)
        .values({ userId: adminId, roleId: superAdminRole.id, assignedBy: adminId });
    }
    seededAnything = true;
  } else {
    adminId = existingAdmin.id;
  }

  /* Central school settings --------------------------------------- */
  const settingsRows = await db.select().from(schoolSettings).limit(1);
  if (settingsRows.length === 0) {
    const crestId = await seedDefaultCrest(adminId);
    await db.insert(schoolSettings).values({
      schoolName: "ALEYART ACADEMY",
      motto: "Seeking Wisdom",
      location: "Odokor-Official Town, Ghana",
      poBox: "P.O. Box 4183",
      telephone: "0553797233",
      crestFileId: crestId,
      isCurrent: true,
      updatedBy: adminId,
    });
    seededAnything = true;
  }

  /* Classes Basic 1 – 9 ------------------------------------------- */
  const existingClasses = await db.select().from(classes);
  if (existingClasses.length === 0) {
    await db.insert(classes).values(
      Array.from({ length: 9 }, (_, i) => ({
        name: `Basic ${i + 1}`,
        levelGroup: i + 1 <= 6 ? "lower" : "upper",
        sortOrder: i + 1,
        isActive: true,
      })),
    );
    seededAnything = true;
  }

  /* Subjects + class assignments ---------------------------------- */
  const existingSubjects = await db.select().from(subjects);
  if (existingSubjects.length === 0) {
    const uniqueNames = Array.from(new Set([...LOWER_SUBJECTS, ...UPPER_SUBJECTS]));
    const inserted = await db
      .insert(subjects)
      .values(uniqueNames.map((name) => ({ name, isActive: true })))
      .returning();
    const subjectIdByName = new Map(inserted.map((s) => [s.name, s.id]));

    const allClasses = await db.select().from(classes);
    const assignments: Array<{ classId: string; subjectId: string; isCore: boolean }> = [];
    for (const klass of allClasses) {
      const list = klass.levelGroup === "lower" ? LOWER_SUBJECTS : UPPER_SUBJECTS;
      for (const subjectName of list) {
        const subjectId = subjectIdByName.get(subjectName);
        if (subjectId) {
          assignments.push({ classId: klass.id, subjectId, isCore: true });
        }
      }
    }
    if (assignments.length > 0) await db.insert(classSubjects).values(assignments);
    seededAnything = true;
  }

  /* Current academic year + three terms --------------------------- */
  const existingYears = await db.select().from(academicYears);
  if (existingYears.length === 0) {
    const [year] = await db
      .insert(academicYears)
      .values({
        name: "2025/2026",
        startDate: "2025-09-01",
        endDate: "2026-08-31",
        isCurrent: true,
        createdBy: adminId,
      })
      .returning({ id: academicYears.id });

    await db.insert(terms).values([
      { name: "First Term", academicYearId: year.id, startDate: "2025-09-01", endDate: "2025-12-15", isCurrent: true },
      { name: "Second Term", academicYearId: year.id, startDate: "2026-01-08", endDate: "2026-04-10", isCurrent: false },
      { name: "Third Term", academicYearId: year.id, startDate: "2026-05-05", endDate: "2026-08-31", isCurrent: false },
    ]);
    seededAnything = true;
  }

  /* Grading schemes + bands + aggregate rule ---------------------- */
  const existingSchemes = await db.select().from(gradingSchemes);
  if (existingSchemes.length === 0) {
    const [competency] = await db
      .insert(gradingSchemes)
      .values({
        name: "Default Competency Grading",
        description:
          "Standards-based competency bands: A Advance, P Proficient, AP Approaching Proficiency, D Developing, B Beginning.",
        kind: "competency",
        isDefault: true,
        isActive: true,
      })
      .returning({ id: gradingSchemes.id });

    await db.insert(gradeBands).values(
      DEFAULT_COMPETENCY_BANDS.map((b, i) => ({
        schemeId: competency.id,
        minScore: b.minScore,
        maxScore: b.maxScore,
        grade: b.grade,
        label: b.label,
        remark: b.remark,
        points: null,
        sortOrder: i,
      })),
    );

    const [aggregate] = await db
      .insert(gradingSchemes)
      .values({
        name: "Default Aggregate Scale (1–9)",
        description: "Numeric aggregate bands used for Basic 7–9 aggregate computation.",
        kind: "aggregate",
        isDefault: true,
        isActive: true,
      })
      .returning({ id: gradingSchemes.id });

    await db.insert(gradeBands).values(
      DEFAULT_AGGREGATE_BANDS.map((b, i) => ({
        schemeId: aggregate.id,
        minScore: b.minScore,
        maxScore: b.maxScore,
        grade: String(b.points),
        label: `Aggregate ${b.points}`,
        points: b.points,
        remark: null,
        sortOrder: i,
      })),
    );

    await db.insert(aggregateRules).values({
      name: "Basic 7–9 Aggregate (4 core + 2 best electives)",
      levelGroup: "upper",
      coreSubjectNames: AGGREGATE_CORE_SUBJECTS,
      electiveSubjectNames: AGGREGATE_ELECTIVE_SUBJECTS,
      electiveCount: 2,
      aggregateSchemeId: aggregate.id,
      rankingMethod: "competition",
      isActive: true,
    });

    seededAnything = true;
  }

  /* Default fee categories ---------------------------------------- */
  const existingFeeCats = await db.select().from(feeCategories).limit(1);
  if (existingFeeCats.length === 0) {
    await db.insert(feeCategories).values([
      { name: "Tuition", code: "TUITION", isRecurring: true, sortOrder: 1,
        description: "Core termly tuition fee." },
      { name: "Admission", code: "ADMISSION", isRecurring: false, sortOrder: 2,
        description: "One-off fee charged on first admission." },
      { name: "Books", code: "BOOKS", isRecurring: true, sortOrder: 3,
        description: "Textbooks and exercise books." },
      { name: "Transport", code: "TRANSPORT", isRecurring: true, sortOrder: 4,
        description: "School bus / transport service." },
      { name: "Feeding", code: "FEEDING", isRecurring: true, sortOrder: 5,
        description: "Daily meals and refreshment." },
      { name: "Examination", code: "EXAMINATION", isRecurring: true, sortOrder: 6,
        description: "Terminal examination and assessment materials." },
      { name: "PTA Levy", code: "PTA", isRecurring: true, sortOrder: 7,
        description: "Parent-Teacher Association levy." },
    ]);
    seededAnything = true;
  }

  if (seededAnything) {
    try {
      await db.insert(auditLogs).values({
        userId: null,
        action: "system.seeded",
        entity: "system",
        details: {
          roles: ROLE_LABELS,
          classes: 9,
          lowerSubjects: LOWER_SUBJECTS.length,
          upperSubjects: UPPER_SUBJECTS.length,
        },
      });
    } catch {
      /* ignore */
    }
    console.log("[seed] database seeding completed.");
  }
}
