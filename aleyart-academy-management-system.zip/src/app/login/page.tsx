import { redirect } from "next/navigation";
import { MapPin, Phone, ShieldCheck, Sparkles, Wallet } from "lucide-react";
import { getSchoolBranding } from "@/lib/school";
import { getCurrentUser } from "@/lib/auth";
import { SchoolCrest } from "@/components/brand";
import { LoginForm } from "./login-form";
import { Suspense } from "react";

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  const user = await getCurrentUser();
  if (user) redirect(user.mustChangePassword ? "/change-password" : "/dashboard");

  const brand = await getSchoolBranding();

  return (
    <main className="flex min-h-dvh flex-col lg:flex-row">
      {/* Brand panel */}
      <section className="relative overflow-hidden bg-gradient-to-br from-orange-500 via-orange-500 to-pink-600 text-white lg:w-[46%] xl:w-1/2">
        {/* texture layers */}
        <div
          aria-hidden
          className="absolute inset-0 opacity-[0.14]"
          style={{
            backgroundImage:
              "radial-gradient(circle at 25% 20%, white 0, transparent 45%), radial-gradient(circle at 80% 90%, white 0, transparent 40%)",
          }}
        />
        <div
          aria-hidden
          className="absolute -right-24 -top-24 size-[28rem] rounded-full border-[40px] border-white/10"
        />
        <div
          aria-hidden
          className="absolute -bottom-32 -left-24 size-[24rem] rounded-full bg-pink-500/40 blur-3xl"
        />
        {/* kente-inspired accent strip */}
        <div aria-hidden className="absolute inset-x-0 top-0 flex h-1.5">
          <span className="h-full flex-[3] bg-amber-300" />
          <span className="h-full flex-[2] bg-pink-400" />
          <span className="h-full flex-[1] bg-white/80" />
          <span className="h-full flex-[2] bg-orange-300" />
          <span className="h-full flex-[3] bg-amber-300" />
        </div>

        <div className="relative flex h-full flex-col px-6 pb-6 pt-8 sm:px-10 sm:pb-8 lg:p-14 lg:pb-12">
          {/* Mobile brand row */}
          <div className="flex items-center gap-3 lg:hidden">
            <div className="rounded-2xl bg-white/95 p-1.5 shadow-lg shadow-orange-900/20">
              <SchoolCrest size={44} />
            </div>
            <div className="min-w-0">
              <p className="truncate font-display text-lg font-bold leading-tight">
                {brand.schoolName}
              </p>
              {brand.motto ? (
                <p className="text-xs italic text-orange-100">&ldquo;{brand.motto}&rdquo;</p>
              ) : null}
            </div>
          </div>

          {/* Desktop hero */}
          <div className="hidden flex-1 flex-col lg:flex">
            <div className="flex items-center gap-5">
              <div className="anim-fade-up rounded-[1.75rem] bg-white/95 p-3 shadow-2xl shadow-orange-900/30 ring-1 ring-white/40">
                <SchoolCrest size={96} />
              </div>
              <div className="h-16 w-px bg-white/30" aria-hidden />
              <p className="text-sm font-medium uppercase tracking-[0.35em] text-orange-100">
                School
                <br />
                Management
                <br />
                System
              </p>
            </div>

            <h1 className="mt-12 font-display text-4xl font-bold leading-[1.05] tracking-tight xl:text-5xl">
              {brand.schoolName}
            </h1>
            {brand.motto ? (
              <p className="mt-3 max-w-md text-xl italic text-orange-50/95 xl:text-2xl">
                &ldquo;{brand.motto}&rdquo;
              </p>
            ) : null}

            <div className="mt-10 grid max-w-md gap-3">
              {[
                { icon: ShieldCheck, text: "Secure, role-based access for staff" },
                { icon: Sparkles, text: "Academic records, reports & ID cards" },
                { icon: Wallet, text: "Fees, receipts & financial documents" },
              ].map(({ icon: Icon, text }) => (
                <div
                  key={text}
                  className="flex items-center gap-3 rounded-2xl border border-white/15 bg-white/10 px-4 py-3 text-sm font-medium backdrop-blur-sm"
                >
                  <Icon className="size-4 shrink-0 text-amber-200" aria-hidden />
                  {text}
                </div>
              ))}
            </div>
          </div>

          {/* Contact row */}
          <div className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-orange-50/90 lg:mt-0">
            <span className="inline-flex items-center gap-1.5">
              <MapPin className="size-3.5" aria-hidden />
              {brand.location}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Phone className="size-3.5" aria-hidden />
              {brand.telephone}
            </span>
            <span>{brand.poBox}</span>
          </div>
        </div>
      </section>

      {/* Form panel */}
      <section className="relative flex flex-1 items-center justify-center px-4 py-10 sm:px-8">
        <div
          aria-hidden
          className="absolute inset-0 -z-10"
          style={{
            backgroundImage:
              "radial-gradient(circle at 85% 10%, rgba(249,115,22,0.08) 0, transparent 35%), radial-gradient(circle at 10% 90%, rgba(236,72,153,0.07) 0, transparent 35%)",
          }}
        />
        <div className="w-full max-w-md">
          <div className="anim-fade-up rounded-3xl border border-neutral-200/70 bg-white p-6 shadow-[0_2px_4px_rgba(28,25,23,0.04),0_24px_56px_-24px_rgba(234,88,12,0.25)] sm:p-9">
            <div className="mb-1 inline-flex items-center gap-1.5 rounded-full bg-orange-50 px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-orange-600">
              <ShieldCheck className="size-3.5" aria-hidden />
              Secure sign in
            </div>
            <h2 className="mt-4 font-display text-2xl font-bold tracking-tight text-neutral-900 sm:text-[1.7rem]">
              Welcome back
            </h2>
            <p className="mt-1.5 text-sm text-neutral-500">
              Sign in to {brand.schoolName} School Management System.
            </p>

            <Suspense>
              <LoginForm />
            </Suspense>
          </div>

          <p className="mt-6 text-center text-xs text-neutral-400">
            Authorised staff only — every sign-in is recorded.
            <br />© {new Date().getFullYear()} {brand.schoolName}. All rights reserved.
          </p>
        </div>
      </section>
    </main>
  );
}
