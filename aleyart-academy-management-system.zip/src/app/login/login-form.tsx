"use client";

import { useActionState, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Eye, EyeOff, LockKeyhole, LogIn, UserRound } from "lucide-react";
import { loginAction, type FormState } from "@/lib/actions/auth-actions";
import { Alert, Field, inputClasses } from "@/components/ui";
import { SubmitButton } from "@/components/ui-client";
import { cn } from "@/lib/utils";

export function LoginForm() {
  const [state, formAction] = useActionState<FormState | null, FormData>(loginAction, null);
  const [showPassword, setShowPassword] = useState(false);
  const params = useSearchParams();
  const next = params.get("next") ?? "";

  return (
    <form action={formAction} className="mt-7 space-y-5" autoComplete="off">
      <input type="hidden" name="next" value={next} />

      {state?.error ? <Alert>{state.error}</Alert> : null}

      <Field label="Username">
        <div className="relative">
          <UserRound
            className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-neutral-400"
            aria-hidden
          />
          <input
            name="username"
            required
            autoFocus
            autoComplete="username"
            placeholder="e.g. admin"
            className={cn(inputClasses, "pl-10")}
          />
        </div>
      </Field>

      <Field label="Password">
        <div className="relative">
          <LockKeyhole
            className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-neutral-400"
            aria-hidden
          />
          <input
            name="password"
            type={showPassword ? "text" : "password"}
            required
            autoComplete="current-password"
            placeholder="Your password"
            className={cn(inputClasses, "pl-10 pr-11")}
          />
          <button
            type="button"
            onClick={() => setShowPassword((v) => !v)}
            aria-label={showPassword ? "Hide password" : "Show password"}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-neutral-400 transition-colors hover:bg-neutral-100 hover:text-neutral-600"
          >
            {showPassword ? <EyeOff className="size-4" aria-hidden /> : <Eye className="size-4" aria-hidden />}
          </button>
        </div>
      </Field>

      <SubmitButton
        pendingText="Signing you in…"
        className="w-full !py-3 text-[15px] shadow-[0_10px_24px_-10px_rgba(249,115,22,0.7)]"
      >
        <LogIn className="size-4" aria-hidden />
        Sign in
      </SubmitButton>
    </form>
  );
}
