import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Inter, Space_Grotesk } from "next/font/google";
import { getSchoolBranding } from "@/lib/school";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans-var",
  display: "swap",
});

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-display-var",
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

/** Titles, descriptions and the favicon all derive from central school settings. */
export async function generateMetadata(): Promise<Metadata> {
  const brand = await getSchoolBranding();
  return {
    title: {
      default: `${brand.schoolName} — School Management System`,
      template: `%s · ${brand.schoolName}`,
    },
    description: `${brand.schoolName}${brand.motto ? ` — ${brand.motto}` : ""}. ${brand.location}. Official School Management System.`,
    applicationName: brand.schoolName,
    icons: brand.crestUrl ? [{ url: brand.crestUrl, rel: "icon" }] : undefined,
  };
}

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${inter.variable} ${spaceGrotesk.variable}`}>
      <body className="bg-paper font-sans text-neutral-900 antialiased">{children}</body>
    </html>
  );
}
