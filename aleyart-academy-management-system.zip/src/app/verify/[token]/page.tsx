import { eq } from "drizzle-orm";
import {
  ShieldCheck,
  ShieldX,
  Phone,
  MapPin,
  BadgeCheck,
  GraduationCap,
  CalendarDays,
  ScanLine,
} from "lucide-react";
import { db } from "@/db";
import { academicYears, classes, students } from "@/db/schema";
import { getSchoolBranding, FALLBACK_BRANDING } from "@/lib/school";
import { SchoolCrest } from "@/components/brand";
import { initials, formatDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Verify Student",
  robots: { index: false, follow: false },
};

/**
 * PUBLIC verification endpoint — the destination of every student ID-card QR.
 * Serves only approved, public fields. Never exposes guardian data,
 * addresses, financials, notes or anything draft/private.
 */
export default async function VerifyStudentPage({
  params,
}: {
  params: Promise<{ token: string }>;
}) {
  const { token } = await params;
  const brand = await getSchoolBranding().catch(() => FALLBACK_BRANDING);
  const verifiedAt = new Date();

  const tokenValidFormat = /^[A-Za-z0-9_-]{40,100}$/.test(token);

  const [row] = tokenValidFormat
    ? await db
        .select({
          student: students,
          className: classes.name,
          yearName: academicYears.name,
        })
        .from(students)
        .leftJoin(classes, eq(classes.id, students.classId))
        .leftJoin(academicYears, eq(academicYears.id, students.currentAcademicYearId))
        .where(eq(students.qrToken, token))
        .limit(1)
    : [null];

  const s = row?.student ?? null;
  const active = s?.status === "active";

  return (
    <main className="relative flex min-h-dvh items-center justify-center px-4 py-10 bg-paper">
      <div
        aria-hidden
        className="absolute inset-0 -z-10"
        style={{
          backgroundImage:
            "radial-gradient(circle at 15% 15%, rgba(249,115,22,0.09) 0, transparent 40%), radial-gradient(circle at 85% 85%, rgba(236,72,153,0.08) 0, transparent 40%)",
        }}
      />

      <div className="w-full max-w-md">
        {/* School brand */}
        <div className="mb-5 flex items-center justify-center gap-3">
          <SchoolCrest size={46} className="rounded-xl" />
          <div className="text-center">
            <p className="font-display text-lg font-bold leading-tight tracking-tight text-neutral-900">
              {brand.schoolName}
            </p>
            <p className="text-xs italic text-orange-600">&ldquo;{brand.motto}&rdquo;</p>
          </div>
        </div>

        <div className="overflow-hidden rounded-3xl border border-neutral-200/70 bg-white shadow-[0_2px_4px_rgba(28,25,23,0.04),0_24px_56px_-24px_rgba(234,88,12,0.25)]">
          {/* Verification banner */}
          <div
            className={cn(
              "flex items-center justify-center gap-2.5 px-6 py-4",
              active
                ? "bg-gradient-to-r from-emerald-500 to-emerald-600"
                : "bg-gradient-to-r from-rose-500 to-rose-600",
            )}
          >
            {active ? (
              <ShieldCheck className="size-5 text-white" aria-hidden />
            ) : (
              <ShieldX className="size-5 text-white" aria-hidden />
            )}
            <p className="font-display text-sm font-bold uppercase tracking-[0.18em] text-white">
              {active
                ? "Verified — authentic student"
                : s
                  ? "Verification warning"
                  : "Verification failed"}
            </p>
          </div>

          <div className="p-6 sm:p-8">
            {s ? (
              <>
                <div className="flex items-center gap-4">
                  {s.photoFileId ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={`/api/files/${s.photoFileId}`}
                      alt={`Photo of ${s.fullName}`}
                      className="size-[4.5rem] shrink-0 rounded-2xl border border-neutral-100 object-cover shadow-sm"
                    />
                  ) : (
                    <span className="flex size-[4.5rem] shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-100 to-pink-100 font-display text-xl font-bold text-orange-600">
                      {initials(s.fullName)}
                    </span>
                  )}
                  <div className="min-w-0">
                    <h1 className="font-display text-xl font-bold leading-tight tracking-tight text-neutral-900">
                      {s.fullName}
                    </h1>
                    <p className="mt-1 inline-flex items-center gap-1.5 rounded-lg bg-orange-50 px-2.5 py-1 font-mono text-[13px] font-bold text-orange-700">
                      <BadgeCheck className="size-4" aria-hidden />
                      {s.studentCode}
                    </p>
                  </div>
                </div>

                <dl className="mt-6 space-y-2.5">
                  <div className="flex items-center justify-between rounded-xl bg-neutral-50 px-4 py-3">
                    <dt className="flex items-center gap-2 text-xs font-semibold text-neutral-400">
                      <GraduationCap className="size-3.5" aria-hidden /> Current class
                    </dt>
                    <dd className="text-sm font-bold text-neutral-800">{row?.className ?? "—"}</dd>
                  </div>
                  <div className="flex items-center justify-between rounded-xl bg-neutral-50 px-4 py-3">
                    <dt className="flex items-center gap-2 text-xs font-semibold text-neutral-400">
                      <CalendarDays className="size-3.5" aria-hidden /> Academic year
                    </dt>
                    <dd className="font-mono text-sm font-bold text-neutral-800">{row?.yearName ?? "—"}</dd>
                  </div>
                  <div className="flex items-center justify-between rounded-xl bg-neutral-50 px-4 py-3">
                    <dt className="flex items-center gap-2 text-xs font-semibold text-neutral-400">
                      <ScanLine className="size-3.5" aria-hidden /> Student status
                    </dt>
                    <dd>
                      <span
                        className={cn(
                          "rounded-full px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wide",
                          active
                            ? "bg-emerald-100 text-emerald-700"
                            : s.status === "graduated"
                              ? "bg-neutral-100 text-neutral-600"
                              : "bg-rose-100 text-rose-700",
                        )}
                      >
                        {s.status}
                      </span>
                    </dd>
                  </div>
                </dl>

                {!active ? (
                  <p className="mt-4 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs leading-relaxed text-amber-800">
                    This ID belongs to a {s.status} record. It is {s.status === "graduated" ? "no longer a current student card" : "not currently valid"}. Contact the school office for confirmation.
                  </p>
                ) : null}

                <p className="mt-5 text-center text-[11px] leading-relaxed text-neutral-400">
                  Verified {formatDateTime(verifiedAt)} · Only approved public information is shown.
                  Guardian, contact, financial and academic-record details are never exposed here.
                </p>
              </>
            ) : (
              <div className="py-4 text-center">
                <ShieldX className="mx-auto size-10 text-rose-400" aria-hidden />
                <h1 className="mt-4 font-display text-lg font-bold text-neutral-900">
                  Unrecognised verification code
                </h1>
                <p className="mx-auto mt-2 max-w-xs text-xs leading-relaxed text-neutral-500">
                  This code does not match any student ID issued by {brand.schoolName}. The card may
                  be counterfeit, damaged, or revoked. Contact the school office to confirm.
                </p>
              </div>
            )}
          </div>

          <div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-1.5 border-t border-neutral-100 bg-neutral-50/60 px-6 py-4 text-[11px] text-neutral-500">
            <span className="inline-flex items-center gap-1.5">
              <MapPin className="size-3 text-orange-500" aria-hidden />
              {brand.location}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Phone className="size-3 text-orange-500" aria-hidden />
              {brand.telephone}
            </span>
          </div>
        </div>

        <p className="mt-5 text-center text-[11px] text-neutral-400">
          {brand.schoolName} — Official student verification · {brand.poBox}
        </p>
      </div>
    </main>
  );
}
