import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { ArrowLeft, Lock, ShieldCheck, History } from "lucide-react";
import { db } from "@/db";
import { academicYears, classes, students, terminalReports, terms } from "@/db/schema";
import { requirePermission, userHasPermission, isSuperAdmin } from "@/lib/auth";
import { getSchoolBranding } from "@/lib/school";
import { loadBands, loadTeacherScope, scopeAllowsClass } from "@/lib/grading";
import { getLiveReportData, type ReportSnapshot } from "@/lib/actions/report-actions";
import { TerminalReportDoc } from "@/components/terminal-report";
import { ReportViewer } from "@/components/report-viewer";
import { PageHeader } from "@/components/page-header";
import { Alert, Badge } from "@/components/ui";
import { ReportWorkflow } from "./workflow";
import { formatDateTime } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = { title: "Terminal Report" };

export default async function ReportDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const actor = await requirePermission("reports.view");
  const { id } = await params;

  const [row] = await db
    .select({
      report: terminalReports,
      studentName: students.fullName,
      className: classes.name,
      yearName: academicYears.name,
      termName: terms.name,
    })
    .from(terminalReports)
    .innerJoin(students, eq(students.id, terminalReports.studentId))
    .innerJoin(classes, eq(classes.id, terminalReports.classId))
    .innerJoin(academicYears, eq(academicYears.id, terminalReports.academicYearId))
    .innerJoin(terms, eq(terms.id, terminalReports.termId))
    .where(eq(terminalReports.id, id))
    .limit(1);
  if (!row) notFound();
  const report = row.report;

  // Server-side scoping: teachers only reach their own classes
  const unrestricted = isSuperAdmin(actor) || userHasPermission(actor, "reports.publish");
  const scope = await loadTeacherScope(actor.id, unrestricted);
  if (!scopeAllowsClass(scope, report.classId)) {
    return (
      <div className="anim-fade-up space-y-4">
        <PageHeader title="Access restricted" description="This report belongs to a class you are not assigned to." />
        <Link href="/reports" className="inline-flex items-center gap-2 text-sm font-semibold text-orange-600">
          <ArrowLeft className="size-4" aria-hidden /> Back to reports
        </Link>
      </div>
    );
  }

  const snapshot = report.snapshot as ReportSnapshot | null;
  const isFinalised = report.status === "published" || report.status === "locked";
  const useSnapshot = Boolean(snapshot && isFinalised);

  const bands = await loadBands("competency");
  const gradeKey = bands.map((b) => ({
    grade: b.grade,
    label: b.label,
    minScore: b.minScore,
    maxScore: b.maxScore,
  }));

  let docProps;
  let liveError: string | null = null;

  if (useSnapshot && snapshot) {
    // HISTORICAL: render exactly what was frozen at publication.
    docProps = {
      brand: snapshot.school,
      student: snapshot.student,
      academic: snapshot.academic,
      results: snapshot.results,
      totals: snapshot.totals,
      remarks: snapshot.remarks,
    };
  } else {
    // DRAFT: render live data with the CURRENT central school settings.
    const brand = await getSchoolBranding();
    const data = await getLiveReportData(report.studentId, report.termId);
    if ("error" in data) {
      liveError = data.error ?? "Report data unavailable.";
    } else {
      docProps = {
        brand: {
          schoolName: brand.schoolName,
          motto: brand.motto,
          location: brand.location,
          poBox: brand.poBox,
          telephone: brand.telephone,
          crestUrl: brand.crestUrl,
        },
        student: {
          fullName: data.student.fullName,
          studentCode: data.student.studentCode,
          admissionNumber: data.student.admissionNumber,
          gender: data.student.gender,
          photoUrl: data.student.photoFileId ? `/api/files/${data.student.photoFileId}` : null,
        },
        academic: {
          className: data.klass.name,
          academicYear: data.year.name,
          term: data.term.name,
          classSize: data.classSize,
        },
        results: data.results,
        totals: {
          totalScore: data.totalScore,
          averageScore: data.averageScore,
          overallPosition: data.overallPosition,
          aggregate: data.aggregate,
        },
        remarks: {
          teacher: report.teacherRemarks,
          headteacher: report.headteacherRemarks,
        },
      };
    }
  }

  return (
    <div className="anim-fade-up space-y-6">
      <div className="no-print space-y-5">
        <PageHeader
          title={`${row.studentName} — ${row.termName}`}
          description={`${row.className} · ${row.yearName} · Student ID ${report.studentCode}`}
        >
          <div className="flex flex-wrap items-center gap-2">
            <Badge
              tone={report.status === "published" ? "green" : report.status === "locked" ? "neutral" : "amber"}
              className="!px-3 !py-1.5 !text-xs"
            >
              {report.status === "locked" ? <Lock className="size-3" aria-hidden /> : null}
              {report.status}
            </Badge>
            <Link
              href="/reports"
              className="inline-flex items-center gap-2 rounded-xl border border-neutral-200 bg-white px-4 py-2.5 text-sm font-semibold text-neutral-700 transition-colors hover:border-orange-300 hover:text-orange-600"
            >
              <ArrowLeft className="size-4" aria-hidden /> All reports
            </Link>
          </div>
        </PageHeader>

        {useSnapshot ? (
          <Alert tone="info">
            <span className="flex flex-wrap items-center gap-1.5">
              <ShieldCheck className="size-4 shrink-0" aria-hidden />
              <b>Historical snapshot.</b> This document shows the school branding, class and results
              exactly as frozen on {formatDateTime(report.publishedAt)}. Later promotions, edits or
              rebranding do not alter it.
            </span>
          </Alert>
        ) : (
          <Alert tone="info">
            <span className="flex flex-wrap items-center gap-1.5">
              <History className="size-4 shrink-0" aria-hidden />
              <b>Draft preview.</b> Rendered live from current school settings and recorded scores.
              Publishing will freeze a permanent snapshot.
            </span>
          </Alert>
        )}

        <ReportWorkflow
          reportId={report.id}
          status={report.status as "draft" | "published" | "locked"}
          teacherRemarks={report.teacherRemarks ?? ""}
          headteacherRemarks={report.headteacherRemarks ?? ""}
          canManage={userHasPermission(actor, "reports.manage")}
          canPublish={userHasPermission(actor, "reports.publish")}
          canUnlock={userHasPermission(actor, "reports.unlock")}
        />
      </div>

      {liveError ? (
        <Alert>{liveError}</Alert>
      ) : docProps ? (
        <ReportViewer label="Print report (A4)">
          <TerminalReportDoc
            {...docProps}
            gradeKey={gradeKey}
            status={report.status as "draft" | "published" | "locked"}
            isSnapshot={useSnapshot}
            publishedAt={report.publishedAt}
          />
        </ReportViewer>
      ) : null}
    </div>
  );
}
