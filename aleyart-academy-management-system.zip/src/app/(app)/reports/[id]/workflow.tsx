"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { CheckCircle2, Lock, LockOpen, RefreshCw, Save, Undo2 } from "lucide-react";
import {
  publishReportAction,
  lockReportAction,
  unlockReportAction,
  revertReportToDraftAction,
  saveReportRemarksAction,
} from "@/lib/actions/report-actions";
import { Alert, Card, inputClasses, buttonClasses } from "@/components/ui";

export function ReportWorkflow({
  reportId,
  status,
  teacherRemarks,
  headteacherRemarks,
  canManage,
  canPublish,
  canUnlock,
}: {
  reportId: string;
  status: "draft" | "published" | "locked";
  teacherRemarks: string;
  headteacherRemarks: string;
  canManage: boolean;
  canPublish: boolean;
  canUnlock: boolean;
}) {
  const [teacher, setTeacher] = useState(teacherRemarks);
  const [head, setHead] = useState(headteacherRemarks);
  const [unlockReason, setUnlockReason] = useState("");
  const [showUnlock, setShowUnlock] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const run = (fn: () => Promise<{ ok?: boolean; error?: string }>, okText: string) =>
    startTransition(async () => {
      setMsg(null);
      const r = await fn();
      if (r.error) setMsg({ ok: false, text: r.error });
      else {
        setMsg({ ok: true, text: okText });
        router.refresh();
      }
    });

  return (
    <Card className="p-5">
      {msg ? (
        <div className="mb-4">
          <Alert tone={msg.ok ? "success" : "error"}>{msg.text}</Alert>
        </div>
      ) : null}

      {status === "draft" && canManage ? (
        <div className="mb-4 grid gap-3 sm:grid-cols-2">
          <div>
            <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">
              Class teacher&apos;s remarks
            </label>
            <input
              value={teacher}
              onChange={(e) => setTeacher(e.target.value)}
              maxLength={500}
              className={inputClasses}
              placeholder="e.g. A hardworking and focused learner."
            />
          </div>
          <div>
            <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">
              Headteacher&apos;s remarks
            </label>
            <input
              value={head}
              onChange={(e) => setHead(e.target.value)}
              maxLength={500}
              className={inputClasses}
              placeholder="e.g. Excellent result. Keep it up."
            />
          </div>
        </div>
      ) : null}

      <div className="flex flex-wrap items-center gap-2">
        {status === "draft" && canManage ? (
          <button
            type="button"
            disabled={pending}
            onClick={() => run(() => saveReportRemarksAction(reportId, teacher, head), "Remarks saved.")}
            className={buttonClasses("secondary")}
          >
            <Save className="size-4" aria-hidden /> Save remarks
          </button>
        ) : null}

        {status === "draft" && canPublish ? (
          <button
            type="button"
            disabled={pending}
            onClick={() =>
              run(
                () => publishReportAction(reportId),
                "Report published — an immutable snapshot of branding, class and results was captured.",
              )
            }
            className={buttonClasses("primary")}
          >
            <CheckCircle2 className="size-4" aria-hidden /> Publish report
          </button>
        ) : null}

        {status === "published" && canPublish ? (
          <>
            <button
              type="button"
              disabled={pending}
              onClick={() => run(() => lockReportAction(reportId), "Report locked.")}
              className={buttonClasses("primary")}
            >
              <Lock className="size-4" aria-hidden /> Lock report
            </button>
            <button
              type="button"
              disabled={pending}
              onClick={() =>
                run(() => revertReportToDraftAction(reportId), "Reverted to draft — scores are editable again.")
              }
              className={buttonClasses("secondary")}
            >
              <Undo2 className="size-4" aria-hidden /> Revert to draft
            </button>
          </>
        ) : null}

        {status === "locked" ? (
          canUnlock ? (
            <button
              type="button"
              disabled={pending}
              onClick={() => setShowUnlock((v) => !v)}
              className={buttonClasses("secondary")}
            >
              <LockOpen className="size-4" aria-hidden /> Unlock report
            </button>
          ) : (
            <p className="flex items-center gap-1.5 text-xs font-medium text-neutral-500">
              <Lock className="size-3.5" aria-hidden />
              This report is locked. Unlocking requires the report-unlock permission.
            </p>
          )
        ) : null}

        {status !== "draft" ? (
          <span className="inline-flex items-center gap-1.5 text-xs text-neutral-400">
            <RefreshCw className="size-3.5" aria-hidden />
            Score edits are blocked while a report is {status}.
          </span>
        ) : null}
      </div>

      {showUnlock && canUnlock && status === "locked" ? (
        <div className="mt-4 flex flex-wrap items-end gap-2 border-t border-neutral-100 pt-4">
          <div className="min-w-56 flex-1">
            <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">
              Reason for unlocking (recorded in the audit log)
            </label>
            <input
              value={unlockReason}
              onChange={(e) => setUnlockReason(e.target.value)}
              maxLength={300}
              className={inputClasses}
              placeholder="e.g. Correcting a mis-entered exam score for Mathematics"
            />
          </div>
          <button
            type="button"
            disabled={pending || unlockReason.trim().length < 5}
            onClick={() =>
              run(() => unlockReportAction(reportId, unlockReason), "Report unlocked and audited.")
            }
            className={buttonClasses("danger")}
          >
            <LockOpen className="size-4" aria-hidden /> Confirm unlock
          </button>
        </div>
      ) : null}
    </Card>
  );
}
