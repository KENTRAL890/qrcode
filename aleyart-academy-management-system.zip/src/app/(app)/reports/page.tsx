import Link from "next/link";
import { and, asc, desc, eq, inArray } from "drizzle-orm";
import { FileText, Lock, CheckCircle2, PencilLine } from "lucide-react";
import { db } from "@/db";
import { academicYears, classes, students, terminalReports, terms } from "@/db/schema";
import { requirePermission, userHasPermission, isSuperAdmin } from "@/lib/auth";
import { loadTeacherScope, scopeClassFilter } from "@/lib/grading";
import { PageHeader } from "@/components/page-header";
import { Badge, Card } from "@/components/ui";
import { formatDate } from "@/lib/format";
import { BulkGeneratePanel } from "./bulk-generate";
import { cn } from "@/lib/utils";

export const dynamic = "force-dynamic";

export const metadata = { title: "Terminal Reports" };

const STATUS_TONE = { draft: "amber", published: "green", locked: "neutral" } as const;

export default async function ReportsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const actor = await requirePermission("reports.view");
  const canManage = userHasPermission(actor, "reports.manage");
  const unrestricted = isSuperAdmin(actor) || userHasPermission(actor, "reports.publish");
  const scope = await loadTeacherScope(actor.id, unrestricted);
  const allowedClassIds = scopeClassFilter(scope);

  const sp = await searchParams;
  const statusFilter = typeof sp.status === "string" ? sp.status : "";

  const conditions = [];
  if (allowedClassIds) {
    if (allowedClassIds.length === 0) {
      conditions.push(eq(terminalReports.id, "00000000-0000-0000-0000-000000000000"));
    } else {
      conditions.push(inArray(terminalReports.classId, allowedClassIds));
    }
  }
  if (statusFilter) conditions.push(eq(terminalReports.status, statusFilter));

  const [rows, classRows, termRows] = await Promise.all([
    db
      .select({
        id: terminalReports.id,
        status: terminalReports.status,
        title: terminalReports.title,
        averageScore: terminalReports.averageScore,
        overallPosition: terminalReports.overallPosition,
        aggregate: terminalReports.aggregate,
        publishedAt: terminalReports.publishedAt,
        studentCode: terminalReports.studentCode,
        fullName: students.fullName,
        className: classes.name,
        yearName: academicYears.name,
        termName: terms.name,
      })
      .from(terminalReports)
      .innerJoin(students, eq(students.id, terminalReports.studentId))
      .innerJoin(classes, eq(classes.id, terminalReports.classId))
      .innerJoin(academicYears, eq(academicYears.id, terminalReports.academicYearId))
      .innerJoin(terms, eq(terms.id, terminalReports.termId))
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(terminalReports.updatedAt))
      .limit(100),
    db.select().from(classes).where(eq(classes.isActive, true)).orderBy(asc(classes.sortOrder)),
    db
      .select({ id: terms.id, name: terms.name, yearName: academicYears.name })
      .from(terms)
      .innerJoin(academicYears, eq(academicYears.id, terms.academicYearId))
      .where(eq(academicYears.isArchived, false))
      .orderBy(asc(academicYears.name), asc(terms.createdAt)),
  ]);

  const visibleClasses = classRows.filter((c) => !allowedClassIds || allowedClassIds.includes(c.id));

  return (
    <div className="anim-fade-up space-y-6">
      <PageHeader
        title="Terminal Reports"
        description="Report identity is Student + Academic Year + Term, so promotion never disturbs a past report. Publishing freezes an immutable snapshot of the school branding, historical class and results."
      >
        <div className="flex flex-wrap items-center gap-1.5">
          {["", "draft", "published", "locked"].map((s) => (
            <Link
              key={s || "all"}
              href={s ? `/reports?status=${s}` : "/reports"}
              className={cn(
                "rounded-lg border px-3 py-1.5 text-xs font-semibold capitalize transition-colors",
                statusFilter === s
                  ? "border-orange-300 bg-orange-50 text-orange-700"
                  : "border-neutral-200 bg-white text-neutral-500 hover:border-orange-200",
              )}
            >
              {s || "all"}
            </Link>
          ))}
        </div>
      </PageHeader>

      {canManage ? (
        <BulkGeneratePanel
          classes={visibleClasses.map((c) => ({ id: c.id, name: c.name }))}
          terms={termRows.map((t) => ({ id: t.id, name: `${t.yearName} · ${t.name}` }))}
        />
      ) : null}

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px] text-left text-sm">
            <thead>
              <tr className="border-b border-neutral-100 bg-neutral-50/60 text-[11px] uppercase tracking-wider text-neutral-400">
                <th className="px-5 py-3.5 font-semibold">Student</th>
                <th className="px-3 py-3.5 font-semibold">Student ID</th>
                <th className="px-3 py-3.5 font-semibold">Class (historical)</th>
                <th className="px-3 py-3.5 font-semibold">Year · Term</th>
                <th className="px-3 py-3.5 text-center font-semibold">Avg</th>
                <th className="px-3 py-3.5 text-center font-semibold">Pos</th>
                <th className="px-3 py-3.5 text-center font-semibold">Agg</th>
                <th className="px-3 py-3.5 font-semibold">Status</th>
                <th className="px-4 py-3.5 text-right font-semibold">Open</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id} className="border-b border-neutral-50 transition-colors hover:bg-orange-50/25">
                  <td className="px-5 py-3 text-[13.5px] font-semibold text-neutral-800">{r.fullName}</td>
                  <td className="px-3 py-3 font-mono text-xs font-semibold text-orange-700">{r.studentCode}</td>
                  <td className="px-3 py-3 text-[13px] text-neutral-700">{r.className}</td>
                  <td className="px-3 py-3 text-xs tabular-nums text-neutral-500">
                    {r.yearName} · {r.termName}
                  </td>
                  <td className="px-3 py-3 text-center text-[13px] font-semibold tabular-nums">
                    {r.averageScore ? Number(r.averageScore).toFixed(1) : "—"}
                  </td>
                  <td className="px-3 py-3 text-center text-[13px] tabular-nums">{r.overallPosition ?? "—"}</td>
                  <td className="px-3 py-3 text-center text-[13px] tabular-nums">{r.aggregate ?? "—"}</td>
                  <td className="px-3 py-3">
                    <Badge tone={STATUS_TONE[r.status as keyof typeof STATUS_TONE] ?? "neutral"}>
                      {r.status === "locked" ? <Lock className="size-2.5" aria-hidden /> : null}
                      {r.status === "published" ? <CheckCircle2 className="size-2.5" aria-hidden /> : null}
                      {r.status === "draft" ? <PencilLine className="size-2.5" aria-hidden /> : null}
                      {r.status}
                    </Badge>
                    {r.publishedAt ? (
                      <p className="mt-0.5 text-[10px] text-neutral-400">{formatDate(r.publishedAt)}</p>
                    ) : null}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Link
                      href={`/reports/${r.id}`}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-neutral-200 px-3 py-1.5 text-xs font-semibold text-neutral-600 transition-colors hover:border-orange-300 hover:text-orange-600"
                    >
                      <FileText className="size-3.5" aria-hidden /> Open
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {rows.length === 0 ? (
          <div className="flex flex-col items-center px-6 py-16 text-center">
            <FileText className="size-9 text-neutral-300" aria-hidden />
            <p className="mt-3 text-sm font-medium text-neutral-500">No terminal reports yet.</p>
            <p className="mt-1 text-xs text-neutral-400">
              Record assessment scores, then generate reports for a class and term.
            </p>
          </div>
        ) : null}
      </Card>
    </div>
  );
}
