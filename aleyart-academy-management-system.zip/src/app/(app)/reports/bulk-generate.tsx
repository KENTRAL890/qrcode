"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Sparkles } from "lucide-react";
import { bulkGenerateReportsAction } from "@/lib/actions/report-actions";
import { Alert, Card, inputClasses, buttonClasses } from "@/components/ui";

export function BulkGeneratePanel({
  classes,
  terms,
}: {
  classes: Array<{ id: string; name: string }>;
  terms: Array<{ id: string; name: string }>;
}) {
  const [classId, setClassId] = useState("");
  const [termId, setTermId] = useState("");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  function run() {
    setMsg(null);
    startTransition(async () => {
      const r = await bulkGenerateReportsAction(classId, termId);
      if (r.error) setMsg({ ok: false, text: r.error });
      else {
        const skipped = r.skipped?.length ?? 0;
        setMsg({
          ok: true,
          text: `Generated ${r.generated} draft report${r.generated === 1 ? "" : "s"}${
            skipped > 0 ? ` · ${skipped} skipped (${r.skipped!.map((s) => `${s.name}: ${s.reason}`).join("; ")})` : ""
          }`,
        });
        router.refresh();
      }
    });
  }

  return (
    <Card className="p-4">
      {msg ? (
        <div className="mb-3">
          <Alert tone={msg.ok ? "success" : "error"}>{msg.text}</Alert>
        </div>
      ) : null}
      <div className="flex flex-wrap items-end gap-3">
        <div className="min-w-40 flex-1">
          <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">Class</label>
          <select value={classId} onChange={(e) => setClassId(e.target.value)} className={inputClasses}>
            <option value="">Choose class…</option>
            {classes.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
        <div className="min-w-48 flex-1">
          <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">Term</label>
          <select value={termId} onChange={(e) => setTermId(e.target.value)} className={inputClasses}>
            <option value="">Choose term…</option>
            {terms.map((t) => (
              <option key={t.id} value={t.id}>{t.name}</option>
            ))}
          </select>
        </div>
        <button
          type="button"
          onClick={run}
          disabled={pending || !classId || !termId}
          className={buttonClasses("primary")}
        >
          <Sparkles className="size-4" aria-hidden />
          {pending ? "Generating…" : "Generate class reports"}
        </button>
      </div>
    </Card>
  );
}
