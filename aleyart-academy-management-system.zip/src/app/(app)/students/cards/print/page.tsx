import Link from "next/link";
import { inArray, eq } from "drizzle-orm";
import { ArrowLeft } from "lucide-react";
import { db } from "@/db";
import { academicYears, classes, students } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { getSchoolBranding } from "@/lib/school";
import { getVerifyUrl, qrSvg } from "@/lib/qrcode";
import { IdCardFront, IdCardBack } from "@/components/id-card";
import { IdCardViewer, CardSheet } from "@/components/id-card-viewer";
import { PageHeader } from "@/components/page-header";
import { logIdCardGenerated } from "@/lib/actions/student-actions";

export const dynamic = "force-dynamic";

export const metadata = { title: "Batch ID Cards" };

export default async function BatchCardsPrintPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  await requirePermission("students.view");
  const sp = await searchParams;
  const raw = typeof sp.ids === "string" ? sp.ids : "";
  const ids = Array.from(new Set(raw.split(",").map((s) => s.trim()).filter(Boolean))).slice(0, 100);

  if (ids.length === 0) {
    return (
      <div className="anim-fade-up space-y-4">
        <PageHeader title="Batch ID cards" description="No students were selected." />
        <Link href="/students" className="inline-flex items-center gap-2 text-sm font-semibold text-orange-600">
          <ArrowLeft className="size-4" aria-hidden /> Back to directory
        </Link>
      </div>
    );
  }

  const rows = await db
    .select({ student: students, className: classes.name, yearName: academicYears.name })
    .from(students)
    .leftJoin(classes, eq(classes.id, students.classId))
    .leftJoin(academicYears, eq(academicYears.id, students.currentAcademicYearId))
    .where(inArray(students.id, ids));

  const brand = await getSchoolBranding();
  const cardBrand = {
    schoolName: brand.schoolName,
    motto: brand.motto,
    crestUrl: brand.crestUrl,
    telephone: brand.telephone,
    location: brand.location,
  };

  const cards = await Promise.all(
    rows.map(async ({ student: s, className, yearName }) => {
      const verifyUrl = s.qrToken ? await getVerifyUrl(s.qrToken) : null;
      const qrMarkup = verifyUrl ? await qrSvg(verifyUrl) : null;
      return { s, className, yearName, qrMarkup };
    }),
  );

  await logIdCardGenerated(rows.map((r) => r.student.id), true);

  return (
    <div className="anim-fade-up space-y-6">
      <div className="no-print">
        <PageHeader
          title={`Batch ID cards — ${cards.length} student${cards.length === 1 ? "" : "s"}`}
          description="Each face prints on its own 85.6 × 54 mm sheet: all fronts first, then all backs. Use duplex or feed the sheets back for the backs."
        >
          <Link
            href="/students"
            className="inline-flex items-center gap-2 rounded-xl border border-neutral-200 bg-white px-4 py-2.5 text-sm font-semibold text-neutral-700 transition-colors hover:border-orange-300 hover:text-orange-600"
          >
            <ArrowLeft className="size-4" aria-hidden /> Directory
          </Link>
        </PageHeader>
      </div>

      <IdCardViewer side="batch">
        {cards.map(({ s, className, yearName, qrMarkup }) => (
          <div key={s.id} className="space-y-4">
            <CardSheet label={`${s.studentCode} — Front`}>
              <IdCardFront
                student={{
                  fullName: s.fullName,
                  studentCode: s.studentCode,
                  admissionNumber: s.admissionNumber,
                  className,
                  yearName,
                  photoUrl: s.photoFileId ? `/api/files/${s.photoFileId}` : null,
                  gender: s.gender,
                }}
                brand={cardBrand}
              />
            </CardSheet>
            <CardSheet label={`${s.studentCode} — Back`}>
              <IdCardBack
                student={{
                  fullName: s.fullName,
                  studentCode: s.studentCode,
                  admissionNumber: s.admissionNumber,
                  className,
                  yearName,
                  photoUrl: s.photoFileId ? `/api/files/${s.photoFileId}` : null,
                  gender: s.gender,
                }}
                brand={cardBrand}
                qrMarkup={qrMarkup}
              />
            </CardSheet>
          </div>
        ))}
      </IdCardViewer>
    </div>
  );
}
