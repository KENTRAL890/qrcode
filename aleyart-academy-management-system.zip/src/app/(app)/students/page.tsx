import { and, asc, desc, eq, ilike, or, count as dcount } from "drizzle-orm";
import { db } from "@/db";
import { academicYears, classes, students } from "@/db/schema";
import { requirePermission, userHasPermission } from "@/lib/auth";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui";
import { DirectoryClient, type DirectoryRow } from "./directory-client";
import { DirectoryFilters } from "./directory-filters";
import Link from "next/link";
import { UserPlus } from "lucide-react";

export const dynamic = "force-dynamic";

export const metadata = { title: "Students" };

const PAGE_SIZE = 12;

export default async function StudentsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const user = await requirePermission("students.view");
  const canManage = userHasPermission(user, "students.manage");
  const sp = await searchParams;

  const q = (typeof sp.q === "string" ? sp.q : "").trim();
  const classId = typeof sp.classId === "string" ? sp.classId : "";
  const yearId = typeof sp.yearId === "string" ? sp.yearId : "";
  const status = typeof sp.status === "string" ? sp.status : "";
  const page = Math.max(1, Number(typeof sp.page === "string" ? sp.page : "1") || 1);

  const conditions = [];
  if (q) {
    const pattern = `%${q.replaceAll("%", "\\%").replaceAll("_", "\\_")}%`;
    conditions.push(
      or(
        ilike(students.fullName, pattern),
        ilike(students.studentCode, pattern),
        ilike(students.admissionNumber, pattern),
      ),
    );
  }
  if (classId) conditions.push(eq(students.classId, classId));
  if (yearId) conditions.push(eq(students.currentAcademicYearId, yearId));
  if (status) conditions.push(eq(students.status, status));

  const where = conditions.length > 0 ? and(...conditions) : undefined;

  const [[{ value: total }], rows, classRows, yearRows] = await Promise.all([
    db.select({ value: dcount() }).from(students).where(where),
    db
      .select({
        id: students.id,
        studentCode: students.studentCode,
        admissionNumber: students.admissionNumber,
        fullName: students.fullName,
        gender: students.gender,
        status: students.status,
        photoFileId: students.photoFileId,
        className: classes.name,
        yearName: academicYears.name,
      })
      .from(students)
      .leftJoin(classes, eq(classes.id, students.classId))
      .leftJoin(academicYears, eq(academicYears.id, students.currentAcademicYearId))
      .where(where)
      .orderBy(asc(students.fullName), desc(students.createdAt))
      .limit(PAGE_SIZE)
      .offset((page - 1) * PAGE_SIZE),
    db.select().from(classes).orderBy(asc(classes.sortOrder)),
    db.select().from(academicYears).orderBy(desc(academicYears.name)),
  ]);

  const data: DirectoryRow[] = rows.map((r) => ({
    id: r.id,
    studentCode: r.studentCode,
    admissionNumber: r.admissionNumber,
    fullName: r.fullName,
    gender: r.gender,
    status: r.status,
    photoUrl: r.photoFileId ? `/api/files/${r.photoFileId}` : null,
    className: r.className ?? "—",
    yearName: r.yearName ?? "—",
  }));

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  const pageHref = (p: number) => {
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (classId) params.set("classId", classId);
    if (yearId) params.set("yearId", yearId);
    if (status) params.set("status", status);
    params.set("page", String(p));
    return `/students?${params.toString()}`;
  };

  return (
    <div className="anim-fade-up space-y-6">
      <PageHeader
        title="Student Directory"
        description="Every learner issued a permanent Student ID (e.g. ALA-2026-0001). Promotion never duplicates a student — the ID and QR token stay fixed for life."
      >
        <div className="flex items-center gap-2">
          <Badge tone="neutral">{total} student{total === 1 ? "" : "s"}</Badge>
          {canManage ? (
            <Link
              href="/students/new"
              className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-4 py-2.5 text-sm font-semibold text-white shadow-[0_8px_20px_-8px_rgba(249,115,22,0.65)] transition-colors hover:bg-orange-600"
            >
              <UserPlus className="size-4" aria-hidden /> Admit student
            </Link>
          ) : null}
        </div>
      </PageHeader>

      <DirectoryFilters
        classes={classRows.map((c) => ({ id: c.id, name: c.name }))}
        years={yearRows.map((y) => ({ id: y.id, name: y.name }))}
        current={{ q, classId, yearId, status }}
      />

      <DirectoryClient
        rows={data}
        canManage={canManage}
        page={page}
        totalPages={totalPages}
        pageHref={pageHref}
      />
    </div>
  );
}
