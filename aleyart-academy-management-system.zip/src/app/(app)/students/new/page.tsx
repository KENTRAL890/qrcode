import { asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { academicYears, classes } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { PageHeader } from "@/components/page-header";
import { Card } from "@/components/ui";
import { StudentForm } from "../student-form";

export const dynamic = "force-dynamic";

export const metadata = { title: "Admit Student" };

export default async function NewStudentPage() {
  await requirePermission("students.manage");

  const [classRows, yearRows] = await Promise.all([
    db.select().from(classes).where(eq(classes.isActive, true)).orderBy(asc(classes.sortOrder)),
    db
      .select()
      .from(academicYears)
      .where(eq(academicYears.isArchived, false))
      .orderBy(desc(academicYears.name)),
  ]);

  const currentYear = yearRows.find((y) => y.isCurrent) ?? yearRows[0];

  return (
    <div className="anim-fade-up space-y-6">
      <PageHeader
        title="Admit Student"
        description="Creates the student record, issues a permanent Student ID (ALA-YYYY-####) and a permanent QR token, and writes the first academic-history entry — all in one transaction."
      />
      <Card className="p-5 sm:p-7">
        <StudentForm
          mode="create"
          classes={classRows.map((c) => ({ id: c.id, name: c.name }))}
          years={yearRows.map((y) => ({ id: y.id, name: y.name }))}
          defaults={{
            firstName: "",
            middleName: "",
            lastName: "",
            gender: "male",
            dateOfBirth: "",
            admissionNumber: "",
            classId: "",
            academicYearId: currentYear?.id ?? "",
            admissionDate: new Date().toISOString().slice(0, 10),
            guardianName: "",
            guardianRelation: "",
            guardianPhone: "",
            contactPhone: "",
            address: "",
            notes: "",
          }}
        />
      </Card>
    </div>
  );
}
