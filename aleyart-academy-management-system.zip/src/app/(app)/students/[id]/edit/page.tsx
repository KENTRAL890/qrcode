import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { academicYears, classes, students } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { PageHeader } from "@/components/page-header";
import { Badge, Card } from "@/components/ui";
import { StudentForm } from "../../student-form";

export const dynamic = "force-dynamic";

export const metadata = { title: "Edit Student" };

export default async function EditStudentPage({ params }: { params: Promise<{ id: string }> }) {
  await requirePermission("students.manage");
  const { id } = await params;

  const [row] = await db
    .select({ student: students, className: classes.name, yearName: academicYears.name })
    .from(students)
    .leftJoin(classes, eq(classes.id, students.classId))
    .leftJoin(academicYears, eq(academicYears.id, students.currentAcademicYearId))
    .where(eq(students.id, id))
    .limit(1);
  if (!row) notFound();
  const s = row.student;

  return (
    <div className="anim-fade-up space-y-6">
      <PageHeader
        title={`Edit — ${s.fullName}`}
        description="Update bio-data, guardian and contact information. The permanent Student ID and QR token are locked by design."
      >
        <Badge tone="orange" className="!px-3 !py-1.5 !text-xs">{s.studentCode}</Badge>
      </PageHeader>

      <Card className="p-5 sm:p-7">
        <StudentForm
          mode="edit"
          studentId={s.id}
          classes={[]}
          years={[]}
          classLabel={row.className ?? "—"}
          yearLabel={row.yearName ?? "—"}
          photoUrl={s.photoFileId ? `/api/files/${s.photoFileId}` : null}
          defaults={{
            firstName: s.firstName,
            middleName: s.middleName ?? "",
            lastName: s.lastName,
            gender: s.gender,
            dateOfBirth: s.dateOfBirth ?? "",
            admissionNumber: s.admissionNumber,
            classId: s.classId ?? "",
            academicYearId: s.currentAcademicYearId ?? "",
            admissionDate: s.admissionDate ?? "",
            guardianName: s.guardianName ?? "",
            guardianRelation: s.guardianRelation ?? "",
            guardianPhone: s.guardianPhone ?? "",
            contactPhone: s.contactPhone ?? "",
            address: s.address ?? "",
            notes: s.notes ?? "",
          }}
        />
      </Card>
    </div>
  );
}
