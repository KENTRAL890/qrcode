"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { ArrowUpRight, BadgeCheck, ChevronDown } from "lucide-react";
import { promoteStudentAction } from "@/lib/actions/student-actions";
import { Alert, Card, inputClasses } from "@/components/ui";
import { cn } from "@/lib/utils";

interface ClassOpt {
  id: string;
  name: string;
  sortOrder: number;
}
interface YearOpt {
  id: string;
  name: string;
  isArchived: boolean;
}

export function PromotePanel({
  studentId,
  studentCode,
  currentClassId,
  currentYearId,
  currentClassName,
  currentYearName,
  classRows,
  yearRows,
}: {
  studentId: string;
  studentCode: string;
  currentClassId: string | null;
  currentYearId: string | null;
  currentClassName: string | null;
  currentYearName: string | null;
  classRows: ClassOpt[];
  yearRows: YearOpt[];
}) {
  const [open, setOpen] = useState(false);
  const [pending, startTransition] = useTransition();
  const [result, setResult] = useState<{ ok: boolean; text: string } | null>(null);
  const router = useRouter();

  const currentSort = classRows.find((c) => c.id === currentClassId)?.sortOrder ?? 0;
  const nextClass = useMemo(
    () => classRows.find((c) => c.sortOrder === currentSort + 1) ?? classRows[classRows.length - 1],
    [classRows, currentSort],
  );
  const nextYear = useMemo(() => {
    if (!currentYearName) return yearRows[yearRows.length - 1];
    const start = Number(currentYearName.slice(0, 4));
    const wanted = `${start + 1}/${start + 2}`;
    return yearRows.find((y) => y.name === wanted) ?? yearRows[yearRows.length - 1];
  }, [yearRows, currentYearName]);

  const [targetClassId, setTargetClassId] = useState(nextClass?.id ?? "");
  const [targetYearId, setTargetYearId] = useState(nextYear?.id ?? "");
  const [note, setNote] = useState("");

  function submit() {
    setResult(null);
    startTransition(async () => {
      const r = await promoteStudentAction(studentId, targetClassId, targetYearId, note || null);
      if (r.error) {
        setResult({ ok: false, text: r.error });
      } else {
        setResult({
          ok: true,
          text: `Promoted successfully. Permanent ID ${studentCode} and QR token are unchanged — the same QR now resolves to the new class/year.`,
        });
        setNote("");
        router.refresh();
      }
    });
  }

  return (
    <Card className="border-orange-100 bg-gradient-to-br from-orange-50/70 to-pink-50/50 p-5 sm:p-6">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center gap-3 text-left"
      >
        <span className="flex size-10 items-center justify-center rounded-xl bg-orange-500 text-white shadow-[0_8px_18px_-8px_rgba(249,115,22,0.8)]">
          <ArrowUpRight className="size-5" aria-hidden />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block font-display text-sm font-bold text-neutral-900">
            Promote / transfer {studentCode}
          </span>
          <span className="block text-xs text-neutral-500">
            Currently {currentClassName ?? "—"} · {currentYearName ?? "—"}. The Student ID and QR token
            always survive promotion.
          </span>
        </span>
        <ChevronDown className={cn("size-4 text-neutral-400 transition-transform", open && "rotate-180")} aria-hidden />
      </button>

      {open ? (
        <div className="mt-5 space-y-4 border-t border-orange-100 pt-4">
          {result ? <Alert tone={result.ok ? "success" : "error"}>{result.text}</Alert> : null}
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Target class</label>
              <select
                value={targetClassId}
                onChange={(e) => setTargetClassId(e.target.value)}
                className={inputClasses}
              >
                {classRows.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}{c.id === currentClassId ? " (current)" : ""}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Target academic year</label>
              <select
                value={targetYearId}
                onChange={(e) => setTargetYearId(e.target.value)}
                className={inputClasses}
              >
                {yearRows.map((y) => (
                  <option key={y.id} value={y.id} disabled={y.isArchived}>
                    {y.name}{y.id === currentYearId ? " (current)" : ""}{y.isArchived ? " — archived" : ""}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div>
            <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">
              Note for the history record <span className="font-normal text-neutral-400">(optional)</span>
            </label>
            <input
              value={note}
              onChange={(e) => setNote(e.target.value)}
              maxLength={200}
              placeholder="e.g. End-of-year promotion"
              className={inputClasses}
            />
          </div>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="flex max-w-md items-start gap-1.5 text-[11px] leading-relaxed text-neutral-400">
              <BadgeCheck className="mt-0.5 size-3.5 shrink-0 text-emerald-500" aria-hidden />
              Runs in a database transaction: validates the student, class and year, writes the academic
              history row, updates current class/year and audits the event — atomically.
            </p>
            <button
              type="button"
              onClick={submit}
              disabled={pending || !targetClassId || !targetYearId}
              className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white shadow-[0_8px_20px_-8px_rgba(249,115,22,0.7)] transition-colors hover:bg-orange-600 disabled:cursor-not-allowed disabled:opacity-60"
            >
              <ArrowUpRight className="size-4" aria-hidden />
              {pending ? "Promoting…" : "Confirm promotion"}
            </button>
          </div>
        </div>
      ) : null}
    </Card>
  );
}
