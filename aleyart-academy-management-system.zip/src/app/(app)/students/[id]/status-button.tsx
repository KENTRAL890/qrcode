"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Archive, ArchiveRestore } from "lucide-react";
import { archiveStudentAction, restoreStudentAction } from "@/lib/actions/student-actions";

export function StudentStatusButton({ studentId, status }: { studentId: string; status: string }) {
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const archived = status === "archived";

  return (
    <span className="inline-flex flex-col items-end">
      <button
        type="button"
        disabled={pending}
        onClick={() =>
          startTransition(async () => {
            setError(null);
            const r = archived
              ? await restoreStudentAction(studentId)
              : await archiveStudentAction(studentId);
            if (r.error) setError(r.error);
            else router.refresh();
          })
        }
        className={
          archived
            ? "inline-flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-sm font-semibold text-emerald-700 transition-colors hover:bg-emerald-100 disabled:opacity-60"
            : "inline-flex items-center gap-2 rounded-xl border border-rose-200 bg-white px-4 py-2.5 text-sm font-semibold text-rose-600 transition-colors hover:bg-rose-50 disabled:opacity-60"
        }
      >
        {archived ? <ArchiveRestore className="size-4" aria-hidden /> : <Archive className="size-4" aria-hidden />}
        {pending ? "Working…" : archived ? "Restore" : "Archive"}
      </button>
      {error ? <span className="mt-1 text-[11px] font-medium text-rose-600">{error}</span> : null}
    </span>
  );
}
