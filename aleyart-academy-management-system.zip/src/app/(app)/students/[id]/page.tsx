import Link from "next/link";
import { notFound } from "next/navigation";
import { asc, desc, eq } from "drizzle-orm";
import {
  Pencil,
  IdCard,
  ArrowUpRight,
  BadgeCheck,
  QrCode,
  CalendarDays,
  PhoneCall,
  MapPinHouse,
  LockKeyhole,
  UserRound,
  History as HistoryIcon,
  Wallet,
} from "lucide-react";
import { db } from "@/db";
import {
  academicYears,
  classes,
  studentAcademicHistory,
  students,
  users,
} from "@/db/schema";
import { requirePermission, userHasPermission } from "@/lib/auth";
import { PageHeader } from "@/components/page-header";
import { Badge, Card } from "@/components/ui";
import { formatDate, formatDateTime, initials } from "@/lib/format";
import { cn } from "@/lib/utils";
import { PromotePanel } from "./promote-panel";
import { StudentStatusButton } from "./status-button";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [s] = await db.select({ fullName: students.fullName }).from(students).where(eq(students.id, id)).limit(1);
  return { title: s ? `${s.fullName} — Student` : "Student" };
}

const HISTORY_ACTION_META: Record<string, { label: string; tone: string }> = {
  enrolled: { label: "Enrolled", tone: "bg-emerald-100 text-emerald-700" },
  promoted: { label: "Promoted", tone: "bg-orange-100 text-orange-700" },
  repeated: { label: "Repeated", tone: "bg-amber-100 text-amber-700" },
  demoted: { label: "Demoted", tone: "bg-rose-100 text-rose-700" },
  transferred: { label: "Transferred", tone: "bg-sky-100 text-sky-700" },
};

export default async function StudentProfilePage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const user = await requirePermission("students.view");
  const canManage = userHasPermission(user, "students.manage");
  const canPromote = userHasPermission(user, "students.promote");
  const { id } = await params;
  const sp = await searchParams;

  const [row] = await db
    .select({
      student: students,
      className: classes.name,
      classSort: classes.sortOrder,
      yearName: academicYears.name,
    })
    .from(students)
    .leftJoin(classes, eq(classes.id, students.classId))
    .leftJoin(academicYears, eq(academicYears.id, students.currentAcademicYearId))
    .where(eq(students.id, id))
    .limit(1);
  if (!row) notFound();
  const s = row.student;

  const [history, classRows, yearRows] = await Promise.all([
    db
      .select({
        id: studentAcademicHistory.id,
        action: studentAcademicHistory.action,
        note: studentAcademicHistory.note,
        createdAt: studentAcademicHistory.createdAt,
        yearName: academicYears.name,
        className: classes.name,
        performedByName: users.fullName,
      })
      .from(studentAcademicHistory)
      .leftJoin(academicYears, eq(academicYears.id, studentAcademicHistory.academicYearId))
      .leftJoin(classes, eq(classes.id, studentAcademicHistory.classId))
      .leftJoin(users, eq(users.id, studentAcademicHistory.performedBy))
      .where(eq(studentAcademicHistory.studentId, s.id))
      .orderBy(desc(academicYears.name), asc(studentAcademicHistory.createdAt)),
    db.select().from(classes).orderBy(asc(classes.sortOrder)),
    db.select().from(academicYears).orderBy(asc(academicYears.name)),
  ]);

  const photoUrl = s.photoFileId ? `/api/files/${s.photoFileId}` : null;

  return (
    <div className="anim-fade-up space-y-6">
      <PageHeader title={s.fullName} description={`${row.className ?? "No class"} · ${row.yearName ?? "No academic year"}`}>
        <div className="flex w-full min-w-0 flex-wrap items-center gap-2 sm:w-auto">
          <Badge
            tone={s.status === "active" ? "green" : s.status === "archived" ? "rose" : "neutral"}
            className="!px-3 !py-1.5 !text-xs"
          >
            {s.status}
          </Badge>
          <Link
            href={`/finance/payments?studentId=${s.id}`}
            className="inline-flex items-center gap-2 rounded-xl border border-neutral-200 bg-white px-4 py-2.5 text-sm font-semibold text-neutral-700 transition-colors hover:border-orange-300 hover:text-orange-600"
          >
            <Wallet className="size-4" aria-hidden /> Fees
          </Link>
          <Link
            href={`/students/${s.id}/card`}
            className="inline-flex items-center gap-2 rounded-xl border border-neutral-200 bg-white px-4 py-2.5 text-sm font-semibold text-neutral-700 transition-colors hover:border-orange-300 hover:text-orange-600"
          >
            <IdCard className="size-4" aria-hidden /> ID card
          </Link>
          {canManage ? (
            <Link
              href={`/students/${s.id}/edit`}
              className="inline-flex items-center gap-2 rounded-xl border border-neutral-200 bg-white px-4 py-2.5 text-sm font-semibold text-neutral-700 transition-colors hover:border-orange-300 hover:text-orange-600"
            >
              <Pencil className="size-4" aria-hidden /> Edit
            </Link>
          ) : null}
          {canManage ? <StudentStatusButton studentId={s.id} status={s.status} /> : null}
        </div>
      </PageHeader>

      {sp.created === "1" ? (
        <div className="flex items-center gap-2.5 rounded-2xl border border-emerald-200 bg-emerald-50 px-5 py-3.5 text-sm text-emerald-700">
          <BadgeCheck className="size-5 shrink-0" aria-hidden />
          <span>
            Student admitted — permanent ID <b className="font-mono">{s.studentCode}</b> issued together
            with a permanent QR token. This ID never changes, across every class and year.
          </span>
        </div>
      ) : null}

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[0.9fr_1.1fr]">
        {/* Identity */}
        <div className="space-y-5">
          <Card className="overflow-hidden">
            <div className="h-1.5 bg-gradient-to-r from-orange-500 via-orange-400 to-pink-500" />
            <div className="p-5 sm:p-6">
              <div className="flex items-start gap-4">
                {photoUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={photoUrl}
                    alt={`Photo of ${s.fullName}`}
                    className="size-24 shrink-0 rounded-2xl border border-neutral-100 object-cover shadow-sm"
                  />
                ) : (
                  <span className="flex size-24 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-100 to-pink-100 font-display text-2xl font-bold text-orange-600">
                    {initials(s.fullName)}
                  </span>
                )}
                <div className="min-w-0">
                  <p className="inline-flex items-center gap-1.5 rounded-lg bg-orange-50 px-2.5 py-1 font-mono text-sm font-bold text-orange-700">
                    <BadgeCheck className="size-4" aria-hidden />
                    {s.studentCode}
                  </p>
                  <p className="mt-2 text-xs text-neutral-400">Permanent Student ID — never changes</p>
                  <p className="mt-2.5 inline-flex items-center gap-1.5 text-xs font-medium text-neutral-500">
                    <QrCode className="size-3.5 text-orange-500" aria-hidden />
                    QR token {s.qrToken ? "issued" : "missing"}
                    {s.qrIssuedAt ? ` · ${formatDate(s.qrIssuedAt)}` : ""}
                  </p>
                </div>
              </div>

              <dl className="mt-6 grid grid-cols-1 gap-3 min-[480px]:grid-cols-2">
                {(
                  [
                    ["Full name", s.fullName],
                    ["Gender", s.gender],
                    ["Date of birth", formatDate(s.dateOfBirth)],
                    ["Admission number", s.admissionNumber || "—"],
                    ["Admission date", formatDate(s.admissionDate)],
                    ["Record created", formatDate(s.createdAt)],
                  ] as Array<[string, string]>
                ).map(([k, v]) => (
                  <div key={k} className="rounded-xl bg-neutral-50 px-3.5 py-2.5">
                    <dt className="text-[10px] font-semibold uppercase tracking-wide text-neutral-400">{k}</dt>
                    <dd className="mt-0.5 truncate text-[13px] font-semibold capitalize text-neutral-800">{v}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </Card>

          {/* Guardian & contact — private */}
          <Card className="p-5 sm:p-6">
            <h3 className="flex items-center gap-2 font-display text-sm font-bold text-neutral-900">
              <UserRound className="size-4 text-pink-500" aria-hidden />
              Guardian & contact
              <span className="ml-auto inline-flex items-center gap-1 rounded-full bg-rose-50 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-rose-500">
                <LockKeyhole className="size-2.5" aria-hidden /> private
              </span>
            </h3>
            <dl className="mt-4 space-y-2.5 text-sm">
              {(
                [
                  ["Guardian / parent", s.guardianName],
                  ["Relationship", s.guardianRelation],
                  ["Guardian phone", s.guardianPhone],
                  ["Home contact", s.contactPhone],
                ] as Array<[string, string | null]>
              ).map(([k, v]) => (
                <div key={k} className="flex items-start justify-between gap-4">
                  <dt className="text-xs text-neutral-400">{k}</dt>
                  <dd className="flex items-center gap-1.5 text-right text-[13px] font-medium text-neutral-700">
                    {k.includes("phone") || k.includes("contact") ? (
                      <PhoneCall className="size-3 text-neutral-300" aria-hidden />
                    ) : null}
                    {v || <span className="text-neutral-300">—</span>}
                  </dd>
                </div>
              ))}
              <div className="flex items-start justify-between gap-4">
                <dt className="text-xs text-neutral-400">Address</dt>
                <dd className="flex items-center gap-1.5 text-right text-[13px] font-medium text-neutral-700">
                  <MapPinHouse className="size-3.5 text-neutral-300" aria-hidden />
                  <span className="max-w-[13rem] break-words">{s.address || "—"}</span>
                </dd>
              </div>
            </dl>
          </Card>

          {s.notes ? (
            <Card className="border-amber-100 bg-amber-50/60 p-5">
              <h3 className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider text-amber-600">
                <LockKeyhole className="size-3.5" aria-hidden /> Confidential staff notes
              </h3>
              <p className="mt-2 whitespace-pre-wrap text-[13px] leading-relaxed text-amber-900/80">{s.notes}</p>
            </Card>
          ) : null}
        </div>

        {/* Right column: promote + history */}
        <div className="space-y-5">
          {canPromote ? (
            <PromotePanel
              studentId={s.id}
              studentCode={s.studentCode}
              currentClassId={s.classId}
              currentYearId={s.currentAcademicYearId}
              currentClassName={row.className}
              currentYearName={row.yearName}
              classRows={classRows.map((c) => ({ id: c.id, name: c.name, sortOrder: c.sortOrder }))}
              yearRows={yearRows.map((y) => ({ id: y.id, name: y.name, isArchived: y.isArchived }))}
            />
          ) : null}

          <Card className="p-5 sm:p-6">
            <h3 className="flex items-center gap-2 font-display text-sm font-bold text-neutral-900">
              <HistoryIcon className="size-4 text-orange-500" aria-hidden />
              Academic history — one Student ID, every year
            </h3>
            <p className="mt-1 text-xs text-neutral-400">
              Class and year progression for <span className="font-mono font-semibold">{s.studentCode}</span>.
              Promotion appends to this trail; it never rewrites it.
            </p>

            <ol className="relative mt-6 space-y-4 border-l-2 border-orange-100 pl-6">
              {history.map((h, i) => {
                const meta = HISTORY_ACTION_META[h.action] ?? HISTORY_ACTION_META.enrolled;
                const isCurrent = i === 0 && h.yearName === row.yearName;
                return (
                  <li key={h.id} className="relative">
                    <span
                      className={cn(
                        "absolute -left-[31px] top-1 flex size-[18px] items-center justify-center rounded-full border-2 border-paper",
                        isCurrent ? "bg-orange-500" : "bg-orange-200",
                      )}
                    >
                      {isCurrent ? <ArrowUpRight className="size-2.5 text-white" aria-hidden /> : null}
                    </span>
                    <div className="flex w-full min-w-0 flex-wrap items-center gap-2 sm:w-auto">
                      <span className="flex items-center gap-1.5 font-mono text-sm font-bold text-neutral-800">
                        <CalendarDays className="size-3.5 text-orange-400" aria-hidden />
                        {h.yearName}
                      </span>
                      <span className="text-neutral-300">→</span>
                      <span className="text-sm font-semibold text-neutral-700">{h.className ?? "—"}</span>
                      <span className={cn("rounded-full px-2.5 py-0.5 text-[10.5px] font-bold uppercase tracking-wide", meta.tone)}>
                        {meta.label}
                      </span>
                      {isCurrent && row.className === h.className ? (
                        <Badge tone="orange">current</Badge>
                      ) : null}
                    </div>
                    <p className="mt-1 text-xs text-neutral-400">
                      {h.note ?? "—"} {h.performedByName ? `· by ${h.performedByName}` : ""} · {formatDateTime(h.createdAt)}
                    </p>
                  </li>
                );
              })}
              {history.length === 0 ? (
                <li className="text-xs text-neutral-400">No academic history recorded yet.</li>
              ) : null}
            </ol>
          </Card>
        </div>
      </div>
    </div>
  );
}
