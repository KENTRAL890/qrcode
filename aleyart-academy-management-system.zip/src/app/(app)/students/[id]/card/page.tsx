import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { ArrowLeft } from "lucide-react";
import { db } from "@/db";
import { academicYears, classes, students } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { getSchoolBranding } from "@/lib/school";
import { getVerifyUrl, qrSvg } from "@/lib/qrcode";
import { IdCardFront, IdCardBack } from "@/components/id-card";
import { IdCardViewer, CardSheet } from "@/components/id-card-viewer";
import { PageHeader } from "@/components/page-header";
import { logIdCardGenerated } from "@/lib/actions/student-actions";

export const dynamic = "force-dynamic";

export const metadata = { title: "Student ID Card" };

export default async function StudentCardPage({ params }: { params: Promise<{ id: string }> }) {
  await requirePermission("students.view");
  const { id } = await params;

  const [row] = await db
    .select({ student: students, className: classes.name, yearName: academicYears.name })
    .from(students)
    .leftJoin(classes, eq(classes.id, students.classId))
    .leftJoin(academicYears, eq(academicYears.id, students.currentAcademicYearId))
    .where(eq(students.id, id))
    .limit(1);
  if (!row) notFound();
  const s = row.student;

  const brand = await getSchoolBranding();
  const verifyUrl = s.qrToken ? await getVerifyUrl(s.qrToken) : null;
  const qrMarkup = verifyUrl ? await qrSvg(verifyUrl) : null;

  await logIdCardGenerated([s.id], false);

  const cardStudent = {
    fullName: s.fullName,
    studentCode: s.studentCode,
    admissionNumber: s.admissionNumber,
    className: row.className,
    yearName: row.yearName,
    photoUrl: s.photoFileId ? `/api/files/${s.photoFileId}` : null,
    gender: s.gender,
  };
  const cardBrand = {
    schoolName: brand.schoolName,
    motto: brand.motto,
    crestUrl: brand.crestUrl,
    telephone: brand.telephone,
    location: brand.location,
  };

  return (
    <div className="anim-fade-up space-y-6">
      <div className="no-print">
        <PageHeader
          title={`ID card — ${s.fullName}`}
          description="Live preview of the physical CR80 card. School name, motto and crest come from central School Settings — rebranding updates this card automatically."
        >
          <Link
            href={`/students/${s.id}`}
            className="inline-flex items-center gap-2 rounded-xl border border-neutral-200 bg-white px-4 py-2.5 text-sm font-semibold text-neutral-700 transition-colors hover:border-orange-300 hover:text-orange-600"
          >
            <ArrowLeft className="size-4" aria-hidden /> Profile
          </Link>
        </PageHeader>
      </div>

      <IdCardViewer side="single">
        <CardSheet label="Front · 85.6 × 54 mm">
          <IdCardFront student={cardStudent} brand={cardBrand} />
        </CardSheet>
        <CardSheet label="Back · 85.6 × 54 mm · print on reverse (duplex, flip on long edge)">
          <IdCardBack student={cardStudent} brand={cardBrand} qrMarkup={qrMarkup} />
        </CardSheet>
      </IdCardViewer>

      <p className="no-print max-w-2xl rounded-2xl border border-dashed border-orange-200 bg-orange-50/60 px-5 py-3.5 text-xs leading-relaxed text-orange-700">
        The QR code contains only an opaque verification link — no personal data is embedded.
        Scanning it always resolves the student&apos;s <b>current</b> class and academic year from the
        database, while the permanent ID <span className="font-mono font-bold">{s.studentCode}</span>{" "}
        and the QR itself stay fixed from Basic 1 to Basic 9.
      </p>
    </div>
  );
}
