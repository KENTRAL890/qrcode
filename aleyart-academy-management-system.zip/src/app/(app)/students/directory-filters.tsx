"use client";

import { useRouter } from "next/navigation";
import { Search, Filter, X } from "lucide-react";
import { Card, inputClasses, buttonClasses } from "@/components/ui";

interface Filters {
  q: string;
  classId: string;
  yearId: string;
  status: string;
}

export function DirectoryFilters({
  classes,
  years,
  current,
}: {
  classes: Array<{ id: string; name: string }>;
  years: Array<{ id: string; name: string }>;
  current: Filters;
}) {
  const router = useRouter();

  function submit(formData: FormData) {
    const params = new URLSearchParams();
    const q = String(formData.get("q") ?? "").trim();
    const classId = String(formData.get("classId") ?? "");
    const yearId = String(formData.get("yearId") ?? "");
    const status = String(formData.get("status") ?? "");
    if (q) params.set("q", q);
    if (classId) params.set("classId", classId);
    if (yearId) params.set("yearId", yearId);
    if (status) params.set("status", status);
    router.push(`/students${params.size > 0 ? `?${params.toString()}` : ""}`);
  }

  const hasFilters = current.q || current.classId || current.yearId || current.status;

  return (
    <Card className="p-4">
      <form action={submit} className="flex flex-wrap items-end gap-3">
        <div className="min-w-52 flex-[2]">
          <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">
            Search name, Student ID or admission no.
          </label>
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-neutral-400" aria-hidden />
            <input name="q" defaultValue={current.q} placeholder="e.g. ALA-2026-0001 or Ama Serwaa" className={`${inputClasses} pl-9`} />
          </div>
        </div>
        <div className="min-w-36 flex-1">
          <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">Class</label>
          <select name="classId" defaultValue={current.classId} className={inputClasses}>
            <option value="">All classes</option>
            {classes.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
        <div className="min-w-36 flex-1">
          <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">Academic year</label>
          <select name="yearId" defaultValue={current.yearId} className={inputClasses}>
            <option value="">All years</option>
            {years.map((y) => (
              <option key={y.id} value={y.id}>{y.name}</option>
            ))}
          </select>
        </div>
        <div className="min-w-32 flex-1">
          <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">Status</label>
          <select name="status" defaultValue={current.status} className={inputClasses}>
            <option value="">All statuses</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="graduated">Graduated</option>
            <option value="archived">Archived</option>
          </select>
        </div>
        <button type="submit" className={buttonClasses("primary")}>
          <Filter className="size-4" aria-hidden /> Filter
        </button>
        {hasFilters ? (
          <button
            type="button"
            onClick={() => router.push("/students")}
            className={buttonClasses("ghost")}
          >
            <X className="size-4" aria-hidden /> Clear
          </button>
        ) : null}
      </form>
    </Card>
  );
}
