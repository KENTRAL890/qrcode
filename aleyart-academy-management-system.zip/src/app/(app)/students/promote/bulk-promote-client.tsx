"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { ArrowUpRight, CheckCircle2, AlertTriangle, Users as UsersIcon, Filter } from "lucide-react";
import { bulkPromoteStudentsAction, type BulkPromoteResult } from "@/lib/actions/student-actions";
import { Alert, Badge, Card, inputClasses, buttonClasses } from "@/components/ui";
import { initials } from "@/lib/format";
import { cn } from "@/lib/utils";

export interface BulkStudent {
  id: string;
  studentCode: string;
  fullName: string;
  gender: string;
}

interface ClassOpt {
  id: string;
  name: string;
  sortOrder: number;
}
interface YearOpt {
  id: string;
  name: string;
  isArchived: boolean;
}

export function BulkPromoteClient({
  classes,
  years,
  eligible,
  sourceClassId,
  sourceYearId,
  defaultTargetYearId,
  totalEligible,
}: {
  classes: ClassOpt[];
  years: YearOpt[];
  eligible: BulkStudent[];
  sourceClassId: string;
  sourceYearId: string;
  defaultTargetYearId: string;
  totalEligible: number;
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [checked, setChecked] = useState<Set<string>>(new Set(eligible.map((s) => s.id)));
  const [targetClassId, setTargetClassId] = useState(() => {
    const src = classes.find((c) => c.id === sourceClassId);
    return classes.find((c) => c.sortOrder === (src?.sortOrder ?? 0) + 1)?.id ?? "";
  });
  const [targetYearId, setTargetYearId] = useState(defaultTargetYearId);
  const [note, setNote] = useState("");
  const [result, setResult] = useState<BulkPromoteResult | null>(null);

  function loadClass(formData: FormData) {
    const params = new URLSearchParams();
    const classId = String(formData.get("sourceClassId") ?? "");
    const yearId = String(formData.get("sourceYearId") ?? "");
    if (classId && yearId) {
      params.set("classId", classId);
      params.set("yearId", yearId);
      router.push(`/students/promote?${params.toString()}`);
    }
  }

  function promote() {
    setResult(null);
    startTransition(async () => {
      const r = await bulkPromoteStudentsAction(
        Array.from(checked),
        targetClassId,
        targetYearId,
        note.trim() || null,
      );
      setResult(r);
      if (r.ok) router.refresh();
    });
  }

  const allChecked = eligible.length > 0 && eligible.every((s) => checked.has(s.id));

  return (
    <div className="space-y-5">
      {/* Source selection */}
      <Card className="p-4">
        <form action={loadClass} className="flex flex-wrap items-end gap-3">
          <div className="min-w-40 flex-1">
            <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">Source class</label>
            <select name="sourceClassId" defaultValue={sourceClassId} className={inputClasses}>
              <option value="">Choose class…</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
          <div className="min-w-40 flex-1">
            <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">Current academic year</label>
            <select name="sourceYearId" defaultValue={sourceYearId} className={inputClasses}>
              <option value="">Choose year…</option>
              {years.map((y) => (
                <option key={y.id} value={y.id}>{y.name}</option>
              ))}
            </select>
          </div>
          <button type="submit" className={buttonClasses("primary")}>
            <Filter className="size-4" aria-hidden /> Load students
          </button>
        </form>
      </Card>

      {sourceClassId && sourceYearId ? (
        <div className="grid grid-cols-1 gap-5 xl:grid-cols-[1.15fr_0.85fr]">
          {/* Eligible list */}
          <Card className="overflow-hidden">
            <div className="flex items-center justify-between border-b border-neutral-100 px-5 py-3.5">
              <label className="flex items-center gap-2.5">
                <input
                  type="checkbox"
                  checked={allChecked}
                  onChange={() =>
                    setChecked(() =>
                      allChecked ? new Set() : new Set(eligible.map((s) => s.id)),
                    )
                  }
                  className="size-4 accent-orange-500"
                />
                <span className="text-[13px] font-bold text-neutral-700">
                  Select all ({eligible.length})
                </span>
              </label>
              <Badge tone="neutral">{totalEligible} eligible</Badge>
            </div>
            <div className="max-h-[26rem] overflow-y-auto">
              {eligible.length === 0 ? (
                <div className="flex flex-col items-center px-6 py-14 text-center">
                  <UsersIcon className="size-8 text-neutral-300" aria-hidden />
                  <p className="mt-3 text-sm text-neutral-500">
                    No active students found in that class and year.
                  </p>
                </div>
              ) : (
                <ul>
                  {eligible.map((s) => (
                    <li key={s.id} className={cn("border-b border-neutral-50", checked.has(s.id) && "bg-orange-50/40")}>
                      <label className="flex cursor-pointer items-center gap-3 px-5 py-2.5">
                        <input
                          type="checkbox"
                          checked={checked.has(s.id)}
                          onChange={() =>
                            setChecked((prev) => {
                              const next = new Set(prev);
                              if (next.has(s.id)) next.delete(s.id);
                              else next.add(s.id);
                              return next;
                            })
                          }
                          className="size-4 accent-orange-500"
                        />
                        <span className="flex size-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-orange-100 to-pink-100 text-[10px] font-bold text-orange-700">
                          {initials(s.fullName)}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-[13px] font-semibold text-neutral-800">{s.fullName}</span>
                          <span className="font-mono text-[11px] text-orange-600">{s.studentCode}</span>
                        </span>
                        <span className="text-[11px] capitalize text-neutral-400">{s.gender}</span>
                      </label>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </Card>

          {/* Target + action */}
          <div className="space-y-4">
            <Card className="border-orange-100 bg-gradient-to-br from-orange-50/70 to-pink-50/40 p-5 sm:p-6">
              <h3 className="flex items-center gap-2 font-display text-sm font-bold text-neutral-900">
                <ArrowUpRight className="size-4 text-orange-500" aria-hidden />
                Promote {checked.size} student{checked.size === 1 ? "" : "s"} to…
              </h3>
              <div className="mt-4 space-y-3">
                <div>
                  <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Target class</label>
                  <select value={targetClassId} onChange={(e) => setTargetClassId(e.target.value)} className={inputClasses}>
                    <option value="">Choose class…</option>
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Target academic year</label>
                  <select value={targetYearId} onChange={(e) => setTargetYearId(e.target.value)} className={inputClasses}>
                    <option value="">Choose year…</option>
                    {years.map((y) => (
                      <option key={y.id} value={y.id} disabled={y.isArchived}>
                        {y.name}{y.isArchived ? " — archived" : ""}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">
                    History note <span className="font-normal text-neutral-400">(optional)</span>
                  </label>
                  <input value={note} onChange={(e) => setNote(e.target.value)} maxLength={200} placeholder="e.g. End-of-year mass promotion" className={inputClasses} />
                </div>
                <button
                  type="button"
                  disabled={pending || checked.size === 0 || !targetClassId || !targetYearId}
                  onClick={promote}
                  className="w-full rounded-xl bg-orange-500 px-5 py-3 text-sm font-bold text-white shadow-[0_8px_20px_-8px_rgba(249,115,22,0.7)] transition-colors hover:bg-orange-600 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {pending ? "Promoting…" : `Promote ${checked.size} student${checked.size === 1 ? "" : "s"}`}
                </button>
                <p className="text-[11px] leading-relaxed text-neutral-500">
                  Each student is moved in its own transaction: history written, current class and year
                  updated, IDs and QR tokens preserved, audit events recorded. Students that fail
                  validation are skipped and listed below.
                </p>
              </div>
            </Card>

            {result ? (
              <Card className="p-5 sm:p-6">
                {result.error ? <Alert>{result.error}</Alert> : null}
                {result.promoted && result.promoted.length > 0 ? (
                  <div>
                    <h4 className="flex items-center gap-2 text-sm font-bold text-emerald-700">
                      <CheckCircle2 className="size-4" aria-hidden /> Promoted ({result.promoted.length})
                    </h4>
                    <ul className="mt-2 max-h-36 space-y-1 overflow-y-auto text-xs text-neutral-600">
                      {result.promoted.map((p) => (
                        <li key={p.studentCode}>
                          <span className="font-mono font-semibold text-orange-600">{p.studentCode}</span> — {p.fullName}
                        </li>
                      ))}
                    </ul>
                  </div>
                ) : null}
                {result.failed && result.failed.length > 0 ? (
                  <div className={result.promoted && result.promoted.length > 0 ? "mt-4" : ""}>
                    <h4 className="flex items-center gap-2 text-sm font-bold text-rose-700">
                      <AlertTriangle className="size-4" aria-hidden /> Skipped ({result.failed.length})
                    </h4>
                    <ul className="mt-2 max-h-36 space-y-1 overflow-y-auto text-xs text-neutral-600">
                      {result.failed.map((f) => (
                        <li key={f.studentCode + f.fullName}>
                          <span className="font-mono font-semibold">{f.studentCode}</span> — {f.fullName}:{" "}
                          <span className="text-rose-600">{f.reason}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ) : null}
              </Card>
            ) : null}
          </div>
        </div>
      ) : (
        <Card className="flex flex-col items-center px-6 py-16 text-center">
          <ArrowUpRight className="size-9 text-orange-200" aria-hidden />
          <p className="mt-3 text-sm font-medium text-neutral-500">
            Choose a source class and academic year above to load the students eligible for promotion.
          </p>
        </Card>
      )}
    </div>
  );
}
