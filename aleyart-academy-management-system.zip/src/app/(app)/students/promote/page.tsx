import { and, asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { academicYears, classes, students } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { PageHeader } from "@/components/page-header";
import { BulkPromoteClient, type BulkStudent } from "./bulk-promote-client";

export const dynamic = "force-dynamic";

export const metadata = { title: "Bulk Promotion" };

export default async function BulkPromotePage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  await requirePermission("students.promote");
  const sp = await searchParams;
  const sourceClassId = typeof sp.classId === "string" ? sp.classId : "";
  const sourceYearId = typeof sp.yearId === "string" ? sp.yearId : "";

  const [classRows, yearRows] = await Promise.all([
    db.select().from(classes).orderBy(asc(classes.sortOrder)),
    db.select().from(academicYears).orderBy(asc(academicYears.name)),
  ]);

  let eligible: BulkStudent[] = [];
  if (sourceClassId && sourceYearId) {
    const rows = await db
      .select()
      .from(students)
      .where(
        and(
          eq(students.classId, sourceClassId),
          eq(students.currentAcademicYearId, sourceYearId),
          eq(students.status, "active"),
        ),
      )
      .orderBy(asc(students.fullName));
    eligible = rows.map((s) => ({
      id: s.id,
      studentCode: s.studentCode,
      fullName: s.fullName,
      gender: s.gender,
    }));
  }

  const currentYear = yearRows.find((y) => y.isCurrent);

  return (
    <div className="anim-fade-up space-y-6">
      <PageHeader
        title="Bulk Promotion"
        description="Move an entire class to the next class and academic year in one audited, transactional sweep. Permanent Student IDs and QR tokens are preserved for every student."
      />

      <BulkPromoteClient
        classes={classRows.map((c) => ({ id: c.id, name: c.name, sortOrder: c.sortOrder }))}
        years={yearRows.map((y) => ({ id: y.id, name: y.name, isArchived: y.isArchived }))}
        eligible={eligible}
        sourceClassId={sourceClassId}
        sourceYearId={sourceYearId}
        defaultTargetYearId={
          yearRows.find((y) => {
            if (!currentYear) return false;
            const start = Number(currentYear.name.slice(0, 4));
            return y.name === `${start + 1}/${start + 2}`;
          })?.id ??
          currentYear?.id ??
          ""
        }
        totalEligible={eligible.length}
      />
    </div>
  );
}
