"use client";

import { useActionState, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ImagePlus, Save, Trash2 } from "lucide-react";
import { createStudentAction, updateStudentAction } from "@/lib/actions/student-actions";
import type { FormState } from "@/lib/actions/auth-actions";
import { MAX_CREST_BYTES } from "@/lib/upload-constants";
import { Alert, Field, inputClasses } from "@/components/ui";
import { SubmitButton } from "@/components/ui-client";

export interface StudentFormDefaults {
  firstName: string;
  middleName: string;
  lastName: string;
  gender: string;
  dateOfBirth: string;
  admissionNumber: string;
  classId: string;
  academicYearId: string;
  admissionDate: string;
  guardianName: string;
  guardianRelation: string;
  guardianPhone: string;
  contactPhone: string;
  address: string;
  notes: string;
}

interface Opts {
  id: string;
  name: string;
}

export function StudentForm({
  mode,
  studentId,
  defaults,
  classes,
  years,
  classLabel,
  yearLabel,
  photoUrl,
}: {
  mode: "create" | "edit";
  studentId?: string;
  defaults: StudentFormDefaults;
  classes: Opts[];
  years: Opts[];
  classLabel?: string;
  yearLabel?: string;
  photoUrl?: string | null;
}) {
  const action =
    mode === "create"
      ? createStudentAction
      : updateStudentAction.bind(null, studentId ?? "");
  const [state, formAction] = useActionState<(FormState & { studentId?: string }) | null, FormData>(action, null);
  const [preview, setPreview] = useState<string | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    if (state?.ok && mode === "create" && state.studentId) {
      router.push(`/students/${state.studentId}?created=1`);
    }
  }, [state, mode, router]);

  useEffect(() => () => { if (preview) URL.revokeObjectURL(preview); }, [preview]);

  function pickPhoto(file: File | undefined) {
    if (!file) return;
    if (file.size > MAX_CREST_BYTES) {
      setFileError(`"${file.name}" exceeds the 2 MB photo limit.`);
      return;
    }
    setFileError(null);
    if (preview) URL.revokeObjectURL(preview);
    setPreview(URL.createObjectURL(file));
  }

  const isEdit = mode === "edit";

  return (
    <form action={formAction} className="space-y-7" autoComplete="off">
      {state?.error ? <Alert>{state.error}</Alert> : null}
      {state?.ok && isEdit ? (
        <Alert tone="success">Student record updated. (Student ID and QR token are untouched.)</Alert>
      ) : null}

      {/* Identity */}
      <section>
        <h3 className="mb-4 text-[11px] font-bold uppercase tracking-[0.15em] text-orange-500">
          Student identity
        </h3>
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="First name *">
            <input name="firstName" required maxLength={80} defaultValue={defaults.firstName} className={inputClasses} placeholder="e.g. Ama" />
          </Field>
          <Field label="Middle name">
            <input name="middleName" maxLength={80} defaultValue={defaults.middleName} className={inputClasses} placeholder="(optional)" />
          </Field>
          <Field label="Last name *">
            <input name="lastName" required maxLength={80} defaultValue={defaults.lastName} className={inputClasses} placeholder="e.g. Serwaa" />
          </Field>
          <Field label="Gender *">
            <select name="gender" required defaultValue={defaults.gender} className={inputClasses}>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </Field>
          <Field label="Date of birth">
            <input name="dateOfBirth" type="date" defaultValue={defaults.dateOfBirth} className={inputClasses} />
          </Field>
          <Field label="Admission number" hint={isEdit ? undefined : "Leave blank to auto-generate (ADM-YYYY-####)."}>
            <input name="admissionNumber" maxLength={30} defaultValue={defaults.admissionNumber} className={inputClasses} placeholder={isEdit ? defaults.admissionNumber : "auto if blank"} />
          </Field>
        </div>
      </section>

      {/* Admission */}
      <section>
        <h3 className="mb-4 text-[11px] font-bold uppercase tracking-[0.15em] text-orange-500">
          Admission
        </h3>
        <div className="grid gap-4 sm:grid-cols-3">
          {isEdit ? (
            <>
              <input type="hidden" name="classId" value={defaults.classId} />
              <input type="hidden" name="academicYearId" value={defaults.academicYearId} />
              <div>
                <span className="mb-1.5 block text-[13px] font-semibold text-neutral-700">Current class</span>
                <p className="rounded-xl border border-neutral-100 bg-neutral-50 px-3.5 py-2.5 text-sm font-semibold text-neutral-700">
                  {classLabel ?? "—"}
                </p>
              </div>
              <div>
                <span className="mb-1.5 block text-[13px] font-semibold text-neutral-700">Current academic year</span>
                <p className="rounded-xl border border-neutral-100 bg-neutral-50 px-3.5 py-2.5 text-sm font-semibold text-neutral-700">
                  {yearLabel ?? "—"}
                </p>
              </div>
              <p className="self-end text-xs leading-relaxed text-neutral-400">
                Class and year changes must go through <b className="text-orange-600">Promote</b> on the profile page so academic history is recorded.
              </p>
            </>
          ) : (
            <>
              <Field label="Class admitted into *">
                <select name="classId" required defaultValue={defaults.classId} className={inputClasses}>
                  <option value="" disabled>Choose class…</option>
                  {classes.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </Field>
              <Field label="Academic year *">
                <select name="academicYearId" required defaultValue={defaults.academicYearId} className={inputClasses}>
                  <option value="" disabled>Choose year…</option>
                  {years.map((y) => (
                    <option key={y.id} value={y.id}>{y.name}</option>
                  ))}
                </select>
              </Field>
              <Field label="Admission date" hint="The permanent Student ID is built from this year (ALA-YYYY-####).">
                <input name="admissionDate" type="date" defaultValue={defaults.admissionDate} className={inputClasses} />
              </Field>
            </>
          )}
        </div>
      </section>

      {/* Photo */}
      <section>
        <h3 className="mb-4 text-[11px] font-bold uppercase tracking-[0.15em] text-orange-500">
          Student photo
        </h3>
        {fileError ? <Alert className="mb-3">{fileError}</Alert> : null}
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex size-28 items-center justify-center overflow-hidden rounded-2xl border-2 border-dashed border-neutral-200 bg-neutral-50">
            {preview ?? photoUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={preview ?? photoUrl!} alt="Student photo preview" className="size-full object-cover" />
            ) : (
              <ImagePlus className="size-6 text-neutral-300" aria-hidden />
            )}
          </div>
          <div className="space-y-2">
            <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-neutral-200 bg-white px-4 py-2.5 text-sm font-semibold text-neutral-700 transition-colors hover:border-orange-300 hover:text-orange-600">
              <ImagePlus className="size-4" aria-hidden />
              {preview ? "Change photo" : photoUrl ? "Replace photo" : "Choose photo"}
              <input
                type="file"
                name="photo"
                accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                className="hidden"
                onChange={(e) => pickPhoto(e.target.files?.[0])}
              />
            </label>
            {preview ? (
              <button
                type="button"
                onClick={() => {
                  setPreview(null);
                  const input = document.querySelector<HTMLInputElement>('input[name="photo"]');
                  if (input) input.value = "";
                }}
                className="flex items-center gap-1.5 text-xs font-semibold text-neutral-400 hover:text-rose-600"
              >
                <Trash2 className="size-3.5" aria-hidden /> Remove selected photo
              </button>
            ) : null}
            <p className="text-xs text-neutral-400">JPG, JPEG, PNG or WEBP · max 2 MB. Shown on the profile, ID card and QR verification page.</p>
          </div>
        </div>
      </section>

      {/* Guardian & contact */}
      <section>
        <h3 className="mb-4 text-[11px] font-bold uppercase tracking-[0.15em] text-orange-500">
          Guardian & contact <span className="ml-2 font-medium normal-case tracking-normal text-rose-400">(private — never shown on public QR page)</span>
        </h3>
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Guardian / parent name">
            <input name="guardianName" maxLength={160} defaultValue={defaults.guardianName} className={inputClasses} />
          </Field>
          <Field label="Relationship">
            <input name="guardianRelation" maxLength={60} defaultValue={defaults.guardianRelation} className={inputClasses} placeholder="e.g. Mother" />
          </Field>
          <Field label="Guardian phone">
            <input name="guardianPhone" maxLength={40} inputMode="tel" defaultValue={defaults.guardianPhone} className={inputClasses} placeholder="e.g. 0553797233" />
          </Field>
          <Field label="Contact phone (student home)">
            <input name="contactPhone" maxLength={40} inputMode="tel" defaultValue={defaults.contactPhone} className={inputClasses} />
          </Field>
          <Field label="Home address" className="sm:col-span-2">
            <input name="address" maxLength={500} defaultValue={defaults.address} className={inputClasses} placeholder="House, street, area" />
          </Field>
        </div>
      </section>

      {/* Notes */}
      <section>
        <h3 className="mb-4 text-[11px] font-bold uppercase tracking-[0.15em] text-orange-500">
          Staff notes <span className="ml-2 font-medium normal-case tracking-normal text-rose-400">(confidential)</span>
        </h3>
        <textarea
          name="notes"
          rows={3}
          maxLength={2000}
          defaultValue={defaults.notes}
          className={inputClasses}
          placeholder="Internal notes — health considerations, special arrangements…"
        />
      </section>

      <div className="flex items-center justify-end gap-2 border-t border-neutral-100 pt-5">
        <button type="button" onClick={() => router.back()} className="rounded-xl px-4 py-2.5 text-sm font-semibold text-neutral-500 transition-colors hover:bg-neutral-100">
          Cancel
        </button>
        <SubmitButton pendingText={isEdit ? "Saving…" : "Admitting student…"}>
          <Save className="size-4" aria-hidden />
          {isEdit ? "Save changes" : "Admit student & issue ID"}
        </SubmitButton>
      </div>
    </form>
  );
}
