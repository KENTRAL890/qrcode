"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Eye,
  Pencil,
  Archive,
  ArchiveRestore,
  IdCard,
  Printer,
  ChevronLeft,
  ChevronRight,
  Users as UsersIcon,
} from "lucide-react";
import { archiveStudentAction, restoreStudentAction } from "@/lib/actions/student-actions";
import { Badge, Card } from "@/components/ui";
import { initials } from "@/lib/format";
import { cn } from "@/lib/utils";

export interface DirectoryRow {
  id: string;
  studentCode: string;
  admissionNumber: string;
  fullName: string;
  gender: string;
  status: string;
  photoUrl: string | null;
  className: string;
  yearName: string;
}

const STATUS_TONE: Record<string, "green" | "amber" | "neutral" | "rose"> = {
  active: "green",
  inactive: "amber",
  graduated: "neutral",
  archived: "rose",
};

export function DirectoryClient({
  rows,
  canManage,
  page,
  totalPages,
  pageHref,
}: {
  rows: DirectoryRow[];
  canManage: boolean;
  page: number;
  totalPages: number;
  pageHref: (p: number) => string;
}) {
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [message, setMessage] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const allSelected = rows.length > 0 && rows.every((r) => selected.has(r.id));

  function toggleAll() {
    setSelected((prev) => {
      const next = new Set(prev);
      if (rows.every((r) => next.has(r.id))) rows.forEach((r) => next.delete(r.id));
      else rows.forEach((r) => next.add(r.id));
      return next;
    });
  }

  function toggleOne(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function archive(id: string, restore: boolean) {
    startTransition(async () => {
      const r = restore ? await restoreStudentAction(id) : await archiveStudentAction(id);
      setMessage(r.error ?? null);
      if (!r.error) router.refresh();
    });
  }

  return (
    <div className="space-y-3">
      {message ? (
        <p className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-2.5 text-xs font-medium text-rose-700">{message}</p>
      ) : null}

      {rows.length > 0 ? (
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-xs text-neutral-400">
            {selected.size > 0 ? `${selected.size} selected` : "Tick students to batch-print ID cards"}
          </p>
          <button
            type="button"
            disabled={selected.size === 0}
            onClick={() => router.push(`/students/cards/print?ids=${Array.from(selected).join(",")}`)}
            className={cn(
              "inline-flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-bold transition-all",
              selected.size > 0
                ? "bg-neutral-900 text-white hover:bg-neutral-800"
                : "cursor-not-allowed bg-neutral-100 text-neutral-300",
            )}
          >
            <Printer className="size-3.5" aria-hidden />
            Print selected ID cards ({selected.size})
          </button>
        </div>
      ) : null}

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[880px] text-left text-sm">
            <thead>
              <tr className="border-b border-neutral-100 bg-neutral-50/60 text-[11px] uppercase tracking-wider text-neutral-400">
                <th className="w-10 px-4 py-3.5">
                  <input
                    type="checkbox"
                    checked={allSelected}
                    onChange={toggleAll}
                    className="size-4 accent-orange-500"
                    aria-label="Select all students on this page"
                  />
                </th>
                <th className="px-3 py-3.5 font-semibold">Student</th>
                <th className="px-3 py-3.5 font-semibold">Student ID</th>
                <th className="px-3 py-3.5 font-semibold">Adm. No.</th>
                <th className="px-3 py-3.5 font-semibold">Class</th>
                <th className="px-3 py-3.5 font-semibold">Year</th>
                <th className="px-3 py-3.5 font-semibold">Status</th>
                <th className="px-4 py-3.5 text-right font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr
                  key={row.id}
                  className={cn(
                    "border-b border-neutral-50 transition-colors hover:bg-orange-50/30",
                    selected.has(row.id) && "bg-orange-50/50",
                    row.status === "archived" && "opacity-60",
                  )}
                >
                  <td className="px-4 py-3">
                    <input
                      type="checkbox"
                      checked={selected.has(row.id)}
                      onChange={() => toggleOne(row.id)}
                      className="size-4 accent-orange-500"
                      aria-label={`Select ${row.fullName}`}
                    />
                  </td>
                  <td className="px-3 py-3">
                    <Link href={`/students/${row.id}`} className="group flex items-center gap-3">
                      {row.photoUrl ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img
                          src={row.photoUrl}
                          alt=""
                          className="size-9 shrink-0 rounded-full border border-neutral-200 object-cover"
                        />
                      ) : (
                        <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-orange-100 to-pink-100 text-[11px] font-bold text-orange-700">
                          {initials(row.fullName)}
                        </span>
                      )}
                      <span className="min-w-0">
                        <span className="block truncate text-[13.5px] font-semibold text-neutral-800 group-hover:text-orange-700">
                          {row.fullName}
                        </span>
                        <span className="block text-[10.5px] capitalize text-neutral-400">{row.gender}</span>
                      </span>
                    </Link>
                  </td>
                  <td className="px-3 py-3 font-mono text-xs font-semibold text-orange-700">{row.studentCode}</td>
                  <td className="px-3 py-3 font-mono text-[11px] text-neutral-500">{row.admissionNumber}</td>
                  <td className="px-3 py-3 text-[13px] text-neutral-700">{row.className}</td>
                  <td className="px-3 py-3 text-[13px] tabular-nums text-neutral-500">{row.yearName}</td>
                  <td className="px-3 py-3">
                    <Badge tone={STATUS_TONE[row.status] ?? "neutral"}>{row.status}</Badge>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-0.5">
                      <Link href={`/students/${row.id}`} title="View profile" className="rounded-lg p-2 text-neutral-400 transition-colors hover:bg-neutral-100 hover:text-neutral-700">
                        <Eye className="size-4" />
                      </Link>
                      <Link href={`/students/${row.id}/card`} title="Print ID card" className="rounded-lg p-2 text-neutral-400 transition-colors hover:bg-orange-50 hover:text-orange-600">
                        <IdCard className="size-4" />
                      </Link>
                      {canManage ? (
                        <>
                          <Link href={`/students/${row.id}/edit`} title="Edit record" className="rounded-lg p-2 text-neutral-400 transition-colors hover:bg-amber-50 hover:text-amber-600">
                            <Pencil className="size-4" />
                          </Link>
                          <button
                            type="button"
                            disabled={pending}
                            onClick={() => archive(row.id, row.status === "archived")}
                            title={row.status === "archived" ? "Restore student" : "Archive student"}
                            className={cn(
                              "rounded-lg p-2 transition-colors disabled:opacity-50",
                              row.status === "archived"
                                ? "text-rose-500 hover:bg-emerald-50 hover:text-emerald-600"
                                : "text-neutral-400 hover:bg-rose-50 hover:text-rose-600",
                            )}
                          >
                            {row.status === "archived" ? <ArchiveRestore className="size-4" /> : <Archive className="size-4" />}
                          </button>
                        </>
                      ) : null}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {rows.length === 0 ? (
          <div className="flex flex-col items-center px-6 py-16 text-center">
            <UsersIcon className="size-9 text-neutral-300" aria-hidden />
            <p className="mt-3 text-sm font-medium text-neutral-500">No students match the current filters.</p>
            <p className="mt-1 text-xs text-neutral-400">
              Admit the first student to issue their permanent ID and QR code.
            </p>
          </div>
        ) : null}

        <div className="flex items-center justify-between border-t border-neutral-100 px-5 py-3.5 text-xs text-neutral-500">
          <span>Page {page} of {totalPages}</span>
          <div className="flex items-center gap-2">
            <Link
              href={pageHref(Math.max(1, page - 1))}
              aria-disabled={page <= 1}
              className={cn(
                "inline-flex items-center gap-1 rounded-lg border px-2.5 py-1.5 font-semibold",
                page <= 1
                  ? "pointer-events-none border-neutral-100 text-neutral-300"
                  : "border-neutral-200 text-neutral-600 hover:border-orange-300 hover:text-orange-600",
              )}
            >
              <ChevronLeft className="size-3.5" /> Prev
            </Link>
            <Link
              href={pageHref(Math.min(totalPages, page + 1))}
              aria-disabled={page >= totalPages}
              className={cn(
                "inline-flex items-center gap-1 rounded-lg border px-2.5 py-1.5 font-semibold",
                page >= totalPages
                  ? "pointer-events-none border-neutral-100 text-neutral-300"
                  : "border-neutral-200 text-neutral-600 hover:border-orange-300 hover:text-orange-600",
              )}
            >
              Next <ChevronRight className="size-3.5" />
            </Link>
          </div>
        </div>
      </Card>
    </div>
  );
}
