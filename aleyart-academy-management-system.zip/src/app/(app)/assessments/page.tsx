import { and, asc, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  academicYears,
  assessments,
  classes,
  classSubjects,
  students,
  subjects,
  terminalReports,
  terms,
} from "@/db/schema";
import { requirePermission, userHasPermission, isSuperAdmin } from "@/lib/auth";
import { loadTeacherScope, scopeAllowsClass, scopeAllowsSubject, loadBands } from "@/lib/grading";
import { PageHeader } from "@/components/page-header";
import { Badge, Card } from "@/components/ui";
import { MarkSheetClient, type MarkSheetRow } from "./mark-sheet-client";
import { AssessmentPickers } from "./pickers";

export const dynamic = "force-dynamic";

export const metadata = { title: "Assessments" };

export default async function AssessmentsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const actor = await requirePermission("assessments.view");
  const canManage = userHasPermission(actor, "assessments.manage");
  const unrestricted = isSuperAdmin(actor) || userHasPermission(actor, "reports.publish");
  const scope = await loadTeacherScope(actor.id, unrestricted);

  const sp = await searchParams;
  const classId = typeof sp.classId === "string" ? sp.classId : "";
  const termId = typeof sp.termId === "string" ? sp.termId : "";
  const subjectId = typeof sp.subjectId === "string" ? sp.subjectId : "";

  const [allClasses, termRows] = await Promise.all([
    db.select().from(classes).where(eq(classes.isActive, true)).orderBy(asc(classes.sortOrder)),
    db
      .select({
        id: terms.id,
        name: terms.name,
        yearName: academicYears.name,
        isCurrent: terms.isCurrent,
        isArchived: academicYears.isArchived,
      })
      .from(terms)
      .innerJoin(academicYears, eq(academicYears.id, terms.academicYearId))
      .orderBy(asc(academicYears.name), asc(terms.createdAt)),
  ]);

  const classOptions = allClasses.filter((c) => scopeAllowsClass(scope, c.id));

  // Subjects assigned to the chosen class, narrowed by teacher scope
  const subjectOptions = classId
    ? (
        await db
          .select({ id: subjects.id, name: subjects.name, isActive: subjects.isActive })
          .from(classSubjects)
          .innerJoin(subjects, eq(subjects.id, classSubjects.subjectId))
          .where(and(eq(classSubjects.classId, classId), eq(subjects.isActive, true)))
          .orderBy(asc(subjects.name))
      ).filter((s) => scopeAllowsSubject(scope, classId, s.id))
    : [];

  let rows: MarkSheetRow[] = [];
  let lockedNote: string | null = null;
  let selectionValid = false;

  if (classId && termId && subjectId) {
    selectionValid =
      scopeAllowsSubject(scope, classId, subjectId) &&
      subjectOptions.some((s) => s.id === subjectId);

    if (selectionValid) {
      const term = termRows.find((t) => t.id === termId);
      const roster = await db
        .select({
          id: students.id,
          studentCode: students.studentCode,
          fullName: students.fullName,
          gender: students.gender,
        })
        .from(students)
        .where(and(eq(students.classId, classId), eq(students.status, "active")))
        .orderBy(asc(students.fullName));

      const existing = await db
        .select()
        .from(assessments)
        .where(
          and(
            eq(assessments.termId, termId),
            eq(assessments.subjectId, subjectId),
            eq(assessments.classId, classId),
          ),
        );
      const byStudent = new Map(existing.map((a) => [a.studentId, a]));

      const publishedReports = await db
        .select({ studentId: terminalReports.studentId, status: terminalReports.status })
        .from(terminalReports)
        .where(eq(terminalReports.termId, termId));
      const blocked = new Map(
        publishedReports.filter((r) => r.status !== "draft").map((r) => [r.studentId, r.status]),
      );

      rows = roster.map((s) => {
        const a = byStudent.get(s.id);
        return {
          studentId: s.id,
          studentCode: s.studentCode,
          fullName: s.fullName,
          classScore: a ? Number(a.classScore) : null,
          examScore: a ? Number(a.examScore) : null,
          total: a ? Number(a.total) : null,
          grade: a?.grade ?? null,
          remarks: a?.remarks ?? null,
          locked: blocked.has(s.id),
          lockedReason: blocked.get(s.id) ?? null,
        };
      });

      const lockedCount = rows.filter((r) => r.locked).length;
      if (lockedCount > 0) {
        lockedNote = `${lockedCount} student${lockedCount === 1 ? "" : "s"} already have a published or locked report for ${term?.name ?? "this term"} — their scores are read-only.`;
      }
    }
  }

  const bands = await loadBands("competency");

  return (
    <div className="anim-fade-up space-y-6">
      <PageHeader
        title="Assessments"
        description="Class Score (max 50) + Exam Score (max 50) = Total (100). Grades are derived server-side from the active grading scheme; teachers only see classes and subjects they are assigned to."
      >
        <div className="flex min-w-0 flex-wrap gap-1.5">
          {bands.map((b) => (
            <Badge key={b.grade} tone="orange">
              {b.grade} {b.minScore}–{b.maxScore}
            </Badge>
          ))}
        </div>
      </PageHeader>

      <AssessmentPickers
        classes={classOptions.map((c) => ({ id: c.id, name: c.name }))}
        terms={termRows
          .filter((t) => !t.isArchived)
          .map((t) => ({ id: t.id, name: `${t.yearName} · ${t.name}`, isCurrent: t.isCurrent }))}
        subjects={subjectOptions.map((s) => ({ id: s.id, name: s.name }))}
        current={{ classId, termId, subjectId }}
      />

      {classId && termId && subjectId ? (
        selectionValid ? (
          <MarkSheetClient
            rows={rows}
            classId={classId}
            termId={termId}
            subjectId={subjectId}
            canManage={canManage}
            lockedNote={lockedNote}
          />
        ) : (
          <Card className="px-6 py-10 text-center text-sm text-rose-600">
            You are not assigned to this class/subject combination.
          </Card>
        )
      ) : (
        <Card className="flex flex-col items-center px-6 py-16 text-center">
          <p className="text-sm font-medium text-neutral-500">
            Choose a class, term and subject above to open the mark sheet.
          </p>
          {classOptions.length === 0 ? (
            <p className="mt-2 text-xs text-rose-500">
              You have no class assignments yet — ask an administrator to assign you.
            </p>
          ) : null}
        </Card>
      )}
    </div>
  );
}
