"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Save, Lock, CheckCircle2, AlertTriangle } from "lucide-react";
import { saveSubjectScoresAction } from "@/lib/actions/assessment-actions";
import { Alert, Badge, Card, buttonClasses } from "@/components/ui";
import { cn } from "@/lib/utils";

export interface MarkSheetRow {
  studentId: string;
  studentCode: string;
  fullName: string;
  classScore: number | null;
  examScore: number | null;
  total: number | null;
  grade: string | null;
  remarks: string | null;
  locked: boolean;
  lockedReason: string | null;
}

interface Draft {
  classScore: string;
  examScore: string;
  remarks: string;
}

export function MarkSheetClient({
  rows,
  classId,
  termId,
  subjectId,
  canManage,
  lockedNote,
}: {
  rows: MarkSheetRow[];
  classId: string;
  termId: string;
  subjectId: string;
  canManage: boolean;
  lockedNote: string | null;
}) {
  const [drafts, setDrafts] = useState<Record<string, Draft>>(() =>
    Object.fromEntries(
      rows.map((r) => [
        r.studentId,
        {
          classScore: r.classScore !== null ? String(r.classScore) : "",
          examScore: r.examScore !== null ? String(r.examScore) : "",
          remarks: r.remarks ?? "",
        },
      ]),
    ),
  );
  const [result, setResult] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  function update(studentId: string, field: keyof Draft, value: string) {
    setDrafts((prev) => ({ ...prev, [studentId]: { ...prev[studentId], [field]: value } }));
  }

  const liveTotals = useMemo(() => {
    const out: Record<string, { total: number | null; error: string | null }> = {};
    for (const r of rows) {
      const d = drafts[r.studentId];
      if (!d || (d.classScore === "" && d.examScore === "")) {
        out[r.studentId] = { total: null, error: null };
        continue;
      }
      const cs = Number(d.classScore || 0);
      const es = Number(d.examScore || 0);
      let error: string | null = null;
      if (!Number.isFinite(cs) || cs < 0 || cs > 50) error = "Class 0–50";
      else if (!Number.isFinite(es) || es < 0 || es > 50) error = "Exam 0–50";
      out[r.studentId] = { total: error ? null : Math.round((cs + es) * 100) / 100, error };
    }
    return out;
  }, [drafts, rows]);

  const invalidCount = Object.values(liveTotals).filter((t) => t.error).length;

  function save() {
    setResult(null);
    const payload = rows
      .filter((r) => !r.locked)
      .map((r) => ({ row: r, d: drafts[r.studentId] }))
      .filter(({ d }) => d && (d.classScore !== "" || d.examScore !== ""))
      .map(({ row, d }) => ({
        studentId: row.studentId,
        classScore: d.classScore || "0",
        examScore: d.examScore || "0",
        remarks: d.remarks || null,
      }));

    if (payload.length === 0) {
      setResult({ ok: false, text: "Enter at least one score before saving." });
      return;
    }

    startTransition(async () => {
      const r = await saveSubjectScoresAction({ classId, termId, subjectId }, payload);
      if (r.error) {
        setResult({ ok: false, text: r.error });
        return;
      }
      const rejected = r.rejected?.length ?? 0;
      setResult({
        ok: rejected === 0,
        text:
          rejected === 0
            ? `Saved ${r.saved} result${r.saved === 1 ? "" : "s"}. Totals and grades were recalculated on the server.`
            : `Saved ${r.saved}; ${rejected} rejected — ${r.rejected!.map((x) => x.reason).join("; ")}`,
      });
      router.refresh();
    });
  }

  if (rows.length === 0) {
    return (
      <Card className="px-6 py-14 text-center">
        <p className="text-sm text-neutral-500">No active students in this class.</p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {lockedNote ? <Alert tone="info">{lockedNote}</Alert> : null}
      {result ? <Alert tone={result.ok ? "success" : "error"}>{result.text}</Alert> : null}

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[820px] text-left text-sm">
            <thead>
              <tr className="border-b border-neutral-100 bg-neutral-50/60 text-[11px] uppercase tracking-wider text-neutral-400">
                <th className="px-5 py-3.5 font-semibold">Student</th>
                <th className="w-28 px-3 py-3.5 text-center font-semibold">Class /50</th>
                <th className="w-28 px-3 py-3.5 text-center font-semibold">Exam /50</th>
                <th className="w-24 px-3 py-3.5 text-center font-semibold">Total</th>
                <th className="w-20 px-3 py-3.5 text-center font-semibold">Grade</th>
                <th className="px-3 py-3.5 font-semibold">Remarks</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const live = liveTotals[r.studentId];
                const d = drafts[r.studentId];
                const disabled = !canManage || r.locked;
                return (
                  <tr
                    key={r.studentId}
                    className={cn(
                      "border-b border-neutral-50 transition-colors",
                      r.locked ? "bg-neutral-50/70" : "hover:bg-orange-50/20",
                    )}
                  >
                    <td className="px-5 py-2.5">
                      <p className="flex items-center gap-1.5 text-[13.5px] font-semibold text-neutral-800">
                        {r.locked ? <Lock className="size-3 text-neutral-400" aria-hidden /> : null}
                        {r.fullName}
                      </p>
                      <p className="font-mono text-[11px] text-orange-600">{r.studentCode}</p>
                    </td>
                    <td className="px-3 py-2.5">
                      <input
                        type="number"
                        min={0}
                        max={50}
                        step="0.5"
                        inputMode="decimal"
                        disabled={disabled}
                        value={d?.classScore ?? ""}
                        onChange={(e) => update(r.studentId, "classScore", e.target.value)}
                        className={cn(
                          "w-full rounded-lg border px-2 py-1.5 text-center text-sm tabular-nums transition-colors focus:outline-none",
                          live?.error?.startsWith("Class")
                            ? "border-rose-300 bg-rose-50 text-rose-700"
                            : "border-neutral-200 focus:border-orange-400",
                          disabled && "cursor-not-allowed bg-neutral-100 text-neutral-400",
                        )}
                      />
                    </td>
                    <td className="px-3 py-2.5">
                      <input
                        type="number"
                        min={0}
                        max={50}
                        step="0.5"
                        inputMode="decimal"
                        disabled={disabled}
                        value={d?.examScore ?? ""}
                        onChange={(e) => update(r.studentId, "examScore", e.target.value)}
                        className={cn(
                          "w-full rounded-lg border px-2 py-1.5 text-center text-sm tabular-nums transition-colors focus:outline-none",
                          live?.error?.startsWith("Exam")
                            ? "border-rose-300 bg-rose-50 text-rose-700"
                            : "border-neutral-200 focus:border-orange-400",
                          disabled && "cursor-not-allowed bg-neutral-100 text-neutral-400",
                        )}
                      />
                    </td>
                    <td className="px-3 py-2.5 text-center">
                      {live?.error ? (
                        <span className="text-[11px] font-bold text-rose-600">{live.error}</span>
                      ) : (
                        <span className="text-sm font-bold tabular-nums text-neutral-800">
                          {live?.total !== null && live?.total !== undefined
                            ? live.total.toFixed(1)
                            : r.total !== null
                              ? r.total.toFixed(1)
                              : "—"}
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-2.5 text-center">
                      {r.grade ? <Badge tone="orange">{r.grade}</Badge> : <span className="text-neutral-300">—</span>}
                    </td>
                    <td className="px-3 py-2.5">
                      <input
                        type="text"
                        maxLength={200}
                        disabled={disabled}
                        value={d?.remarks ?? ""}
                        placeholder={r.locked ? r.lockedReason ?? "" : "auto from grade"}
                        onChange={(e) => update(r.studentId, "remarks", e.target.value)}
                        className={cn(
                          "w-full rounded-lg border border-neutral-200 px-2.5 py-1.5 text-xs transition-colors focus:border-orange-400 focus:outline-none",
                          disabled && "cursor-not-allowed bg-neutral-100 text-neutral-400",
                        )}
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {canManage ? (
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-neutral-100 bg-neutral-50/50 px-5 py-3.5">
            <p className="flex items-center gap-1.5 text-xs text-neutral-500">
              {invalidCount > 0 ? (
                <>
                  <AlertTriangle className="size-3.5 text-rose-500" aria-hidden />
                  <span className="text-rose-600">{invalidCount} row(s) out of range</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="size-3.5 text-emerald-500" aria-hidden />
                  Scores are re-validated and graded on the server when saved.
                </>
              )}
            </p>
            <button
              type="button"
              onClick={save}
              disabled={pending || invalidCount > 0}
              className={buttonClasses("primary")}
            >
              <Save className="size-4" aria-hidden />
              {pending ? "Saving…" : "Save mark sheet"}
            </button>
          </div>
        ) : null}
      </Card>
    </div>
  );
}
