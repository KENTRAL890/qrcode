"use client";

import { useRouter } from "next/navigation";
import { ClipboardList } from "lucide-react";
import { Card, inputClasses, buttonClasses } from "@/components/ui";

export function AssessmentPickers({
  classes,
  terms,
  subjects,
  current,
}: {
  classes: Array<{ id: string; name: string }>;
  terms: Array<{ id: string; name: string; isCurrent: boolean }>;
  subjects: Array<{ id: string; name: string }>;
  current: { classId: string; termId: string; subjectId: string };
}) {
  const router = useRouter();

  function go(next: Partial<typeof current>) {
    const merged = { ...current, ...next };
    const params = new URLSearchParams();
    if (merged.classId) params.set("classId", merged.classId);
    if (merged.termId) params.set("termId", merged.termId);
    if (merged.subjectId) params.set("subjectId", merged.subjectId);
    router.push(`/assessments?${params.toString()}`);
  }

  return (
    <Card className="p-4">
      <div className="flex flex-wrap items-end gap-3">
        <div className="min-w-40 flex-1">
          <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">Class</label>
          <select
            value={current.classId}
            onChange={(e) => go({ classId: e.target.value, subjectId: "" })}
            className={inputClasses}
          >
            <option value="">Choose class…</option>
            {classes.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
        <div className="min-w-48 flex-1">
          <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">Term</label>
          <select value={current.termId} onChange={(e) => go({ termId: e.target.value })} className={inputClasses}>
            <option value="">Choose term…</option>
            {terms.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}{t.isCurrent ? " (current)" : ""}
              </option>
            ))}
          </select>
        </div>
        <div className="min-w-44 flex-1">
          <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">Subject</label>
          <select
            value={current.subjectId}
            onChange={(e) => go({ subjectId: e.target.value })}
            disabled={!current.classId}
            className={inputClasses}
          >
            <option value="">{current.classId ? "Choose subject…" : "Pick a class first"}</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>
        <span className={buttonClasses("secondary", "pointer-events-none")}>
          <ClipboardList className="size-4" aria-hidden /> Mark sheet
        </span>
      </div>
    </Card>
  );
}
