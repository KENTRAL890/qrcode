import Link from "next/link";
import { asc, desc, eq, sql, count as dcount } from "drizzle-orm";
import {
  GraduationCap,
  UserRound,
  School as SchoolIcon,
  FileCheck2,
  Wallet,
  AlertCircle,
  CalendarRange,
  LogIn,
  LogOut,
  Settings2,
  UserCog,
  BookOpen,
  Activity,
  ArrowRight,
} from "lucide-react";
import { db } from "@/db";
import {
  academicYears,
  auditLogs,
  classes,
  studentFeeAccounts,
  feePayments,
  roles,
  students,
  terminalReports,
  terms,
  userRoles,
  users,
} from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { PageHeader } from "@/components/page-header";
import { Card, Badge } from "@/components/ui";
import { formatMoney, timeAgo } from "@/lib/format";
import { cn } from "@/lib/utils";

export const dynamic = "force-dynamic";

export const metadata = { title: "Dashboard" };

const ACTION_META: Record<string, { icon: typeof LogIn; tone: string }> = {
  "auth.login": { icon: LogIn, tone: "text-emerald-600 bg-emerald-50" },
  "auth.logout": { icon: LogOut, tone: "text-neutral-500 bg-neutral-100" },
  "settings.school_name_changed": { icon: Settings2, tone: "text-orange-600 bg-orange-50" },
  "settings.motto_changed": { icon: Settings2, tone: "text-orange-600 bg-orange-50" },
  "settings.crest_changed": { icon: Settings2, tone: "text-pink-600 bg-pink-50" },
  "settings.updated": { icon: Settings2, tone: "text-orange-600 bg-orange-50" },
};

function actionIcon(action: string) {
  if (ACTION_META[action]) return ACTION_META[action];
  if (action.startsWith("auth.")) return { icon: LogIn, tone: "text-neutral-500 bg-neutral-100" };
  if (action.startsWith("user.")) return { icon: UserCog, tone: "text-pink-600 bg-pink-50" };
  if (action.startsWith("subject") || action.startsWith("class"))
    return { icon: BookOpen, tone: "text-orange-600 bg-orange-50" };
  if (action.startsWith("academic") || action.startsWith("term"))
    return { icon: CalendarRange, tone: "text-amber-600 bg-amber-50" };
  return { icon: Activity, tone: "text-neutral-500 bg-neutral-100" };
}

export default async function DashboardPage() {
  const user = await requirePermission("dashboard.view");

  const [
    [{ value: totalStudents }],
    perClass,
    [{ value: totalTeachers }],
    [currentYear],
    [currentTerm],
    [{ value: publishedReports }],
    [{ sum: feesCollected }],
    [{ sum: outstandingFees }],
    recentActivity,
    [{ value: activeClasses }],
  ] = await Promise.all([
    db.select({ value: dcount() }).from(students).where(eq(students.status, "active")),
    db
      .select({ id: classes.id, name: classes.name, count: sql<number>`count(${students.id})` })
      .from(classes)
      .leftJoin(students, sql`${students.classId} = ${classes.id} and ${students.status} = 'active'`)
      .groupBy(classes.id, classes.name, classes.sortOrder)
      .orderBy(asc(classes.sortOrder)),
    db
      .select({ value: sql<number>`count(distinct ${userRoles.userId})` })
      .from(userRoles)
      .innerJoin(roles, eq(roles.id, userRoles.roleId))
      .innerJoin(users, eq(users.id, userRoles.userId))
      .where(sql`${roles.name} = 'teacher' and ${users.status} = 'active'`),
    db.select().from(academicYears).where(eq(academicYears.isCurrent, true)).limit(1),
    db.select().from(terms).where(eq(terms.isCurrent, true)).limit(1),
    db.select({ value: dcount() }).from(terminalReports).where(eq(terminalReports.status, "published")),
    db
      .select({ sum: sql<string | null>`coalesce(sum(${feePayments.amount}), 0)` })
      .from(feePayments)
      .where(eq(feePayments.status, "active")),
    db
      .select({ sum: sql<string | null>`coalesce(sum(${studentFeeAccounts.outstanding}), 0)` })
      .from(studentFeeAccounts),
    db
      .select({
        id: auditLogs.id,
        action: auditLogs.action,
        entity: auditLogs.entity,
        createdAt: auditLogs.createdAt,
        username: users.username,
        fullName: users.fullName,
      })
      .from(auditLogs)
      .leftJoin(users, eq(users.id, auditLogs.userId))
      .orderBy(desc(auditLogs.createdAt))
      .limit(8),
    db.select({ value: dcount() }).from(classes).where(eq(classes.isActive, true)),
  ]);

  const maxEnrollment = Math.max(1, ...perClass.map((c) => c.count));
  const collected = Number(feesCollected ?? 0);
  const outstanding = Number(outstandingFees ?? 0);
  const totalFees = collected + outstanding;
  const collectedPct = totalFees > 0 ? Math.round((collected / totalFees) * 100) : 0;

  const stats = [
    { label: "Total Students", value: String(totalStudents), icon: GraduationCap, tone: "bg-orange-100 text-orange-600", sub: totalStudents === 0 ? "No enrolments yet" : "actively enrolled" },
    { label: "Teachers", value: String(totalTeachers), icon: UserRound, tone: "bg-pink-100 text-pink-600", sub: totalTeachers === 0 ? "No teacher accounts yet" : "active staff" },
    { label: "Classes", value: String(activeClasses), icon: SchoolIcon, tone: "bg-amber-100 text-amber-600", sub: "Basic 1 – Basic 9" },
    { label: "Published Reports", value: String(publishedReports), icon: FileCheck2, tone: "bg-emerald-100 text-emerald-600", sub: publishedReports === 0 ? "None published yet" : "terminal reports" },
    { label: "Fees Collected", value: formatMoney(collected), icon: Wallet, tone: "bg-orange-100 text-orange-600", sub: "active payments received" },
    { label: "Outstanding Fees", value: formatMoney(outstanding), icon: AlertCircle, tone: "bg-rose-100 text-rose-600", sub: "unpaid balances" },
  ];

  return (
    <div className="anim-fade-up space-y-6">
      <PageHeader
        title={`Welcome, ${user.fullName.split(" ")[0]}`}
        description="Live overview of the school — every figure below is read directly from the database."
      >
        <div className="flex items-center gap-2">
          {currentYear ? (
            <Badge tone="orange" className="!px-3 !py-1.5 !text-xs">
              <CalendarRange className="size-3.5" aria-hidden />
              {currentYear.name}
            </Badge>
          ) : (
            <Badge tone="rose">No academic year set</Badge>
          )}
          {currentTerm ? <Badge tone="pink" className="!px-3 !py-1.5 !text-xs">{currentTerm.name}</Badge> : null}
        </div>
      </PageHeader>

      {/* Stat cards */}
      <div className="grid grid-cols-1 gap-4 min-[480px]:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-6">
        {stats.map(({ label, value, icon: Icon, tone, sub }) => (
          <Card key={label} className="group p-5 transition-transform duration-200 hover:-translate-y-0.5">
            <div className="flex items-start justify-between gap-2">
              <p className="text-[12.5px] font-semibold uppercase tracking-wide text-neutral-400">
                {label}
              </p>
              <span className={cn("rounded-xl p-2 transition-transform duration-200 group-hover:scale-110", tone)}>
                <Icon className="size-4" aria-hidden />
              </span>
            </div>
            <p className="mt-2 truncate font-display text-[1.55rem] font-bold leading-none tracking-tight text-neutral-900">
              {value}
            </p>
            <p className="mt-2 truncate text-xs text-neutral-400">{sub}</p>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        {/* Enrollment by class */}
        <Card className="p-5 sm:p-6 xl:col-span-2">
          <div className="mb-5 flex items-center justify-between gap-3">
            <div>
              <h2 className="font-display text-base font-bold tracking-tight text-neutral-900">
                Students by class
              </h2>
              <p className="text-xs text-neutral-400">Basic 1 – Basic 9 · active enrolment</p>
            </div>
            <Badge tone="neutral">{totalStudents} enrolled</Badge>
          </div>

          <div className="space-y-2.5">
            {perClass.map((row) => (
              <div key={row.id} className="group grid grid-cols-[4.2rem_1fr_2.5rem] items-center gap-3">
                <span className="truncate text-[13px] font-medium text-neutral-600">{row.name}</span>
                <div className="relative h-7 overflow-hidden rounded-lg bg-neutral-100">
                  <div
                    className={cn(
                      "h-full rounded-lg bg-gradient-to-r from-orange-500 to-orange-400 transition-all duration-700",
                      row.count === 0 && "bg-none",
                    )}
                    style={{ width: `${(row.count / maxEnrollment) * 100}%` }}
                  />
                </div>
                <span className="text-right text-[13px] font-semibold tabular-nums text-neutral-700">
                  {row.count}
                </span>
              </div>
            ))}
          </div>

          {totalStudents === 0 ? (
            <p className="mt-5 rounded-xl border border-dashed border-orange-200 bg-orange-50/60 px-4 py-3 text-xs leading-relaxed text-orange-700">
              Student enrolment starts in Phase 2 — nothing has been fabricated here. Once students
              are admitted, this chart fills itself from the database automatically.
            </p>
          ) : null}
        </Card>

        {/* Fees overview + recent activity */}
        <div className="space-y-4">
          <Card className="p-5 sm:p-6">
            <h2 className="font-display text-base font-bold tracking-tight text-neutral-900">
              Fees overview
            </h2>
            <p className="text-xs text-neutral-400">Collected vs outstanding</p>
            <div className="mt-5 flex items-center gap-5">
              <div
                className="relative size-28 shrink-0 rounded-full"
                style={{
                  background:
                    totalFees > 0
                      ? `conic-gradient(#f97316 0 ${collectedPct}%, #fecdd3 ${collectedPct}% 100%)`
                      : `conic-gradient(#f5f5f4 0 100%)`,
                }}
              >
                <div className="absolute inset-[10px] flex flex-col items-center justify-center rounded-full bg-white text-center">
                  <span className="font-display text-lg font-bold text-neutral-900">
                    {totalFees > 0 ? `${collectedPct}%` : "—"}
                  </span>
                  <span className="text-[10px] font-medium uppercase tracking-wide text-neutral-400">
                    collected
                  </span>
                </div>
              </div>
              <div className="min-w-0 space-y-2.5 text-sm">
                <div className="flex items-center gap-2">
                  <span className="size-2.5 rounded-full bg-orange-500" />
                  <div>
                    <p className="font-semibold text-neutral-800">{formatMoney(collected)}</p>
                    <p className="text-[11px] text-neutral-400">Collected</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="size-2.5 rounded-full bg-rose-300" />
                  <div>
                    <p className="font-semibold text-neutral-800">{formatMoney(outstanding)}</p>
                    <p className="text-[11px] text-neutral-400">Outstanding</p>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-5 sm:p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-base font-bold tracking-tight text-neutral-900">
                Recent activity
              </h2>
              <Link
                href="/admin/audit"
                className="inline-flex items-center gap-1 text-xs font-semibold text-orange-600 hover:text-orange-700"
              >
                Audit log
                <ArrowRight className="size-3.5" aria-hidden />
              </Link>
            </div>
            {recentActivity.length === 0 ? (
              <p className="text-sm text-neutral-400">No activity recorded yet.</p>
            ) : (
              <ul className="space-y-1">
                {recentActivity.map((entry) => {
                  const meta = actionIcon(entry.action);
                  const Icon = meta.icon;
                  return (
                    <li key={entry.id} className="flex items-center gap-3 rounded-xl px-2 py-2 transition-colors hover:bg-neutral-50">
                      <span className={cn("flex size-8 shrink-0 items-center justify-center rounded-lg", meta.tone)}>
                        <Icon className="size-3.5" aria-hidden />
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13px] font-medium text-neutral-700">
                          <span className="font-semibold">{entry.fullName ?? "System"}</span>
                          <span className="text-neutral-300"> · </span>
                          <span className="text-neutral-500">{entry.action.replaceAll("_", " ")}</span>
                        </p>
                      </div>
                      <span className="shrink-0 text-[11px] tabular-nums text-neutral-400">
                        {timeAgo(entry.createdAt)}
                      </span>
                    </li>
                  );
                })}
              </ul>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
