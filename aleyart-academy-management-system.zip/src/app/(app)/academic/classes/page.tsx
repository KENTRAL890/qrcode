import { asc, sql } from "drizzle-orm";
import { GraduationCap, BookOpen, Layers } from "lucide-react";
import { db } from "@/db";
import { classes, classSubjects, students } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { PageHeader } from "@/components/page-header";
import { Badge, Card } from "@/components/ui";
import { cn } from "@/lib/utils";
import { ClassActiveToggle } from "./class-toggle";

export const dynamic = "force-dynamic";

export const metadata = { title: "Classes" };

export default async function ClassesPage() {
  const user = await requirePermission("academic.view");
  const canManage = user.permissions.has("academic.manage") || user.roles.includes("super_admin");

  const rows = await db
    .select({
      id: classes.id,
      name: classes.name,
      levelGroup: classes.levelGroup,
      isActive: classes.isActive,
      sortOrder: classes.sortOrder,
      subjectCount: sql<number>`(
        select count(*) from ${classSubjects} where ${classSubjects.classId} = ${classes.id}
      )`,
      studentCount: sql<number>`(
        select count(*) from ${students} where ${students.classId} = ${classes.id} and ${students.status} = 'active'
      )`,
    })
    .from(classes)
    .orderBy(asc(classes.sortOrder));

  return (
    <div className="anim-fade-up space-y-6">
      <PageHeader
        title="Classes"
        description="The nine official class levels of the school — Basic 1 through Basic 9 — with their live subject and enrolment counts."
      >
        <Badge tone="neutral">{rows.length} levels</Badge>
      </PageHeader>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {rows.map((klass) => (
          <Card
            key={klass.id}
            className={cn(
              "group relative overflow-hidden p-5 transition-all duration-200 hover:-translate-y-0.5",
              !klass.isActive && "opacity-70",
            )}
          >
            <div
              className={cn(
                "absolute inset-x-0 top-0 h-1 bg-gradient-to-r",
                klass.levelGroup === "lower"
                  ? "from-orange-400 to-orange-500"
                  : "from-pink-400 to-pink-500",
              )}
            />
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <span
                  className={cn(
                    "flex size-11 items-center justify-center rounded-2xl transition-transform duration-200 group-hover:scale-105",
                    klass.levelGroup === "lower"
                      ? "bg-orange-100 text-orange-600"
                      : "bg-pink-100 text-pink-600",
                  )}
                >
                  <GraduationCap className="size-5" aria-hidden />
                </span>
                <div>
                  <p className="font-display text-lg font-bold tracking-tight text-neutral-900">
                    {klass.name}
                  </p>
                  <p className="text-[11px] font-semibold uppercase tracking-wide text-neutral-400">
                    {klass.levelGroup === "lower" ? "Lower Basic" : "Upper Basic (JHS)"}
                  </p>
                </div>
              </div>
              <Badge tone={klass.isActive ? "green" : "neutral"}>
                {klass.isActive ? "Active" : "Inactive"}
              </Badge>
            </div>

            <div className="mt-5 grid grid-cols-2 gap-3">
              <div className="rounded-xl bg-neutral-50 px-3.5 py-2.5">
                <p className="flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-wide text-neutral-400">
                  <Layers className="size-3" /> Students
                </p>
                <p className="mt-0.5 font-display text-lg font-bold tabular-nums text-neutral-800">
                  {klass.studentCount}
                </p>
              </div>
              <div className="rounded-xl bg-neutral-50 px-3.5 py-2.5">
                <p className="flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-wide text-neutral-400">
                  <BookOpen className="size-3" /> Subjects
                </p>
                <p className="mt-0.5 font-display text-lg font-bold tabular-nums text-neutral-800">
                  {klass.subjectCount}
                </p>
              </div>
            </div>

            {canManage ? (
              <div className="mt-4 flex justify-end">
                <ClassActiveToggle classId={klass.id} isActive={klass.isActive} />
              </div>
            ) : null}
          </Card>
        ))}
      </div>
    </div>
  );
}
