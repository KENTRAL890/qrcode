"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { Power } from "lucide-react";
import { toggleClassActiveAction } from "@/lib/actions/academic-actions";
import { cn } from "@/lib/utils";

export function ClassActiveToggle({ classId, isActive }: { classId: string; isActive: boolean }) {
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  return (
    <button
      type="button"
      disabled={pending}
      onClick={() =>
        startTransition(async () => {
          await toggleClassActiveAction(classId);
          router.refresh();
        })
      }
      className={cn(
        "inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors disabled:opacity-60",
        isActive
          ? "border-rose-100 text-rose-600 hover:bg-rose-50"
          : "border-emerald-100 text-emerald-600 hover:bg-emerald-50",
      )}
    >
      <Power className="size-3.5" aria-hidden />
      {pending ? "Updating…" : isActive ? "Deactivate" : "Activate"}
    </button>
  );
}
