import { asc } from "drizzle-orm";
import { db } from "@/db";
import { academicYears, terms } from "@/db/schema";
import { requirePermission, userHasPermission } from "@/lib/auth";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui";
import { YearsClient, type YearWithTerms } from "./years-client";

export const dynamic = "force-dynamic";

export const metadata = { title: "Academic Years & Terms" };

export default async function AcademicYearsPage() {
  const user = await requirePermission("academic.view");
  const canManage = userHasPermission(user, "academic.manage");

  const yearRows = await db.select().from(academicYears).orderBy(asc(academicYears.name));
  const termRows = await db.select().from(terms).orderBy(asc(terms.createdAt));

  const data: YearWithTerms[] = yearRows.map((year) => ({
    id: year.id,
    name: year.name,
    startDate: year.startDate,
    endDate: year.endDate,
    isCurrent: year.isCurrent,
    isArchived: year.isArchived,
    terms: termRows
      .filter((t) => t.academicYearId === year.id)
      .map((t) => ({
        id: t.id,
        name: t.name,
        startDate: t.startDate,
        endDate: t.endDate,
        isCurrent: t.isCurrent,
      })),
  }));

  return (
    <div className="anim-fade-up space-y-6">
      <PageHeader
        title="Academic Years & Terms"
        description="Create school years (each automatically gets First, Second and Third Term). Only one year can be current; years holding historical records can only be archived, never deleted."
      >
        <Badge tone="neutral">{yearRows.length} year{yearRows.length === 1 ? "" : "s"}</Badge>
      </PageHeader>

      <YearsClient years={data} canManage={canManage} />
    </div>
  );
}
