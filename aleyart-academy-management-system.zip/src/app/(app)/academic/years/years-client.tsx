"use client";

import { useActionState, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  CalendarPlus,
  Star,
  Archive,
  ArchiveRestore,
  Trash2,
  X,
  CalendarRange,
  Check,
} from "lucide-react";
import {
  createAcademicYearAction,
  setCurrentAcademicYearAction,
  setAcademicYearArchivedAction,
  deleteAcademicYearAction,
  setCurrentTermAction,
  updateTermDatesAction,
} from "@/lib/actions/academic-actions";
import type { FormState } from "@/lib/actions/auth-actions";
import { Alert, Badge, Card, inputClasses, buttonClasses } from "@/components/ui";
import { SubmitButton } from "@/components/ui-client";
import { formatDate } from "@/lib/format";
import { cn } from "@/lib/utils";

export interface YearWithTerms {
  id: string;
  name: string;
  startDate: string | null;
  endDate: string | null;
  isCurrent: boolean;
  isArchived: boolean;
  terms: Array<{
    id: string;
    name: string;
    startDate: string | null;
    endDate: string | null;
    isCurrent: boolean;
  }>;
}

function CreateYearForm({ onDone }: { onDone: () => void }) {
  const [state, formAction] = useActionState<FormState | null, FormData>(createAcademicYearAction, null);
  const router = useRouter();
  if (state?.ok) {
    router.refresh();
    onDone();
  }
  return (
    <form action={formAction} className="space-y-4" autoComplete="off">
      {state?.error ? <Alert>{state.error}</Alert> : null}
      <div className="grid gap-4 sm:grid-cols-3">
        <div>
          <label className="mb-1.5 block text-[13px] font-semibold text-neutral-700">Year name</label>
          <input name="name" required placeholder="2026/2027" pattern="\d{4}/\d{4}" className={inputClasses} />
        </div>
        <div>
          <label className="mb-1.5 block text-[13px] font-semibold text-neutral-700">
            Starts <span className="font-normal text-neutral-400">(optional)</span>
          </label>
          <input name="startDate" type="date" className={inputClasses} />
        </div>
        <div>
          <label className="mb-1.5 block text-[13px] font-semibold text-neutral-700">
            Ends <span className="font-normal text-neutral-400">(optional)</span>
          </label>
          <input name="endDate" type="date" className={inputClasses} />
        </div>
      </div>
      <p className="text-xs text-neutral-400">
        First, Second and Third Term are created automatically with Ghana calendar defaults
        (Sep–Dec, Jan–Apr, May–Aug). Dates can be adjusted later.
      </p>
      <div className="flex items-center justify-end gap-2">
        <button type="button" onClick={onDone} className={buttonClasses("ghost")}>
          <X className="size-4" /> Cancel
        </button>
        <SubmitButton pendingText="Creating year…">
          <CalendarPlus className="size-4" /> Create academic year
        </SubmitButton>
      </div>
    </form>
  );
}

function TermCard({
  term,
  yearArchived,
  canManage,
  onMessage,
}: {
  term: YearWithTerms["terms"][number];
  yearArchived: boolean;
  canManage: boolean;
  onMessage: (m: { ok: boolean; text: string } | null) => void;
}) {
  const [start, setStart] = useState(term.startDate ?? "");
  const [end, setEnd] = useState(term.endDate ?? "");
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const dirty = start !== (term.startDate ?? "") || end !== (term.endDate ?? "");

  return (
    <div
      className={cn(
        "rounded-2xl border p-4 transition-colors",
        term.isCurrent ? "border-orange-200 bg-orange-50/50" : "border-neutral-150 bg-white",
        yearArchived && "opacity-70",
      )}
    >
      <div className="flex items-center justify-between gap-2">
        <p className="text-[13px] font-bold text-neutral-800">{term.name}</p>
        {term.isCurrent ? (
          <Badge tone="orange">
            <Check className="size-3" /> current
          </Badge>
        ) : canManage && !yearArchived ? (
          <button
            onClick={() =>
              startTransition(async () => {
                const r = await setCurrentTermAction(term.id);
                onMessage(r.error ? { ok: false, text: r.error } : { ok: true, text: `${term.name} is now the current term.` });
                if (!r.error) router.refresh();
              })
            }
            disabled={pending}
            className="text-[11px] font-semibold text-neutral-400 underline decoration-dotted underline-offset-2 transition-colors hover:text-orange-600"
          >
            Set current
          </button>
        ) : null}
      </div>

      {canManage && !yearArchived ? (
        <div className="mt-3 space-y-2">
          <div className="flex flex-col gap-2 min-[380px]:flex-row min-[380px]:items-center">
            <input
              type="date"
              value={start}
              onChange={(e) => setStart(e.target.value)}
              className="w-full min-w-0 rounded-lg border border-neutral-200 bg-white px-2 py-1.5 text-xs"
              aria-label={`${term.name} start date`}
            />
            <span className="hidden text-neutral-300 min-[380px]:inline">→</span>
            <input
              type="date"
              value={end}
              onChange={(e) => setEnd(e.target.value)}
              className="w-full min-w-0 rounded-lg border border-neutral-200 bg-white px-2 py-1.5 text-xs"
              aria-label={`${term.name} end date`}
            />
          </div>
          {dirty ? (
            <button
              onClick={() =>
                startTransition(async () => {
                  const r = await updateTermDatesAction(term.id, start || null, end || null);
                  onMessage(r.error ? { ok: false, text: r.error } : { ok: true, text: `${term.name} dates saved.` });
                  if (!r.error) router.refresh();
                })
              }
              disabled={pending}
              className="w-full rounded-lg bg-orange-500 px-2 py-1.5 text-xs font-bold text-white transition-colors hover:bg-orange-600 disabled:opacity-60"
            >
              {pending ? "Saving…" : "Save dates"}
            </button>
          ) : null}
        </div>
      ) : (
        <p className="mt-1.5 text-[11.5px] tabular-nums text-neutral-500">
          {formatDate(term.startDate)} → {formatDate(term.endDate)}
        </p>
      )}
    </div>
  );
}

export function YearsClient({ years, canManage }: { years: YearWithTerms[]; canManage: boolean }) {
  const [creating, setCreating] = useState(false);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const run = (fn: () => Promise<FormState>) =>
    startTransition(async () => {
      const r = await fn();
      setMessage(r.error ? { ok: false, text: r.error } : { ok: true, text: "Done." });
      if (!r.error) router.refresh();
    });

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-end">
        {canManage ? (
          <button onClick={() => setCreating((v) => !v)} className={buttonClasses(creating ? "secondary" : "primary")}>
            {creating ? <X className="size-4" /> : <CalendarPlus className="size-4" />}
            {creating ? "Close" : "New academic year"}
          </button>
        ) : null}
      </div>

      {message ? <Alert tone={message.ok ? "success" : "error"}>{message.text}</Alert> : null}

      {creating && canManage ? (
        <Card className="anim-fade-up p-5 sm:p-6">
          <h2 className="mb-4 font-display text-base font-bold text-neutral-900">Create academic year</h2>
          <CreateYearForm onDone={() => setCreating(false)} />
        </Card>
      ) : null}

      <div className="space-y-4">
        {years.map((year) => (
          <Card key={year.id} className={cn("p-5 sm:p-6", year.isArchived && "opacity-80")}>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex min-w-0 flex-wrap items-center gap-3">
                <span
                  className={cn(
                    "flex size-10 shrink-0 items-center justify-center rounded-xl",
                    year.isCurrent ? "bg-orange-100 text-orange-600" : "bg-neutral-100 text-neutral-400",
                  )}
                >
                  <CalendarRange className="size-5" />
                </span>
                <div>
                  <p className="font-display text-lg font-bold tracking-tight text-neutral-900">
                    {year.name}
                  </p>
                  <p className="text-xs tabular-nums text-neutral-400">
                    {formatDate(year.startDate)} → {formatDate(year.endDate)}
                  </p>
                </div>
                <div className="flex gap-1.5">
                  {year.isCurrent ? <Badge tone="orange">current year</Badge> : null}
                  {year.isArchived ? <Badge tone="neutral">archived</Badge> : null}
                </div>
              </div>

              {canManage ? (
                <div className="flex flex-wrap items-center gap-1.5">
                  {!year.isCurrent && !year.isArchived ? (
                    <button
                      onClick={() => run(() => setCurrentAcademicYearAction(year.id))}
                      disabled={pending}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-orange-200 bg-orange-50 px-3 py-1.5 text-xs font-semibold text-orange-700 transition-colors hover:bg-orange-100 disabled:opacity-60"
                    >
                      <Star className="size-3.5" /> Set current
                    </button>
                  ) : null}
                  {!year.isCurrent ? (
                    year.isArchived ? (
                      <button
                        onClick={() => run(() => setAcademicYearArchivedAction(year.id, false))}
                        disabled={pending}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-neutral-200 px-3 py-1.5 text-xs font-semibold text-neutral-600 transition-colors hover:bg-neutral-50 disabled:opacity-60"
                      >
                        <ArchiveRestore className="size-3.5" /> Unarchive
                      </button>
                    ) : (
                      <button
                        onClick={() => run(() => setAcademicYearArchivedAction(year.id, true))}
                        disabled={pending}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-neutral-200 px-3 py-1.5 text-xs font-semibold text-neutral-600 transition-colors hover:bg-neutral-50 disabled:opacity-60"
                      >
                        <Archive className="size-3.5" /> Archive
                      </button>
                    )
                  ) : null}
                  {!year.isCurrent ? (
                    <button
                      onClick={() => {
                        if (window.confirm(`Delete academic year ${year.name}? Years containing historical records cannot be deleted.`)) {
                          run(() => deleteAcademicYearAction(year.id));
                        }
                      }}
                      disabled={pending}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-rose-100 px-3 py-1.5 text-xs font-semibold text-rose-600 transition-colors hover:bg-rose-50 disabled:opacity-60"
                    >
                      <Trash2 className="size-3.5" /> Delete
                    </button>
                  ) : null}
                </div>
              ) : null}
            </div>

            <div className="mt-5 grid gap-3 sm:grid-cols-3">
              {year.terms.map((term) => (
                <TermCard
                  key={term.id}
                  term={term}
                  yearArchived={year.isArchived}
                  canManage={canManage}
                  onMessage={setMessage}
                />
              ))}
              {year.terms.length === 0 ? (
                <p className="col-span-3 rounded-xl border border-dashed border-neutral-200 px-4 py-3 text-xs text-neutral-400">
                  No terms linked to this year.
                </p>
              ) : null}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
