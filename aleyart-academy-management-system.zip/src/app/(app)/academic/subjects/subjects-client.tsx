"use client";

import { useActionState, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  BookPlus,
  BookOpen,
  ChevronDown,
  Pencil,
  Power,
  X,
  Plus,
  Sparkles,
  Check,
} from "lucide-react";
import {
  createSubjectAction,
  updateSubjectAction,
  toggleSubjectActiveAction,
  assignSubjectToClassAction,
  removeClassSubjectAction,
  toggleClassSubjectCoreAction,
} from "@/lib/actions/subject-actions";
import type { FormState } from "@/lib/actions/auth-actions";
import { Alert, Badge, Card, inputClasses, buttonClasses } from "@/components/ui";
import { SubmitButton } from "@/components/ui-client";
import { cn } from "@/lib/utils";

export interface SubjectRow {
  id: string;
  name: string;
  description: string | null;
  isActive: boolean;
  assignments: Array<{ id: string; classId: string; className: string; isCore: boolean }>;
}

interface ClassOpt {
  id: string;
  name: string;
  levelGroup: string;
}

function CreateSubjectForm({ classes, onDone }: { classes: ClassOpt[]; onDone: () => void }) {
  const [state, formAction] = useActionState<FormState | null, FormData>(createSubjectAction, null);
  const router = useRouter();
  if (state?.ok) {
    router.refresh();
    onDone();
  }
  return (
    <form action={formAction} className="space-y-5" autoComplete="off">
      {state?.error ? <Alert>{state.error}</Alert> : null}
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label className="mb-1.5 block text-[13px] font-semibold text-neutral-700">Subject name</label>
          <input name="name" required maxLength={120} className={inputClasses} placeholder="e.g. Creative Arts" />
        </div>
        <div>
          <label className="mb-1.5 block text-[13px] font-semibold text-neutral-700">
            Description <span className="font-normal text-neutral-400">(optional)</span>
          </label>
          <input name="description" maxLength={300} className={inputClasses} placeholder="Short description" />
        </div>
      </div>
      <div>
        <span className="mb-2 block text-[13px] font-semibold text-neutral-700">
          Assign to classes <span className="font-normal text-neutral-400">(optional)</span>
        </span>
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-5 lg:grid-cols-9">
          {classes.map((c) => (
            <label
              key={c.id}
              className="flex cursor-pointer items-center justify-center gap-1.5 rounded-xl border border-neutral-200 bg-neutral-50 px-2 py-2 text-xs font-semibold text-neutral-600 transition-colors has-checked:border-orange-300 has-checked:bg-orange-50 has-checked:text-orange-700"
            >
              <input type="checkbox" name="classIds" value={c.id} className="hidden" />
              {c.name}
            </label>
          ))}
        </div>
      </div>
      <label className="inline-flex items-center gap-2 text-xs font-semibold text-neutral-600">
        <input type="checkbox" name="isCore" defaultChecked className="size-3.5 accent-orange-500" />
        Assign as <span className="text-orange-600">core</span> subject (uncheck for elective)
      </label>
      <div className="flex items-center justify-end gap-2 border-t border-neutral-100 pt-4">
        <button type="button" onClick={onDone} className={buttonClasses("ghost")}>
          <X className="size-4" /> Cancel
        </button>
        <SubmitButton pendingText="Creating subject…">
          <BookPlus className="size-4" /> Create subject
        </SubmitButton>
      </div>
    </form>
  );
}

function SubjectCard({
  subject,
  classes,
  canManage,
  notify,
}: {
  subject: SubjectRow;
  classes: ClassOpt[];
  canManage: boolean;
  notify: (m: { ok: boolean; text: string } | null) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editName, setEditName] = useState(subject.name);
  const [assignClassId, setAssignClassId] = useState("");
  const [assignCore, setAssignCore] = useState(true);
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const run = (fn: () => Promise<FormState>, okText: string) =>
    startTransition(async () => {
      const r = await fn();
      notify(r.error ? { ok: false, text: r.error } : { ok: true, text: okText });
      if (!r.error) router.refresh();
    });

  const unassigned = classes.filter((c) => !subject.assignments.some((a) => a.classId === c.id));

  return (
    <Card className={cn("overflow-hidden", !subject.isActive && "opacity-70")}>
      <div className="flex flex-wrap items-center gap-3 p-4 sm:p-5">
        <span
          className={cn(
            "flex size-10 shrink-0 items-center justify-center rounded-xl",
            subject.isActive ? "bg-orange-100 text-orange-600" : "bg-neutral-100 text-neutral-400",
          )}
        >
          <BookOpen className="size-5" aria-hidden />
        </span>

        <div className="min-w-0 flex-1">
          {editing ? (
            <form
              className="flex items-center gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                setEditing(false);
                if (editName.trim() && editName.trim() !== subject.name) {
                  run(() => updateSubjectAction(subject.id, { name: editName, description: subject.description }), "Subject renamed.");
                }
              }}
            >
              <input
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full max-w-64 rounded-lg border border-orange-300 bg-white px-2.5 py-1.5 text-sm font-semibold"
                autoFocus
              />
              <button type="submit" className="rounded-lg bg-orange-500 p-1.5 text-white hover:bg-orange-600" aria-label="Save name">
                <Check className="size-4" />
              </button>
              <button type="button" onClick={() => { setEditing(false); setEditName(subject.name); }} className="rounded-lg p-1.5 text-neutral-400 hover:bg-neutral-100" aria-label="Cancel">
                <X className="size-4" />
              </button>
            </form>
          ) : (
            <>
              <p className="truncate font-display text-[15px] font-bold tracking-tight text-neutral-900">
                {subject.name}
              </p>
              <p className="truncate text-xs text-neutral-400">
                {subject.assignments.length} class{subject.assignments.length === 1 ? "" : "es"}
                {subject.description ? ` · ${subject.description}` : ""}
              </p>
            </>
          )}
        </div>

        <div className="flex items-center gap-1">
          <Badge tone={subject.isActive ? "green" : "neutral"}>{subject.isActive ? "Active" : "Inactive"}</Badge>
          {canManage ? (
            <>
              <button
                onClick={() => setEditing((v) => !v)}
                title="Rename subject"
                className="rounded-lg p-2 text-neutral-400 transition-colors hover:bg-orange-50 hover:text-orange-600"
              >
                <Pencil className="size-4" />
              </button>
              <button
                onClick={() =>
                  run(
                    () => toggleSubjectActiveAction(subject.id),
                    subject.isActive ? "Subject deactivated." : "Subject activated.",
                  )
                }
                title={subject.isActive ? "Deactivate" : "Activate"}
                className={cn(
                  "rounded-lg p-2 transition-colors",
                  subject.isActive
                    ? "text-neutral-400 hover:bg-rose-50 hover:text-rose-600"
                    : "text-rose-500 hover:bg-emerald-50 hover:text-emerald-600",
                )}
              >
                <Power className="size-4" />
              </button>
            </>
          ) : null}
          <button
            onClick={() => setExpanded((v) => !v)}
            aria-label={expanded ? "Hide assignments" : "Show assignments"}
            className="rounded-lg p-2 text-neutral-400 transition-colors hover:bg-neutral-100"
          >
            <ChevronDown className={cn("size-4 transition-transform duration-200", expanded && "rotate-180")} />
          </button>
        </div>
      </div>

      {expanded ? (
        <div className="border-t border-neutral-100 bg-neutral-50/50 p-4 sm:p-5">
          <p className="mb-3 text-[11px] font-semibold uppercase tracking-wider text-neutral-400">
            Class assignments
          </p>
          {subject.assignments.length === 0 ? (
            <p className="rounded-xl border border-dashed border-neutral-200 bg-white px-4 py-3 text-xs text-neutral-400">
              Not assigned to any class yet.
            </p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {subject.assignments.map((a) => (
                <span
                  key={a.id}
                  className="group inline-flex items-center gap-2 rounded-xl border border-neutral-200 bg-white py-1.5 pl-3 pr-1.5 text-xs font-semibold text-neutral-700"
                >
                  {a.className}
                  <button
                    type="button"
                    disabled={!canManage || pending}
                    onClick={() =>
                      run(
                        () => toggleClassSubjectCoreAction(a.id),
                        a.isCore ? "Marked as elective." : "Marked as core.",
                      )
                    }
                    title="Toggle core / elective"
                    className={cn(
                      "rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide transition-colors disabled:cursor-not-allowed",
                      a.isCore
                        ? "bg-orange-100 text-orange-700 hover:bg-orange-200"
                        : "bg-pink-100 text-pink-600 hover:bg-pink-200",
                    )}
                  >
                    {a.isCore ? "core" : "elective"}
                  </button>
                  {canManage ? (
                    <button
                      type="button"
                      disabled={pending}
                      onClick={() => run(() => removeClassSubjectAction(a.id), "Assignment removed.")}
                      title={`Remove ${subject.name} from ${a.className}`}
                      className="rounded-lg p-1 text-neutral-300 transition-colors hover:bg-rose-50 hover:text-rose-500"
                    >
                      <X className="size-3.5" />
                    </button>
                  ) : null}
                </span>
              ))}
            </div>
          )}

          {canManage && unassigned.length > 0 ? (
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <select
                value={assignClassId}
                onChange={(e) => setAssignClassId(e.target.value)}
                className="rounded-xl border border-neutral-200 bg-white px-3 py-2 text-xs font-semibold text-neutral-700"
              >
                <option value="">Assign to class…</option>
                {unassigned.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
              <label className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-600">
                <input
                  type="checkbox"
                  checked={assignCore}
                  onChange={(e) => setAssignCore(e.target.checked)}
                  className="size-3.5 accent-orange-500"
                />
                core
              </label>
              <button
                type="button"
                disabled={!assignClassId || pending}
                onClick={() =>
                  run(
                    () => assignSubjectToClassAction(subject.id, assignClassId, assignCore),
                    "Subject assigned.",
                  )
                }
                className="inline-flex items-center gap-1.5 rounded-xl bg-orange-500 px-3 py-2 text-xs font-bold text-white transition-colors hover:bg-orange-600 disabled:opacity-50"
              >
                <Plus className="size-3.5" /> Assign
              </button>
            </div>
          ) : null}
        </div>
      ) : null}
    </Card>
  );
}

export function SubjectsClient({
  subjects,
  classes,
  canManage,
}: {
  subjects: SubjectRow[];
  classes: ClassOpt[];
  canManage: boolean;
}) {
  const [creating, setCreating] = useState(false);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);

  const active = subjects.filter((s) => s.isActive);
  const inactive = subjects.filter((s) => !s.isActive);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="flex items-center gap-2 text-xs text-neutral-400">
          <Sparkles className="size-3.5 text-orange-400" aria-hidden />
          Defaults from the Ghana Standards-Based Curriculum are protected — they can be deactivated
          but never hard-deleted once referenced.
        </p>
        {canManage ? (
          <button onClick={() => setCreating((v) => !v)} className={buttonClasses(creating ? "secondary" : "primary")}>
            {creating ? <X className="size-4" /> : <BookPlus className="size-4" />}
            {creating ? "Close" : "New subject"}
          </button>
        ) : null}
      </div>

      {message ? <Alert tone={message.ok ? "success" : "error"}>{message.text}</Alert> : null}

      {creating && canManage ? (
        <Card className="anim-fade-up p-5 sm:p-6">
          <h2 className="mb-4 font-display text-base font-bold text-neutral-900">Create subject</h2>
          <CreateSubjectForm classes={classes} onDone={() => setCreating(false)} />
        </Card>
      ) : null}

      <div className="space-y-3">
        {active.map((subject) => (
          <SubjectCard key={subject.id} subject={subject} classes={classes} canManage={canManage} notify={setMessage} />
        ))}
      </div>

      {inactive.length > 0 ? (
        <div className="space-y-3 pt-2">
          <p className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400">
            Inactive subjects
          </p>
          {inactive.map((subject) => (
            <SubjectCard key={subject.id} subject={subject} classes={classes} canManage={canManage} notify={setMessage} />
          ))}
        </div>
      ) : null}
    </div>
  );
}
