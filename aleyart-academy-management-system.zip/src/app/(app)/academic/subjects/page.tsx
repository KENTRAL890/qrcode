import { asc } from "drizzle-orm";
import { db } from "@/db";
import { classes, classSubjects, subjects } from "@/db/schema";
import { requirePermission, userHasPermission } from "@/lib/auth";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui";
import { SubjectsClient, type SubjectRow } from "./subjects-client";

export const dynamic = "force-dynamic";

export const metadata = { title: "Subjects" };

export default async function SubjectsPage() {
  const user = await requirePermission("subjects.view");
  const canManage = userHasPermission(user, "subjects.manage");

  const [subjectRows, classRows, assignmentRows] = await Promise.all([
    db.select().from(subjects).orderBy(asc(subjects.name)),
    db.select().from(classes).orderBy(asc(classes.sortOrder)),
    db.select().from(classSubjects),
  ]);

  const classNameById = new Map(classRows.map((c) => [c.id, c.name]));

  const data: SubjectRow[] = subjectRows.map((s) => ({
    id: s.id,
    name: s.name,
    description: s.description,
    isActive: s.isActive,
    assignments: assignmentRows
      .filter((a) => a.subjectId === s.id)
      .map((a) => ({
        id: a.id,
        classId: a.classId,
        className: classNameById.get(a.classId) ?? "Unknown class",
        isCore: a.isCore,
      }))
      .sort((a, b) => a.className.localeCompare(b.className, undefined, { numeric: true })),
  }));

  return (
    <div className="anim-fade-up space-y-6">
      <PageHeader
        title="Subjects"
        description="Default Ghana Standards-Based curriculum is preloaded — Basic 1–6 (9 subjects) and Basic 7–9 (10 subjects incl. Computing and Career Technology). Administrators can add, rename, assign and deactivate subjects here."
      >
        <Badge tone="neutral">{subjectRows.length} subjects</Badge>
      </PageHeader>

      <SubjectsClient
        subjects={data}
        classes={classRows.map((c) => ({ id: c.id, name: c.name, levelGroup: c.levelGroup }))}
        canManage={canManage}
      />
    </div>
  );
}
