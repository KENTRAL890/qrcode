import { Globe, Info, UpdatedAtIconNote } from "@/components/settings-notes";
import { requirePermission, userHasPermission } from "@/lib/auth";
import { getSchoolBranding } from "@/lib/school";
import { PageHeader } from "@/components/page-header";
import { Card, Badge } from "@/components/ui";
import { SchoolSettingsForm } from "./school-settings-form";
import { CrestUploadForm } from "./crest-upload-form";
import { formatDateTime } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = { title: "School Settings" };

export default async function SchoolSettingsPage() {
  const user = await requirePermission("settings.view");
  const canEdit = userHasPermission(user, "settings.edit");
  const brand = await getSchoolBranding();

  return (
    <div className="anim-fade-up space-y-6">
      <PageHeader
        title="School Settings"
        description="The single source of truth for school identity. The name, motto and crest saved here flow automatically into every page, ID card, report, receipt and official document."
      >
        <Badge tone="orange">System-wide branding</Badge>
      </PageHeader>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[1.15fr_0.85fr]">
        {/* Identity */}
        <Card className="p-5 sm:p-7">
          <div className="mb-6 flex items-center justify-between gap-3">
            <div>
              <h2 className="font-display text-lg font-bold tracking-tight text-neutral-900">
                School identity
              </h2>
              <p className="mt-0.5 text-xs text-neutral-400">
                Stored once in the database — displayed everywhere.
              </p>
            </div>
            <Globe className="size-5 text-neutral-300" />
          </div>

          {canEdit ? (
            <SchoolSettingsForm
              defaults={{
                schoolName: brand.schoolName,
                motto: brand.motto,
                location: brand.location,
                poBox: brand.poBox,
                telephone: brand.telephone,
              }}
            />
          ) : (
            <div className="space-y-4">
              <dl className="grid gap-4 sm:grid-cols-2">
                {[
                  ["School name", brand.schoolName],
                  ["Motto", brand.motto || "—"],
                  ["Location", brand.location || "—"],
                  ["P.O. Box", brand.poBox || "—"],
                  ["Telephone", brand.telephone || "—"],
                ].map(([k, v]) => (
                  <div key={k} className="rounded-xl border border-neutral-100 bg-neutral-50/60 px-4 py-3">
                    <dt className="text-[11px] font-semibold uppercase tracking-wide text-neutral-400">{k}</dt>
                    <dd className="mt-1 text-sm font-semibold text-neutral-800">{v}</dd>
                  </div>
                ))}
              </dl>
              <p className="flex items-start gap-2 rounded-xl border border-neutral-200 bg-neutral-50 px-4 py-3 text-xs text-neutral-500">
                <Info className="mt-0.5 size-4 shrink-0" />
                You have read-only access. An administrator with the <b>&nbsp;school settings&nbsp;</b>
                permission can make changes.
              </p>
            </div>
          )}
        </Card>

        {/* Crest */}
        <div className="space-y-5">
          <Card className="p-5 sm:p-7">
            <h2 className="font-display text-lg font-bold tracking-tight text-neutral-900">
              School crest / logo
            </h2>
            <p className="mt-0.5 text-xs text-neutral-400">
              JPG, JPEG, PNG or WEBP · maximum 2 MB · signature-verified on upload.
            </p>
            <CrestUploadForm currentCrestUrl={brand.crestUrl} schoolName={brand.schoolName} canEdit={canEdit} />
          </Card>

          <Card className="border-orange-100 bg-gradient-to-br from-orange-50/80 to-pink-50/60 p-5 sm:p-6">
            <UpdatedAtIconNote
              updatedAt={brand.updatedAt ? formatDateTime(brand.updatedAt) : null}
              updatedBy={brand.updatedByName}
            />
          </Card>
        </div>
      </div>
    </div>
  );
}
