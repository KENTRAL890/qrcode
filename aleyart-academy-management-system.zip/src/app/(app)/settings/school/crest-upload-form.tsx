"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { CloudUpload, ImagePlus, Trash2 } from "lucide-react";
import { uploadCrestAction } from "@/lib/actions/settings-actions";
import type { FormState } from "@/lib/actions/auth-actions";
import { MAX_CREST_BYTES } from "@/lib/upload-constants";
import { Alert, } from "@/components/ui";
import { SubmitButton } from "@/components/ui-client";
import { cn } from "@/lib/utils";

export function CrestUploadForm({
  currentCrestUrl,
  schoolName,
  canEdit,
}: {
  currentCrestUrl: string | null;
  schoolName: string;
  canEdit: boolean;
}) {
  const [state, formAction] = useActionState<FormState | null, FormData>(uploadCrestAction, null);
  const [preview, setPreview] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [fileTooBig, setFileTooBig] = useState<string | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  useEffect(() => {
    if (state?.ok) {
      setShowSuccess(true);
      setPreview(null);
      setFileName(null);
      if (inputRef.current) inputRef.current.value = "";
      router.refresh();
      const t = setTimeout(() => setShowSuccess(false), 4000);
      return () => clearTimeout(t);
    }
  }, [state, router]);

  useEffect(() => {
    return () => {
      if (preview) URL.revokeObjectURL(preview);
    };
  }, [preview]);

  function pickFile(file: File | undefined) {
    if (!file) return;
    if (file.size > MAX_CREST_BYTES) {
      setFileTooBig(`"${file.name}" is ${(file.size / 1048576).toFixed(1)} MB — the limit is 2 MB.`);
      if (inputRef.current) inputRef.current.value = "";
      return;
    }
    setFileTooBig(null);
    if (preview) URL.revokeObjectURL(preview);
    setPreview(URL.createObjectURL(file));
    setFileName(file.name);
  }

  const shownUrl = preview ?? currentCrestUrl;

  return (
    <div className="mt-5">
      <form action={formAction} className="space-y-4" autoComplete="off">
        {state?.error ? <Alert>{state.error}</Alert> : null}
        {fileTooBig ? <Alert>{fileTooBig}</Alert> : null}
        {showSuccess ? (
          <Alert tone="success">
            New crest saved — it now appears on the login page, sidebar, dashboard and every official
            document.
          </Alert>
        ) : null}

        {/* Preview area */}
        <div
          className={cn(
            "relative flex aspect-[4/3] items-center justify-center overflow-hidden rounded-2xl border-2 border-dashed transition-colors",
            preview
              ? "border-orange-300 bg-orange-50/50"
              : "border-neutral-200 bg-gradient-to-br from-neutral-50 to-orange-50/40",
          )}
        >
          {shownUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={shownUrl}
              alt={
                preview
                  ? `Preview of new crest (${fileName})`
                  : `${schoolName} official crest`
              }
              className="max-h-[72%] max-w-[72%] object-contain drop-shadow-sm"
            />
          ) : (
            <div className="px-6 text-center">
              <ImagePlus className="mx-auto size-8 text-neutral-300" aria-hidden />
              <p className="mt-2 text-xs text-neutral-400">No crest uploaded yet.</p>
            </div>
          )}

          {preview ? (
            <span className="absolute left-3 top-3 rounded-full bg-orange-500 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white shadow">
              Preview — not saved yet
            </span>
          ) : (
            <span className="absolute left-3 top-3 rounded-full bg-white/90 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-neutral-500 ring-1 ring-neutral-200">
              Current crest
            </span>
          )}
        </div>

        {canEdit ? (
          <>
            <input
              ref={inputRef}
              type="file"
              name="crest"
              accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
              className="hidden"
              onChange={(e) => pickFile(e.target.files?.[0])}
            />

            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={() => inputRef.current?.click()}
                className="inline-flex items-center gap-2 rounded-xl border border-neutral-200 bg-white px-4 py-2.5 text-sm font-semibold text-neutral-700 transition-colors hover:border-orange-300 hover:text-orange-600"
              >
                <ImagePlus className="size-4" aria-hidden />
                {shownUrl ? "Choose another image" : "Choose image"}
              </button>

              {preview ? (
                <>
                  <SubmitButton pendingText="Uploading…">
                    <CloudUpload className="size-4" aria-hidden />
                    Save new crest
                  </SubmitButton>
                  <button
                    type="button"
                    onClick={() => {
                      if (preview) URL.revokeObjectURL(preview);
                      setPreview(null);
                      setFileName(null);
                      if (inputRef.current) inputRef.current.value = "";
                    }}
                    className="inline-flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-neutral-500 transition-colors hover:bg-neutral-100"
                  >
                    <Trash2 className="size-4" aria-hidden />
                    Discard
                  </button>
                </>
              ) : null}
            </div>

            {fileName && preview ? (
              <p className="truncate text-xs text-neutral-400">
                Ready to save: <span className="font-medium text-neutral-600">{fileName}</span>
              </p>
            ) : null}
          </>
        ) : (
          <p className="rounded-xl border border-neutral-200 bg-neutral-50 px-4 py-3 text-xs text-neutral-500">
            Crest replacement requires administrator permission.
          </p>
        )}
      </form>
    </div>
  );
}
