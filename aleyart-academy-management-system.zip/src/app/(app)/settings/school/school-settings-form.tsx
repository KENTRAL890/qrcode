"use client";

import { useActionState, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Save } from "lucide-react";
import { updateSchoolSettingsAction } from "@/lib/actions/settings-actions";
import type { FormState } from "@/lib/actions/auth-actions";
import { Alert, Field, inputClasses } from "@/components/ui";
import { SubmitButton } from "@/components/ui-client";

interface Defaults {
  schoolName: string;
  motto: string;
  location: string;
  poBox: string;
  telephone: string;
}

export function SchoolSettingsForm({ defaults }: { defaults: Defaults }) {
  const [state, formAction] = useActionState<FormState | null, FormData>(
    updateSchoolSettingsAction,
    null,
  );
  const [showSuccess, setShowSuccess] = useState(false);
  const router = useRouter();

  useEffect(() => {
    if (state?.ok) {
      setShowSuccess(true);
      router.refresh();
      const t = setTimeout(() => setShowSuccess(false), 4000);
      return () => clearTimeout(t);
    }
  }, [state, router]);

  return (
    <form action={formAction} className="space-y-5" autoComplete="off">
      {state?.error ? <Alert>{state.error}</Alert> : null}
      {showSuccess ? (
        <Alert tone="success">
          School identity updated — the new name, motto and contact details are now live across the
          whole system.
        </Alert>
      ) : null}

      <Field label="School name">
        <input
          name="schoolName"
          required
          minLength={2}
          maxLength={160}
          defaultValue={defaults.schoolName}
          placeholder="e.g. ALEYART ACADEMY"
          className={inputClasses}
        />
      </Field>

      <Field label="School motto" hint="Shown on the login page, sidebar, reports and ID cards.">
        <input
          name="motto"
          maxLength={200}
          defaultValue={defaults.motto}
          placeholder="e.g. Seeking Wisdom"
          className={inputClasses}
        />
      </Field>

      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Location">
          <input
            name="location"
            maxLength={200}
            defaultValue={defaults.location}
            placeholder="e.g. Odokor-Official Town, Ghana"
            className={inputClasses}
          />
        </Field>
        <Field label="P.O. Box">
          <input
            name="poBox"
            maxLength={60}
            defaultValue={defaults.poBox}
            placeholder="e.g. P.O. Box 4183"
            className={inputClasses}
          />
        </Field>
      </div>

      <Field label="Telephone" hint="Primary contact number printed on receipts and documents.">
        <input
          name="telephone"
          maxLength={40}
          inputMode="tel"
          defaultValue={defaults.telephone}
          placeholder="e.g. 0553797233"
          className={inputClasses}
        />
      </Field>

      <div className="flex items-center justify-end border-t border-neutral-100 pt-5">
        <SubmitButton pendingText="Saving…">
          <Save className="size-4" aria-hidden />
          Save changes
        </SubmitButton>
      </div>
    </form>
  );
}
