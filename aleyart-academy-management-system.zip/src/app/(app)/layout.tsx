import type { ReactNode } from "react";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { academicYears } from "@/db/schema";
import { requireUser, userHasPermission } from "@/lib/auth";
import { getSchoolBranding } from "@/lib/school";
import { ROLE_LABELS } from "@/lib/permissions";
import { AppShell, type ShellNavItem } from "@/components/app-shell";

export const dynamic = "force-dynamic";

interface NavDef extends ShellNavItem {
  section: string;
  permission: Parameters<typeof userHasPermission>[1];
}

const NAV: NavDef[] = [
  { section: "Overview", href: "/dashboard", label: "Dashboard", icon: "dashboard", permission: "dashboard.view" },
  { section: "Students", href: "/students", label: "Directory", icon: "students", permission: "students.view" },
  { section: "Students", href: "/students/promote", label: "Promotions", icon: "promote", permission: "students.promote" },
  { section: "Academics", href: "/assessments", label: "Assessments", icon: "assessments", permission: "assessments.view" },
  { section: "Academics", href: "/reports", label: "Terminal Reports", icon: "reports", permission: "reports.view" },
  { section: "Academics", href: "/academic/years", label: "Years & Terms", icon: "years", permission: "academic.view" },
  { section: "Academics", href: "/academic/classes", label: "Classes", icon: "classes", permission: "academic.view" },
  { section: "Academics", href: "/academic/subjects", label: "Subjects", icon: "subjects", permission: "subjects.view" },
  { section: "Finance", href: "/finance/payments", label: "Fees & Payments", icon: "payments", permission: "fees.view" },
  { section: "Finance", href: "/finance/reports", label: "Financial Reports", icon: "finance", permission: "finance.reports" },
  { section: "Finance", href: "/finance", label: "Fee Setup", icon: "wallet", permission: "fees.manage" },
  { section: "Administration", href: "/admin/users", label: "Users & Roles", icon: "users", permission: "users.view" },
  { section: "Administration", href: "/admin/audit", label: "Audit Log", icon: "audit", permission: "audit.view" },
  { section: "School", href: "/settings/school", label: "School Settings", icon: "settings", permission: "settings.view" },
];

export default async function AppLayout({ children }: { children: ReactNode }) {
  // Authoritative server-side gate for every protected page
  const user = await requireUser();
  const brand = await getSchoolBranding();

  const [currentYear] = await db
    .select({ name: academicYears.name })
    .from(academicYears)
    .where(eq(academicYears.isCurrent, true))
    .limit(1);

  const visible = NAV.filter((item) => userHasPermission(user, item.permission));
  const sections = visible.reduce<Array<{ title: string; items: ShellNavItem[] }>>(
    (acc, item) => {
      let section = acc.find((s) => s.title === item.section);
      if (!section) {
        section = { title: item.section, items: [] };
        acc.push(section);
      }
      section.items.push({ href: item.href, label: item.label, icon: item.icon });
      return acc;
    },
    [],
  );

  return (
    <AppShell
      brandName={brand.schoolName}
      brandMotto={brand.motto}
      crestUrl={brand.crestUrl}
      userName={user.fullName}
      userRoleLabel={user.roles.map((r) => ROLE_LABELS[r] ?? r).join(" · ") || "Staff"}
      currentYear={currentYear?.name ?? null}
      sections={sections}
    >
      {children}
    </AppShell>
  );
}
