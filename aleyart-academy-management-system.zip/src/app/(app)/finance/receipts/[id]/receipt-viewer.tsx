"use client";

import { useState, useTransition, type ReactNode } from "react";
import { Printer, ZoomIn, ZoomOut, Ruler } from "lucide-react";
import { registerReceiptPrintAction } from "@/lib/actions/finance-actions";

/**
 * Receipt preview + print. Printing registers an audited reprint event;
 * the receipt number itself is never regenerated.
 */
export function ReceiptViewer({ children, paymentId }: { children: ReactNode; paymentId: string }) {
  const [zoom, setZoom] = useState(1);
  const [, startTransition] = useTransition();

  function print() {
    startTransition(async () => {
      await registerReceiptPrintAction(paymentId);
      window.print();
    });
  }

  return (
    <div className="space-y-4">
      <div className="no-print flex flex-wrap items-center gap-2.5">
        <div className="flex items-center gap-1 rounded-xl border border-neutral-200 bg-white p-1 shadow-sm">
          <button
            type="button"
            onClick={() => setZoom((z) => Math.max(0.5, +(z - 0.1).toFixed(2)))}
            className="rounded-lg p-1.5 text-neutral-500 transition-colors hover:bg-neutral-100"
            aria-label="Zoom out"
          >
            <ZoomOut className="size-4" />
          </button>
          <span className="w-14 text-center text-xs font-semibold tabular-nums text-neutral-600">
            {Math.round(zoom * 100)}%
          </span>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.min(2, +(z + 0.1).toFixed(2)))}
            className="rounded-lg p-1.5 text-neutral-500 transition-colors hover:bg-neutral-100"
            aria-label="Zoom in"
          >
            <ZoomIn className="size-4" />
          </button>
        </div>
        <button
          type="button"
          onClick={print}
          className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white shadow-[0_8px_20px_-8px_rgba(249,115,22,0.7)] transition-colors hover:bg-orange-600 active:scale-[0.98]"
        >
          <Printer className="size-4" aria-hidden /> Print receipt
        </button>
        <p className="inline-flex items-center gap-1.5 text-[11px] font-medium text-neutral-400">
          <Ruler className="size-3.5" aria-hidden />
          Prints at <b className="text-neutral-600">148 × 105 mm</b> · 100% scale.
        </p>
      </div>

      <div className="report-zoom flex justify-center overflow-x-auto" style={{ zoom } as never}>
        <div className="report-frame rounded-xl shadow-[0_24px_60px_-24px_rgba(28,25,23,0.4)] ring-1 ring-neutral-200">
          {children}
        </div>
      </div>
    </div>
  );
}
