import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { ArrowLeft, ShieldCheck } from "lucide-react";
import { db } from "@/db";
import { academicYears, classes, feePayments, students, studentFeeAccounts, terms } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { getSchoolBranding } from "@/lib/school";
import { ReceiptDoc } from "@/components/receipt";
import { ReceiptViewer } from "./receipt-viewer";
import { PageHeader } from "@/components/page-header";
import { Alert, Badge } from "@/components/ui";

export const dynamic = "force-dynamic";

export const metadata = { title: "Receipt" };

interface PaymentSnapshot {
  school?: {
    schoolName: string;
    motto: string;
    location: string;
    poBox: string;
    telephone: string;
    crestUrl: string | null;
  };
  student?: { fullName: string; studentCode: string; className: string | null };
  academic?: { academicYear: string; term: string };
}

export default async function ReceiptPage({ params }: { params: Promise<{ id: string }> }) {
  await requirePermission("fees.view");
  const { id } = await params;

  const [row] = await db
    .select({
      payment: feePayments,
      studentName: students.fullName,
      className: classes.name,
      yearName: academicYears.name,
      termName: terms.name,
      totalCharged: studentFeeAccounts.totalCharged,
      totalPaid: studentFeeAccounts.totalPaid,
      outstanding: studentFeeAccounts.outstanding,
    })
    .from(feePayments)
    .innerJoin(students, eq(students.id, feePayments.studentId))
    .innerJoin(academicYears, eq(academicYears.id, feePayments.academicYearId))
    .innerJoin(terms, eq(terms.id, feePayments.termId))
    .innerJoin(studentFeeAccounts, eq(studentFeeAccounts.id, feePayments.accountId))
    .leftJoin(classes, eq(classes.id, feePayments.classId))
    .where(eq(feePayments.id, id))
    .limit(1);
  if (!row) notFound();

  const p = row.payment;
  const snap = (p.snapshot ?? null) as PaymentSnapshot | null;
  const live = await getSchoolBranding();

  // Finalized receipts keep the branding captured when they were issued.
  const brand = snap?.school ?? {
    schoolName: live.schoolName,
    motto: live.motto,
    location: live.location,
    poBox: live.poBox,
    telephone: live.telephone,
    crestUrl: live.crestUrl,
  };

  const isReprint = p.printCount > 0;

  return (
    <div className="anim-fade-up space-y-6">
      <div className="no-print space-y-4">
        <PageHeader
          title={`Receipt ${p.receiptNumber}`}
          description={`${row.studentName} · ${p.studentCode} · ${row.yearName} ${row.termName}`}
        >
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone={p.status === "active" ? "green" : "rose"} className="!px-3 !py-1.5 !text-xs">
              {p.status}
            </Badge>
            {isReprint ? <Badge tone="amber">reprint #{p.printCount}</Badge> : null}
            <Link
              href={`/finance/payments?studentId=${p.studentId}`}
              className="inline-flex items-center gap-2 rounded-xl border border-neutral-200 bg-white px-4 py-2.5 text-sm font-semibold text-neutral-700 transition-colors hover:border-orange-300 hover:text-orange-600"
            >
              <ArrowLeft className="size-4" aria-hidden /> Student ledger
            </Link>
          </div>
        </PageHeader>

        <Alert tone="info">
          <span className="flex flex-wrap items-center gap-1.5">
            <ShieldCheck className="size-4 shrink-0" aria-hidden />
            Receipt number <b className="font-mono">{p.receiptNumber}</b> is permanent. Reprinting
            reuses the same number and is recorded in the audit log.
            {snap?.school ? " Branding shown is the snapshot captured when the receipt was issued." : ""}
          </span>
        </Alert>

        {p.status === "reversed" ? (
          <Alert>
            This payment was reversed{p.reversalReason ? `: ${p.reversalReason}` : ""}. The original
            record and its receipt number are preserved for audit.
          </Alert>
        ) : null}
      </div>

      <ReceiptViewer paymentId={p.id}>
        <ReceiptDoc
          brand={brand}
          isReprint={isReprint}
          data={{
            receiptNumber: p.receiptNumber,
            studentName: snap?.student?.fullName ?? row.studentName,
            studentCode: p.studentCode,
            className: snap?.student?.className ?? row.className,
            academicYear: snap?.academic?.academicYear ?? row.yearName,
            term: snap?.academic?.term ?? row.termName,
            amount: p.amount,
            method: p.method,
            paidAt: p.paidAt,
            receivedByName: p.receivedByName,
            reference: p.reference,
            notes: p.notes,
            status: p.status,
            printCount: p.printCount,
            balance: {
              totalCharged: row.totalCharged,
              totalPaid: row.totalPaid,
              outstanding: row.outstanding,
            },
          }}
        />
      </ReceiptViewer>
    </div>
  );
}
