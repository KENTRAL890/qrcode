import { asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  academicYears,
  classes,
  feeCategories,
  feeStructures,
  terms,
} from "@/db/schema";
import { requirePermission, userHasPermission } from "@/lib/auth";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui";
import { FeeSetupClient, type StructureRow } from "./fee-setup-client";

export const dynamic = "force-dynamic";

export const metadata = { title: "Fee Setup" };

export default async function FinanceSetupPage() {
  const actor = await requirePermission("fees.view");
  const canManage = userHasPermission(actor, "fees.manage");

  const [categories, classRows, termRows, structures] = await Promise.all([
    db.select().from(feeCategories).orderBy(asc(feeCategories.sortOrder), asc(feeCategories.name)),
    db.select().from(classes).where(eq(classes.isActive, true)).orderBy(asc(classes.sortOrder)),
    db
      .select({
        id: terms.id,
        name: terms.name,
        yearName: academicYears.name,
        isCurrent: terms.isCurrent,
      })
      .from(terms)
      .innerJoin(academicYears, eq(academicYears.id, terms.academicYearId))
      .where(eq(academicYears.isArchived, false))
      .orderBy(asc(academicYears.name), asc(terms.createdAt)),
    db
      .select({
        id: feeStructures.id,
        amount: feeStructures.amount,
        categoryName: feeCategories.name,
        className: classes.name,
        classSort: classes.sortOrder,
        termName: terms.name,
        yearName: academicYears.name,
      })
      .from(feeStructures)
      .innerJoin(feeCategories, eq(feeCategories.id, feeStructures.categoryId))
      .innerJoin(classes, eq(classes.id, feeStructures.classId))
      .innerJoin(terms, eq(terms.id, feeStructures.termId))
      .innerJoin(academicYears, eq(academicYears.id, feeStructures.academicYearId))
      .where(eq(feeStructures.isActive, true))
      .orderBy(asc(academicYears.name), asc(classes.sortOrder), asc(feeCategories.name)),
  ]);

  const rows: StructureRow[] = structures.map((s) => ({
    id: s.id,
    amount: s.amount,
    categoryName: s.categoryName,
    className: s.className,
    termName: s.termName,
    yearName: s.yearName,
  }));

  void sql;

  return (
    <div className="anim-fade-up space-y-6">
      <PageHeader
        title="Fee Setup"
        description="Configure fee categories and the amount charged per class, academic year and term. All money is stored as exact decimals (NUMERIC) — never floating point."
      >
        <div className="flex gap-2">
          <Badge tone="neutral">{categories.length} categories</Badge>
          <Badge tone="orange">{rows.length} structure lines</Badge>
        </div>
      </PageHeader>

      <FeeSetupClient
        categories={categories.map((c) => ({
          id: c.id,
          name: c.name,
          code: c.code,
          isActive: c.isActive,
          isRecurring: c.isRecurring,
        }))}
        classes={classRows.map((c) => ({ id: c.id, name: c.name }))}
        terms={termRows.map((t) => ({
          id: t.id,
          name: `${t.yearName} · ${t.name}`,
          isCurrent: t.isCurrent,
        }))}
        structures={rows}
        canManage={canManage}
      />
    </div>
  );
}
