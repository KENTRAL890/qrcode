import Link from "next/link";
import { and, asc, desc, eq, gte, ilike, lte, or, sql, sum, count as dcount } from "drizzle-orm";
import { Download, Banknote, TrendingUp, AlertTriangle, Search } from "lucide-react";
import { db } from "@/db";
import {
  academicYears,
  classes,
  feePayments,
  students,
  studentFeeAccounts,
  terms,
} from "@/db/schema";
import { requirePermission, userHasPermission } from "@/lib/auth";
import { PageHeader } from "@/components/page-header";
import { Badge, Card, inputClasses, buttonClasses } from "@/components/ui";
import { formatMoney, formatDate } from "@/lib/format";
import { cn } from "@/lib/utils";

export const dynamic = "force-dynamic";

export const metadata = { title: "Financial Reports" };

const TABS = [
  { key: "daily", label: "Daily collection" },
  { key: "term", label: "Term collection" },
  { key: "year", label: "Year collection" },
  { key: "outstanding", label: "Outstanding & arrears" },
  { key: "search", label: "Receipt search" },
] as const;

export default async function FinanceReportsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const actor = await requirePermission("finance.reports");
  const canExport = userHasPermission(actor, "exports.data");
  const sp = await searchParams;

  const tab = (typeof sp.tab === "string" ? sp.tab : "daily") as (typeof TABS)[number]["key"];
  const from = typeof sp.from === "string" ? sp.from : new Date().toISOString().slice(0, 10);
  const to = typeof sp.to === "string" ? sp.to : new Date().toISOString().slice(0, 10);
  const termId = typeof sp.termId === "string" ? sp.termId : "";
  const yearId = typeof sp.yearId === "string" ? sp.yearId : "";
  const q = (typeof sp.q === "string" ? sp.q : "").trim();
  const classId = typeof sp.classId === "string" ? sp.classId : "";

  const [termRows, yearRows, classRows] = await Promise.all([
    db
      .select({ id: terms.id, name: terms.name, yearName: academicYears.name })
      .from(terms)
      .innerJoin(academicYears, eq(academicYears.id, terms.academicYearId))
      .orderBy(asc(academicYears.name), asc(terms.createdAt)),
    db.select().from(academicYears).orderBy(desc(academicYears.name)),
    db.select().from(classes).orderBy(asc(classes.sortOrder)),
  ]);

  /* ---------------- data per tab ---------------- */
  let rows: Array<Record<string, string | number | null>> = [];
  let totalAmount = "0";
  let headline = "";

  const activeOnly = eq(feePayments.status, "active");

  if (tab === "daily" || tab === "search") {
    const conds = [activeOnly];
    if (tab === "daily") {
      conds.push(gte(feePayments.paidAt, new Date(`${from}T00:00:00Z`)));
      conds.push(lte(feePayments.paidAt, new Date(`${to}T23:59:59Z`)));
    }
    if (q) {
      const pattern = `%${q.replaceAll("%", "\\%").replaceAll("_", "\\_")}%`;
      conds.push(
        or(
          ilike(feePayments.receiptNumber, pattern),
          ilike(feePayments.studentCode, pattern),
          ilike(students.fullName, pattern),
        )!,
      );
    }
    if (classId) conds.push(eq(feePayments.classId, classId));
    if (termId) conds.push(eq(feePayments.termId, termId));

    const data = await db
      .select({
        receiptNumber: feePayments.receiptNumber,
        paidAt: feePayments.paidAt,
        studentCode: feePayments.studentCode,
        fullName: students.fullName,
        className: classes.name,
        termName: terms.name,
        yearName: academicYears.name,
        amount: feePayments.amount,
        method: feePayments.method,
        receivedByName: feePayments.receivedByName,
        id: feePayments.id,
      })
      .from(feePayments)
      .innerJoin(students, eq(students.id, feePayments.studentId))
      .innerJoin(terms, eq(terms.id, feePayments.termId))
      .innerJoin(academicYears, eq(academicYears.id, feePayments.academicYearId))
      .leftJoin(classes, eq(classes.id, feePayments.classId))
      .where(and(...conds))
      .orderBy(desc(feePayments.paidAt))
      .limit(300);

    rows = data.map((d) => ({
      id: d.id,
      receiptNumber: d.receiptNumber,
      date: formatDate(d.paidAt),
      studentCode: d.studentCode,
      fullName: d.fullName,
      className: d.className ?? "—",
      period: `${d.yearName} · ${d.termName}`,
      method: d.method,
      receivedBy: d.receivedByName ?? "—",
      amount: d.amount,
    }));
    totalAmount = data.reduce((s, d) => s + Number(d.amount), 0).toFixed(2);
    headline = tab === "daily" ? `Collections ${formatDate(from)} → ${formatDate(to)}` : "Receipt search";
  }

  if (tab === "term" || tab === "year") {
    const conds = [activeOnly];
    if (tab === "term" && termId) conds.push(eq(feePayments.termId, termId));
    if (tab === "year" && yearId) conds.push(eq(feePayments.academicYearId, yearId));

    const data = await db
      .select({
        yearName: academicYears.name,
        termName: terms.name,
        className: classes.name,
        total: sum(feePayments.amount),
        payments: dcount(),
      })
      .from(feePayments)
      .innerJoin(terms, eq(terms.id, feePayments.termId))
      .innerJoin(academicYears, eq(academicYears.id, feePayments.academicYearId))
      .leftJoin(classes, eq(classes.id, feePayments.classId))
      .where(and(...conds))
      .groupBy(academicYears.name, terms.name, classes.name, classes.sortOrder)
      .orderBy(asc(academicYears.name), asc(classes.sortOrder));

    rows = data.map((d) => ({
      period: `${d.yearName} · ${d.termName}`,
      className: d.className ?? "—",
      payments: Number(d.payments),
      amount: d.total ?? "0",
    }));
    totalAmount = data.reduce((s, d) => s + Number(d.total ?? 0), 0).toFixed(2);
    headline = tab === "term" ? "Collections by term" : "Collections by academic year";
  }

  if (tab === "outstanding") {
    const conds = [sql`${studentFeeAccounts.outstanding} > 0`];
    if (termId) conds.push(eq(studentFeeAccounts.termId, termId));
    if (yearId) conds.push(eq(studentFeeAccounts.academicYearId, yearId));
    if (classId) conds.push(eq(studentFeeAccounts.classId, classId));

    const data = await db
      .select({
        studentCode: studentFeeAccounts.studentCode,
        fullName: students.fullName,
        className: classes.name,
        yearName: academicYears.name,
        termName: terms.name,
        totalCharged: studentFeeAccounts.totalCharged,
        totalPaid: studentFeeAccounts.totalPaid,
        outstanding: studentFeeAccounts.outstanding,
        studentId: studentFeeAccounts.studentId,
      })
      .from(studentFeeAccounts)
      .innerJoin(students, eq(students.id, studentFeeAccounts.studentId))
      .innerJoin(terms, eq(terms.id, studentFeeAccounts.termId))
      .innerJoin(academicYears, eq(academicYears.id, studentFeeAccounts.academicYearId))
      .leftJoin(classes, eq(classes.id, studentFeeAccounts.classId))
      .where(and(...conds))
      .orderBy(desc(studentFeeAccounts.outstanding))
      .limit(300);

    rows = data.map((d) => ({
      studentId: d.studentId,
      studentCode: d.studentCode,
      fullName: d.fullName,
      className: d.className ?? "—",
      period: `${d.yearName} · ${d.termName}`,
      charged: d.totalCharged,
      paid: d.totalPaid,
      amount: d.outstanding,
    }));
    totalAmount = data.reduce((s, d) => s + Number(d.outstanding), 0).toFixed(2);
    headline = "Outstanding fees & arrears";
  }

  const exportQuery = new URLSearchParams({
    tab,
    ...(from ? { from } : {}),
    ...(to ? { to } : {}),
    ...(termId ? { termId } : {}),
    ...(yearId ? { yearId } : {}),
    ...(classId ? { classId } : {}),
    ...(q ? { q } : {}),
  }).toString();

  return (
    <div className="anim-fade-up space-y-6">
      <PageHeader
        title="Financial Reports"
        description="Collections, outstanding balances and receipt search — all computed live from PostgreSQL with exact decimal arithmetic."
      >
        {canExport ? (
          <a
            href={`/api/finance/export?${exportQuery}`}
            className={buttonClasses("secondary")}
            download
          >
            <Download className="size-4" aria-hidden /> Export CSV
          </a>
        ) : null}
      </PageHeader>

      {/* Tabs */}
      <div className="no-print flex flex-wrap gap-1.5" role="tablist">
        {TABS.map((t) => (
          <Link
            key={t.key}
            href={`/finance/reports?tab=${t.key}`}
            role="tab"
            aria-selected={tab === t.key}
            className={cn(
              "rounded-xl border px-3.5 py-2 text-xs font-bold transition-colors",
              tab === t.key
                ? "border-orange-300 bg-orange-50 text-orange-700"
                : "border-neutral-200 bg-white text-neutral-500 hover:border-orange-200",
            )}
          >
            {t.label}
          </Link>
        ))}
      </div>

      {/* Filters */}
      <Card className="p-4">
        <form method="GET" className="flex flex-wrap items-end gap-3">
          <input type="hidden" name="tab" value={tab} />
          {tab === "daily" ? (
            <>
              <div className="min-w-36">
                <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">From</label>
                <input type="date" name="from" defaultValue={from} className={inputClasses} />
              </div>
              <div className="min-w-36">
                <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">To</label>
                <input type="date" name="to" defaultValue={to} className={inputClasses} />
              </div>
            </>
          ) : null}
          {(tab === "term" || tab === "outstanding" || tab === "search") ? (
            <div className="min-w-44 flex-1">
              <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">Term</label>
              <select name="termId" defaultValue={termId} className={inputClasses}>
                <option value="">All terms</option>
                {termRows.map((t) => (
                  <option key={t.id} value={t.id}>{t.yearName} · {t.name}</option>
                ))}
              </select>
            </div>
          ) : null}
          {(tab === "year" || tab === "outstanding") ? (
            <div className="min-w-36 flex-1">
              <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">Academic year</label>
              <select name="yearId" defaultValue={yearId} className={inputClasses}>
                <option value="">All years</option>
                {yearRows.map((y) => (
                  <option key={y.id} value={y.id}>{y.name}</option>
                ))}
              </select>
            </div>
          ) : null}
          {(tab === "outstanding" || tab === "search" || tab === "daily") ? (
            <div className="min-w-32 flex-1">
              <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">Class</label>
              <select name="classId" defaultValue={classId} className={inputClasses}>
                <option value="">All classes</option>
                {classRows.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
          ) : null}
          {(tab === "search" || tab === "daily") ? (
            <div className="min-w-48 flex-1">
              <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">
                Receipt no., Student ID or name
              </label>
              <input name="q" defaultValue={q} className={inputClasses} placeholder="e.g. ALA-RCP-2026-000001" />
            </div>
          ) : null}
          <button type="submit" className={buttonClasses("primary")}>
            <Search className="size-4" aria-hidden /> Apply
          </button>
        </form>
      </Card>

      {/* Summary */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="p-5">
          <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-neutral-400">
            <TrendingUp className="size-3.5" aria-hidden /> {headline}
          </p>
          <p className="mt-1.5 font-display text-2xl font-bold text-neutral-900">
            {formatMoney(totalAmount)}
          </p>
        </Card>
        <Card className="p-5">
          <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-neutral-400">
            <Banknote className="size-3.5" aria-hidden /> Rows
          </p>
          <p className="mt-1.5 font-display text-2xl font-bold text-neutral-900">{rows.length}</p>
        </Card>
        <Card className="p-5">
          <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-neutral-400">
            <AlertTriangle className="size-3.5" aria-hidden /> Scope
          </p>
          <p className="mt-1.5 text-sm font-semibold text-neutral-700">
            {tab === "outstanding" ? "Accounts with a balance > 0" : "Active (non-reversed) payments"}
          </p>
        </Card>
      </div>

      {/* Table */}
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-left text-sm">
            <thead>
              <tr className="border-b border-neutral-100 bg-neutral-50/60 text-[11px] uppercase tracking-wider text-neutral-400">
                {tab === "term" || tab === "year" ? (
                  <>
                    <th className="px-5 py-3 font-semibold">Period</th>
                    <th className="px-3 py-3 font-semibold">Class</th>
                    <th className="px-3 py-3 text-center font-semibold">Payments</th>
                    <th className="px-5 py-3 text-right font-semibold">Total</th>
                  </>
                ) : tab === "outstanding" ? (
                  <>
                    <th className="px-5 py-3 font-semibold">Student</th>
                    <th className="px-3 py-3 font-semibold">Student ID</th>
                    <th className="px-3 py-3 font-semibold">Class</th>
                    <th className="px-3 py-3 font-semibold">Period</th>
                    <th className="px-3 py-3 text-right font-semibold">Charged</th>
                    <th className="px-3 py-3 text-right font-semibold">Paid</th>
                    <th className="px-5 py-3 text-right font-semibold">Outstanding</th>
                  </>
                ) : (
                  <>
                    <th className="px-5 py-3 font-semibold">Receipt</th>
                    <th className="px-3 py-3 font-semibold">Date</th>
                    <th className="px-3 py-3 font-semibold">Student</th>
                    <th className="px-3 py-3 font-semibold">Class</th>
                    <th className="px-3 py-3 font-semibold">Method</th>
                    <th className="px-5 py-3 text-right font-semibold">Amount</th>
                  </>
                )}
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={String(r.id ?? r.receiptNumber ?? i)} className="border-b border-neutral-50 hover:bg-orange-50/25">
                  {tab === "term" || tab === "year" ? (
                    <>
                      <td className="px-5 py-2.5 text-xs tabular-nums text-neutral-600">{r.period}</td>
                      <td className="px-3 py-2.5 text-[13px] text-neutral-700">{r.className}</td>
                      <td className="px-3 py-2.5 text-center text-[13px] tabular-nums">{r.payments}</td>
                      <td className="px-5 py-2.5 text-right text-[13px] font-bold tabular-nums">{formatMoney(r.amount as string)}</td>
                    </>
                  ) : tab === "outstanding" ? (
                    <>
                      <td className="px-5 py-2.5">
                        <Link href={`/finance/payments?studentId=${r.studentId}`} className="text-[13px] font-semibold text-neutral-800 hover:text-orange-700">
                          {r.fullName}
                        </Link>
                      </td>
                      <td className="px-3 py-2.5 font-mono text-[11px] text-orange-700">{r.studentCode}</td>
                      <td className="px-3 py-2.5 text-[13px] text-neutral-600">{r.className}</td>
                      <td className="px-3 py-2.5 text-xs tabular-nums text-neutral-500">{r.period}</td>
                      <td className="px-3 py-2.5 text-right text-[13px] tabular-nums">{formatMoney(r.charged as string)}</td>
                      <td className="px-3 py-2.5 text-right text-[13px] tabular-nums text-emerald-700">{formatMoney(r.paid as string)}</td>
                      <td className="px-5 py-2.5 text-right text-[13px] font-bold tabular-nums text-rose-600">{formatMoney(r.amount as string)}</td>
                    </>
                  ) : (
                    <>
                      <td className="px-5 py-2.5">
                        <Link href={`/finance/receipts/${r.id}`} className="font-mono text-[12px] font-bold text-orange-700 hover:underline">
                          {r.receiptNumber}
                        </Link>
                      </td>
                      <td className="px-3 py-2.5 text-xs tabular-nums text-neutral-500">{r.date}</td>
                      <td className="px-3 py-2.5">
                        <span className="block text-[13px] font-semibold text-neutral-800">{r.fullName}</span>
                        <span className="font-mono text-[10.5px] text-neutral-400">{r.studentCode}</span>
                      </td>
                      <td className="px-3 py-2.5 text-[13px] text-neutral-600">{r.className}</td>
                      <td className="px-3 py-2.5 text-[13px] capitalize text-neutral-600">{r.method}</td>
                      <td className="px-5 py-2.5 text-right text-[13px] font-bold tabular-nums text-emerald-700">{formatMoney(r.amount as string)}</td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {rows.length === 0 ? (
          <p className="px-6 py-12 text-center text-sm text-neutral-400">
            No records match the selected filters.
          </p>
        ) : (
          <div className="flex items-center justify-between border-t border-neutral-100 bg-neutral-50/50 px-5 py-3 text-xs">
            <span className="text-neutral-500">{rows.length} row(s)</span>
            <Badge tone="orange">Total {formatMoney(totalAmount)}</Badge>
          </div>
        )}
      </Card>
    </div>
  );
}
