"use client";

import { useActionState, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Banknote,
  Receipt as ReceiptIcon,
  Plus,
  Undo2,
  Layers,
  CircleAlert,
} from "lucide-react";
import {
  recordPaymentAction,
  createChargeAction,
  applyFeeStructureAction,
  reversePaymentAction,
  reverseChargeAction,
} from "@/lib/actions/finance-actions";
import type { FormState } from "@/lib/actions/auth-actions";
import { Alert, Badge, Card, inputClasses, buttonClasses } from "@/components/ui";
import { SubmitButton } from "@/components/ui-client";
import { formatMoney, formatDate } from "@/lib/format";
import { cn } from "@/lib/utils";
import { PAYMENT_METHODS } from "@/lib/finance-constants";

export interface AccountView {
  student: {
    id: string;
    fullName: string;
    studentCode: string;
    className: string | null;
    status: string;
  };
  accounts: Array<{
    id: string;
    termId: string;
    totalCharged: string;
    totalPaid: string;
    outstanding: string;
    termName: string;
    yearName: string;
    className: string | null;
  }>;
  charges: Array<{
    id: string;
    accountId: string;
    description: string;
    amount: string;
    kind: string;
    status: string;
    createdAt: string;
  }>;
  payments: Array<{
    id: string;
    accountId: string;
    receiptNumber: string;
    amount: string;
    method: string;
    paidAt: string;
    status: string;
    reference: string | null;
    receivedByName: string | null;
  }>;
}

export function PaymentsClient({
  data,
  terms,
  categories,
  canRecord,
  canReverse,
  canCharge,
}: {
  data: AccountView;
  terms: Array<{ id: string; name: string; isCurrent: boolean }>;
  categories: Array<{ id: string; name: string }>;
  canRecord: boolean;
  canReverse: boolean;
  canCharge: boolean;
}) {
  const [payState, payAction] = useActionState<
    (FormState & { receiptNumber?: string; paymentId?: string }) | null,
    FormData
  >(recordPaymentAction, null);
  const [chargeState, chargeAction] = useActionState<FormState | null, FormData>(createChargeAction, null);
  const [tab, setTab] = useState<"pay" | "charge">("pay");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const defaultTerm = terms.find((t) => t.isCurrent)?.id ?? terms[0]?.id ?? "";
  const [structTerm, setStructTerm] = useState(defaultTerm);

  if (payState?.ok || chargeState?.ok) router.refresh();

  const run = (fn: () => Promise<FormState>, okText: string) =>
    startTransition(async () => {
      const r = await fn();
      setMsg(r.error ? { ok: false, text: r.error } : { ok: true, text: okText });
      if (!r.error) router.refresh();
    });

  const totals = data.accounts.reduce(
    (acc, a) => ({
      charged: acc.charged + Number(a.totalCharged),
      paid: acc.paid + Number(a.totalPaid),
      outstanding: acc.outstanding + Number(a.outstanding),
    }),
    { charged: 0, paid: 0, outstanding: 0 },
  );

  return (
    <div className="space-y-5">
      {/* Student header */}
      <Card className="overflow-hidden">
        <div className="h-1.5 bg-gradient-to-r from-orange-500 to-pink-500" />
        <div className="flex flex-wrap items-center justify-between gap-4 p-5">
          <div className="min-w-0">
            <h2 className="font-display text-lg font-bold tracking-tight text-neutral-900">
              {data.student.fullName}
            </h2>
            <p className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-neutral-500">
              <span className="rounded-lg bg-orange-50 px-2 py-0.5 font-mono font-bold text-orange-700">
                {data.student.studentCode}
              </span>
              <span>{data.student.className ?? "—"}</span>
              <Badge tone={data.student.status === "active" ? "green" : "neutral"}>
                {data.student.status}
              </Badge>
            </p>
          </div>
          <div className="grid grid-cols-3 gap-3 text-center">
            {[
              ["Charged", totals.charged, "text-neutral-800"],
              ["Paid", totals.paid, "text-emerald-600"],
              ["Outstanding", totals.outstanding, "text-rose-600"],
            ].map(([label, value, color]) => (
              <div key={label as string} className="rounded-xl bg-neutral-50 px-4 py-2.5">
                <p className="text-[10px] font-semibold uppercase tracking-wide text-neutral-400">{label}</p>
                <p className={cn("mt-0.5 text-sm font-bold tabular-nums", color as string)}>
                  {formatMoney(value as number)}
                </p>
              </div>
            ))}
          </div>
        </div>
      </Card>

      {msg ? <Alert tone={msg.ok ? "success" : "error"}>{msg.text}</Alert> : null}

      {payState?.ok && payState.receiptNumber ? (
        <Alert tone="success">
          Payment recorded. Permanent receipt{" "}
          <b className="font-mono">{payState.receiptNumber}</b> issued —{" "}
          <Link href={`/finance/receipts/${payState.paymentId}`} className="font-semibold underline">
            open receipt
          </Link>
          .
        </Alert>
      ) : null}

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[0.9fr_1.1fr]">
        {/* Actions */}
        <div className="space-y-4">
          {canRecord || canCharge ? (
            <Card className="p-5">
              <div className="mb-4 flex gap-2" role="tablist">
                {canRecord ? (
                  <button
                    role="tab"
                    aria-selected={tab === "pay"}
                    onClick={() => setTab("pay")}
                    className={cn(
                      "rounded-xl px-3.5 py-2 text-xs font-bold transition-colors",
                      tab === "pay" ? "bg-orange-500 text-white" : "bg-neutral-100 text-neutral-500",
                    )}
                  >
                    <Banknote className="mr-1.5 inline size-3.5" /> Record payment
                  </button>
                ) : null}
                {canCharge ? (
                  <button
                    role="tab"
                    aria-selected={tab === "charge"}
                    onClick={() => setTab("charge")}
                    className={cn(
                      "rounded-xl px-3.5 py-2 text-xs font-bold transition-colors",
                      tab === "charge" ? "bg-orange-500 text-white" : "bg-neutral-100 text-neutral-500",
                    )}
                  >
                    <Plus className="mr-1.5 inline size-3.5" /> Post charge
                  </button>
                ) : null}
              </div>

              {tab === "pay" && canRecord ? (
                <form action={payAction} className="space-y-3">
                  {payState?.error ? <Alert>{payState.error}</Alert> : null}
                  <input type="hidden" name="studentId" value={data.student.id} />
                  <div>
                    <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Term</label>
                    <select name="termId" required defaultValue={defaultTerm} className={inputClasses}>
                      {terms.map((t) => (
                        <option key={t.id} value={t.id}>{t.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div>
                      <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Amount (GHS)</label>
                      <input
                        name="amount"
                        required
                        inputMode="decimal"
                        pattern="^\d{1,9}(\.\d{1,2})?$"
                        className={inputClasses}
                        placeholder="e.g. 250.00"
                      />
                    </div>
                    <div>
                      <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Method</label>
                      <select name="method" defaultValue="cash" className={inputClasses}>
                        {PAYMENT_METHODS.map((m) => (
                          <option key={m} value={m} className="capitalize">{m}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Payment date</label>
                      <input
                        name="paidAt"
                        type="date"
                        defaultValue={new Date().toISOString().slice(0, 10)}
                        className={inputClasses}
                      />
                    </div>
                    <div>
                      <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Reference</label>
                      <input name="reference" maxLength={80} className={inputClasses} placeholder="optional" />
                    </div>
                  </div>
                  <div>
                    <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Notes</label>
                    <input name="notes" maxLength={300} className={inputClasses} placeholder="optional" />
                  </div>
                  <div className="flex justify-end">
                    <SubmitButton pendingText="Recording…">
                      <ReceiptIcon className="size-4" /> Record &amp; issue receipt
                    </SubmitButton>
                  </div>
                </form>
              ) : null}

              {tab === "charge" && canCharge ? (
                <div className="space-y-4">
                  <form action={chargeAction} className="space-y-3">
                    {chargeState?.error ? <Alert>{chargeState.error}</Alert> : null}
                    <input type="hidden" name="studentId" value={data.student.id} />
                    <div className="grid gap-3 sm:grid-cols-2">
                      <div>
                        <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Term</label>
                        <select name="termId" required defaultValue={defaultTerm} className={inputClasses}>
                          {terms.map((t) => (
                            <option key={t.id} value={t.id}>{t.name}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Category</label>
                        <select name="categoryId" className={inputClasses}>
                          <option value="">Custom</option>
                          {categories.map((c) => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="grid gap-3 sm:grid-cols-2">
                      <div>
                        <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Description</label>
                        <input name="description" maxLength={200} className={inputClasses} placeholder="e.g. Tuition" />
                      </div>
                      <div>
                        <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Amount (GHS)</label>
                        <input
                          name="amount"
                          required
                          inputMode="decimal"
                          pattern="^\d{1,9}(\.\d{1,2})?$"
                          className={inputClasses}
                          placeholder="e.g. 350.00"
                        />
                      </div>
                    </div>
                    <div className="flex justify-end">
                      <SubmitButton pendingText="Posting…">
                        <Plus className="size-4" /> Post charge
                      </SubmitButton>
                    </div>
                  </form>

                  <div className="flex flex-wrap items-end gap-2 border-t border-neutral-100 pt-4">
                    <div className="min-w-44 flex-1">
                      <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">
                        Or apply the whole fee structure
                      </label>
                      <select value={structTerm} onChange={(e) => setStructTerm(e.target.value)} className={inputClasses}>
                        {terms.map((t) => (
                          <option key={t.id} value={t.id}>{t.name}</option>
                        ))}
                      </select>
                    </div>
                    <button
                      type="button"
                      disabled={pending || !structTerm}
                      onClick={() =>
                        run(
                          () => applyFeeStructureAction(data.student.id, structTerm),
                          "Fee structure applied to the student's account.",
                        )
                      }
                      className={buttonClasses("secondary")}
                    >
                      <Layers className="size-4" /> Apply structure
                    </button>
                  </div>
                </div>
              ) : null}
            </Card>
          ) : null}
        </div>

        {/* Ledger */}
        <div className="space-y-4">
          {data.accounts.map((acc) => {
            const accCharges = data.charges.filter((c) => c.accountId === acc.id);
            const accPayments = data.payments.filter((p) => p.accountId === acc.id);
            return (
              <Card key={acc.id} className="overflow-hidden">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-neutral-100 bg-neutral-50/60 px-5 py-3">
                  <p className="text-[13px] font-bold text-neutral-800">
                    {acc.yearName} · {acc.termName}
                    {acc.className ? <span className="ml-2 text-xs font-medium text-neutral-400">{acc.className}</span> : null}
                  </p>
                  <div className="flex gap-3 text-xs tabular-nums">
                    <span className="text-neutral-500">Charged <b className="text-neutral-800">{formatMoney(acc.totalCharged)}</b></span>
                    <span className="text-neutral-500">Paid <b className="text-emerald-600">{formatMoney(acc.totalPaid)}</b></span>
                    <span className="text-neutral-500">Due <b className="text-rose-600">{formatMoney(acc.outstanding)}</b></span>
                  </div>
                </div>

                <div className="divide-y divide-neutral-50">
                  {accCharges.map((c) => (
                    <div key={c.id} className="flex items-center gap-3 px-5 py-2.5">
                      <span className={cn("flex size-7 items-center justify-center rounded-lg", c.kind === "reversal" ? "bg-rose-50 text-rose-500" : "bg-amber-50 text-amber-600")}>
                        <Plus className="size-3.5" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className={cn("block truncate text-[13px] font-medium", c.status === "reversed" ? "text-neutral-400 line-through" : "text-neutral-700")}>
                          {c.description}
                        </span>
                        <span className="text-[10.5px] text-neutral-400">{formatDate(c.createdAt)} · charge</span>
                      </span>
                      <span className={cn("text-[13px] font-bold tabular-nums", Number(c.amount) < 0 ? "text-rose-600" : "text-neutral-700")}>
                        {formatMoney(c.amount)}
                      </span>
                      {canReverse && c.status === "active" && c.kind === "charge" ? (
                        <button
                          type="button"
                          disabled={pending}
                          onClick={() => {
                            const reason = window.prompt("Reason for reversing this charge?");
                            if (reason) run(() => reverseChargeAction(c.id, reason), "Charge reversed.");
                          }}
                          title="Reverse charge"
                          className="rounded-lg p-1.5 text-neutral-300 transition-colors hover:bg-rose-50 hover:text-rose-600"
                        >
                          <Undo2 className="size-3.5" />
                        </button>
                      ) : null}
                    </div>
                  ))}

                  {accPayments.map((p) => (
                    <div key={p.id} className="flex items-center gap-3 px-5 py-2.5">
                      <span className={cn("flex size-7 items-center justify-center rounded-lg", p.status === "reversed" ? "bg-rose-50 text-rose-500" : "bg-emerald-50 text-emerald-600")}>
                        <Banknote className="size-3.5" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <Link
                          href={`/finance/receipts/${p.id}`}
                          className={cn("block truncate font-mono text-[12px] font-bold hover:underline", p.status === "reversed" ? "text-neutral-400 line-through" : "text-orange-700")}
                        >
                          {p.receiptNumber}
                        </Link>
                        <span className="text-[10.5px] capitalize text-neutral-400">
                          {formatDate(p.paidAt)} · {p.method}
                          {p.receivedByName ? ` · ${p.receivedByName}` : ""}
                        </span>
                      </span>
                      <span className={cn("text-[13px] font-bold tabular-nums", p.status === "reversed" ? "text-neutral-400 line-through" : "text-emerald-700")}>
                        {formatMoney(p.amount)}
                      </span>
                      {canReverse && p.status === "active" ? (
                        <button
                          type="button"
                          disabled={pending}
                          onClick={() => {
                            const reason = window.prompt("Reason for reversing this payment?");
                            if (reason) run(() => reversePaymentAction(p.id, reason), "Payment reversed. The receipt number is preserved.");
                          }}
                          title="Reverse payment"
                          className="rounded-lg p-1.5 text-neutral-300 transition-colors hover:bg-rose-50 hover:text-rose-600"
                        >
                          <Undo2 className="size-3.5" />
                        </button>
                      ) : null}
                    </div>
                  ))}

                  {accCharges.length === 0 && accPayments.length === 0 ? (
                    <p className="px-5 py-6 text-center text-xs text-neutral-400">No ledger entries yet.</p>
                  ) : null}
                </div>
              </Card>
            );
          })}

          {data.accounts.length === 0 ? (
            <Card className="flex flex-col items-center px-6 py-12 text-center">
              <CircleAlert className="size-8 text-neutral-300" aria-hidden />
              <p className="mt-3 text-sm text-neutral-500">
                No fee account yet. Post a charge or apply the fee structure to open one.
              </p>
            </Card>
          ) : null}
        </div>
      </div>
    </div>
  );
}
