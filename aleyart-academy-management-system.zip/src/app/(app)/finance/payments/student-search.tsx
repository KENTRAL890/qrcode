"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { Search } from "lucide-react";
import { Card, inputClasses, buttonClasses } from "@/components/ui";

export function StudentSearch({
  initialQuery,
  matches,
}: {
  initialQuery: string;
  matches: Array<{ id: string; fullName: string; studentCode: string; className: string | null }>;
}) {
  const router = useRouter();

  function submit(formData: FormData) {
    const q = String(formData.get("q") ?? "").trim();
    router.push(q ? `/finance/payments?q=${encodeURIComponent(q)}` : "/finance/payments");
  }

  return (
    <Card className="p-4">
      <form action={submit} className="flex flex-wrap items-end gap-3">
        <div className="min-w-56 flex-1">
          <label htmlFor="fee-student-search" className="mb-1.5 block text-[12px] font-semibold text-neutral-500">
            Find student by name or Student ID
          </label>
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-neutral-400" aria-hidden />
            <input
              id="fee-student-search"
              name="q"
              defaultValue={initialQuery}
              placeholder="e.g. ALA-2026-0001 or Ama Serwaa"
              className={`${inputClasses} pl-9`}
            />
          </div>
        </div>
        <button type="submit" className={buttonClasses("primary")}>
          <Search className="size-4" aria-hidden /> Search
        </button>
      </form>

      {matches.length > 0 ? (
        <ul className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {matches.map((m) => (
            <li key={m.id}>
              <Link
                href={`/finance/payments?studentId=${m.id}`}
                className="flex items-center justify-between gap-3 rounded-xl border border-neutral-200 px-3.5 py-2.5 transition-colors hover:border-orange-300 hover:bg-orange-50/50"
              >
                <span className="min-w-0">
                  <span className="block truncate text-[13px] font-semibold text-neutral-800">{m.fullName}</span>
                  <span className="font-mono text-[11px] text-orange-600">{m.studentCode}</span>
                </span>
                <span className="shrink-0 text-xs text-neutral-400">{m.className ?? "—"}</span>
              </Link>
            </li>
          ))}
        </ul>
      ) : null}
    </Card>
  );
}
