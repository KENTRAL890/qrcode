import { and, asc, desc, eq, ilike, or } from "drizzle-orm";
import { db } from "@/db";
import {
  academicYears,
  classes,
  feeCategories,
  feeCharges,
  feePayments,
  students,
  studentFeeAccounts,
  terms,
} from "@/db/schema";
import { requirePermission, userHasPermission } from "@/lib/auth";
import { PageHeader } from "@/components/page-header";
import { Card } from "@/components/ui";
import { PaymentsClient, type AccountView } from "./payments-client";
import { StudentSearch } from "./student-search";

export const dynamic = "force-dynamic";

export const metadata = { title: "Payments" };

export default async function PaymentsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const actor = await requirePermission("fees.view");
  const canRecord = userHasPermission(actor, "payments.record");
  const canReverse = userHasPermission(actor, "payments.reverse");
  const canCharge = userHasPermission(actor, "fees.manage");

  const sp = await searchParams;
  const q = (typeof sp.q === "string" ? sp.q : "").trim();
  const studentId = typeof sp.studentId === "string" ? sp.studentId : "";

  // Student lookup
  let matches: Array<{ id: string; fullName: string; studentCode: string; className: string | null }> = [];
  if (q && !studentId) {
    const pattern = `%${q.replaceAll("%", "\\%").replaceAll("_", "\\_")}%`;
    matches = await db
      .select({
        id: students.id,
        fullName: students.fullName,
        studentCode: students.studentCode,
        className: classes.name,
      })
      .from(students)
      .leftJoin(classes, eq(classes.id, students.classId))
      .where(or(ilike(students.fullName, pattern), ilike(students.studentCode, pattern)))
      .orderBy(asc(students.fullName))
      .limit(12);
  }

  let account: AccountView | null = null;
  if (studentId) {
    const [student] = await db
      .select({
        id: students.id,
        fullName: students.fullName,
        studentCode: students.studentCode,
        className: classes.name,
        status: students.status,
      })
      .from(students)
      .leftJoin(classes, eq(classes.id, students.classId))
      .where(eq(students.id, studentId))
      .limit(1);

    if (student) {
      const accounts = await db
        .select({
          id: studentFeeAccounts.id,
          termId: studentFeeAccounts.termId,
          totalCharged: studentFeeAccounts.totalCharged,
          totalPaid: studentFeeAccounts.totalPaid,
          outstanding: studentFeeAccounts.outstanding,
          termName: terms.name,
          yearName: academicYears.name,
          className: classes.name,
        })
        .from(studentFeeAccounts)
        .innerJoin(terms, eq(terms.id, studentFeeAccounts.termId))
        .innerJoin(academicYears, eq(academicYears.id, studentFeeAccounts.academicYearId))
        .leftJoin(classes, eq(classes.id, studentFeeAccounts.classId))
        .where(eq(studentFeeAccounts.studentId, studentId))
        .orderBy(desc(academicYears.name), asc(terms.createdAt));

      const charges = await db
        .select({
          id: feeCharges.id,
          accountId: feeCharges.accountId,
          description: feeCharges.description,
          amount: feeCharges.amount,
          kind: feeCharges.kind,
          status: feeCharges.status,
          createdAt: feeCharges.createdAt,
        })
        .from(feeCharges)
        .where(eq(feeCharges.studentId, studentId))
        .orderBy(desc(feeCharges.createdAt));

      const payments = await db
        .select({
          id: feePayments.id,
          accountId: feePayments.accountId,
          receiptNumber: feePayments.receiptNumber,
          amount: feePayments.amount,
          method: feePayments.method,
          paidAt: feePayments.paidAt,
          status: feePayments.status,
          reference: feePayments.reference,
          receivedByName: feePayments.receivedByName,
        })
        .from(feePayments)
        .where(eq(feePayments.studentId, studentId))
        .orderBy(desc(feePayments.paidAt));

      account = {
        student: {
          id: student.id,
          fullName: student.fullName,
          studentCode: student.studentCode,
          className: student.className,
          status: student.status,
        },
        accounts: accounts.map((a) => ({
          ...a,
          paidAt: null,
        })),
        charges: charges.map((c) => ({ ...c, createdAt: c.createdAt.toISOString() })),
        payments: payments.map((p) => ({ ...p, paidAt: p.paidAt.toISOString() })),
      };
    }
  }

  const termRows = await db
    .select({ id: terms.id, name: terms.name, yearName: academicYears.name, isCurrent: terms.isCurrent })
    .from(terms)
    .innerJoin(academicYears, eq(academicYears.id, terms.academicYearId))
    .where(eq(academicYears.isArchived, false))
    .orderBy(asc(academicYears.name), asc(terms.createdAt));

  const categories = await db
    .select({ id: feeCategories.id, name: feeCategories.name })
    .from(feeCategories)
    .where(eq(feeCategories.isActive, true))
    .orderBy(asc(feeCategories.name));

  void and;

  return (
    <div className="anim-fade-up space-y-6">
      <PageHeader
        title="Fees & Payments"
        description="Search a student to view their ledger, post charges, record payments and issue permanent receipts (ALA-RCP-YYYY-######)."
      />

      <StudentSearch initialQuery={q} matches={matches} />

      {account ? (
        <PaymentsClient
          data={account}
          terms={termRows.map((t) => ({
            id: t.id,
            name: `${t.yearName} · ${t.name}`,
            isCurrent: t.isCurrent,
          }))}
          categories={categories}
          canRecord={canRecord}
          canReverse={canReverse}
          canCharge={canCharge}
        />
      ) : (
        <Card className="px-6 py-14 text-center">
          <p className="text-sm text-neutral-500">
            {q ? "Select a student from the results above." : "Search for a student by name or Student ID."}
          </p>
        </Card>
      )}
    </div>
  );
}
