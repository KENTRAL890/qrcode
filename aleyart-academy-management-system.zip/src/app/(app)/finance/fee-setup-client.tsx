"use client";

import { useActionState, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Plus, Power, Wallet, Tag, X } from "lucide-react";
import {
  createFeeCategoryAction,
  saveFeeStructureAction,
  toggleFeeCategoryAction,
} from "@/lib/actions/finance-actions";
import type { FormState } from "@/lib/actions/auth-actions";
import { Alert, Badge, Card, inputClasses, buttonClasses } from "@/components/ui";
import { SubmitButton } from "@/components/ui-client";
import { formatMoney } from "@/lib/format";
import { cn } from "@/lib/utils";

export interface StructureRow {
  id: string;
  amount: string;
  categoryName: string;
  className: string;
  termName: string;
  yearName: string;
}

export function FeeSetupClient({
  categories,
  classes,
  terms,
  structures,
  canManage,
}: {
  categories: Array<{ id: string; name: string; code: string; isActive: boolean; isRecurring: boolean }>;
  classes: Array<{ id: string; name: string }>;
  terms: Array<{ id: string; name: string; isCurrent: boolean }>;
  structures: StructureRow[];
  canManage: boolean;
}) {
  const [catState, catAction] = useActionState<FormState | null, FormData>(createFeeCategoryAction, null);
  const [structState, structAction] = useActionState<FormState | null, FormData>(saveFeeStructureAction, null);
  const [showCat, setShowCat] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  if (catState?.ok || structState?.ok) router.refresh();

  return (
    <div className="grid grid-cols-1 gap-5 xl:grid-cols-[0.85fr_1.15fr]">
      {/* Categories */}
      <div className="space-y-4">
        <Card className="p-5">
          <div className="mb-4 flex items-center justify-between gap-3">
            <h2 className="flex items-center gap-2 font-display text-base font-bold text-neutral-900">
              <Tag className="size-4 text-orange-500" aria-hidden /> Fee categories
            </h2>
            {canManage ? (
              <button onClick={() => setShowCat((v) => !v)} className={buttonClasses(showCat ? "ghost" : "secondary")}>
                {showCat ? <X className="size-4" /> : <Plus className="size-4" />}
                {showCat ? "Close" : "New"}
              </button>
            ) : null}
          </div>

          {showCat && canManage ? (
            <form action={catAction} className="mb-5 space-y-3 rounded-xl border border-neutral-100 bg-neutral-50/60 p-4">
              {catState?.error ? <Alert>{catState.error}</Alert> : null}
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Name</label>
                  <input name="name" required maxLength={80} className={inputClasses} placeholder="e.g. Transport" />
                </div>
                <div>
                  <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Code</label>
                  <input name="code" required maxLength={20} className={inputClasses} placeholder="e.g. TRANSPORT" />
                </div>
              </div>
              <div>
                <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Description</label>
                <input name="description" maxLength={300} className={inputClasses} placeholder="optional" />
              </div>
              <label className="inline-flex items-center gap-2 text-xs font-semibold text-neutral-600">
                <input type="checkbox" name="isRecurring" defaultChecked className="size-3.5 accent-orange-500" />
                Recurring each term
              </label>
              <div className="flex justify-end">
                <SubmitButton pendingText="Creating…">
                  <Plus className="size-4" /> Create category
                </SubmitButton>
              </div>
            </form>
          ) : null}

          <ul className="space-y-1.5">
            {categories.map((c) => (
              <li
                key={c.id}
                className={cn(
                  "flex items-center gap-3 rounded-xl border border-neutral-100 px-3.5 py-2.5",
                  !c.isActive && "opacity-60",
                )}
              >
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[13px] font-semibold text-neutral-800">{c.name}</span>
                  <span className="font-mono text-[10.5px] text-neutral-400">{c.code}</span>
                </span>
                <Badge tone={c.isRecurring ? "orange" : "neutral"}>{c.isRecurring ? "recurring" : "one-off"}</Badge>
                <Badge tone={c.isActive ? "green" : "rose"}>{c.isActive ? "active" : "inactive"}</Badge>
                {canManage ? (
                  <button
                    type="button"
                    disabled={pending}
                    onClick={() =>
                      startTransition(async () => {
                        await toggleFeeCategoryAction(c.id);
                        router.refresh();
                      })
                    }
                    title={c.isActive ? "Deactivate" : "Activate"}
                    className="rounded-lg p-1.5 text-neutral-400 transition-colors hover:bg-neutral-100 hover:text-neutral-700"
                  >
                    <Power className="size-3.5" />
                  </button>
                ) : null}
              </li>
            ))}
            {categories.length === 0 ? (
              <li className="rounded-xl border border-dashed border-neutral-200 px-4 py-6 text-center text-xs text-neutral-400">
                No fee categories yet.
              </li>
            ) : null}
          </ul>
        </Card>
      </div>

      {/* Structures */}
      <div className="space-y-4">
        {canManage ? (
          <Card className="p-5">
            <h2 className="mb-4 flex items-center gap-2 font-display text-base font-bold text-neutral-900">
              <Wallet className="size-4 text-orange-500" aria-hidden /> Set amount per class &amp; term
            </h2>
            <form action={structAction} className="space-y-3">
              {structState?.error ? <Alert>{structState.error}</Alert> : null}
              {structState?.ok ? <Alert tone="success">Fee structure saved.</Alert> : null}
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Category</label>
                  <select name="categoryId" required className={inputClasses}>
                    <option value="">Choose…</option>
                    {categories.filter((c) => c.isActive).map((c) => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Class</label>
                  <select name="classId" required className={inputClasses}>
                    <option value="">Choose…</option>
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Term</label>
                  <select name="termId" required className={inputClasses}>
                    <option value="">Choose…</option>
                    {terms.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name}{t.isCurrent ? " (current)" : ""}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="mb-1.5 block text-[12px] font-semibold text-neutral-600">Amount (GHS)</label>
                  <input
                    name="amount"
                    required
                    inputMode="decimal"
                    pattern="^\d{1,9}(\.\d{1,2})?$"
                    className={inputClasses}
                    placeholder="e.g. 350.00"
                  />
                </div>
              </div>
              <div className="flex justify-end">
                <SubmitButton pendingText="Saving…">
                  <Wallet className="size-4" /> Save fee amount
                </SubmitButton>
              </div>
            </form>
          </Card>
        ) : null}

        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px] text-left text-sm">
              <thead>
                <tr className="border-b border-neutral-100 bg-neutral-50/60 text-[11px] uppercase tracking-wider text-neutral-400">
                  <th className="px-5 py-3 font-semibold">Year · Term</th>
                  <th className="px-3 py-3 font-semibold">Class</th>
                  <th className="px-3 py-3 font-semibold">Category</th>
                  <th className="px-5 py-3 text-right font-semibold">Amount</th>
                </tr>
              </thead>
              <tbody>
                {structures.map((s) => (
                  <tr key={s.id} className="border-b border-neutral-50 hover:bg-orange-50/25">
                    <td className="px-5 py-2.5 text-xs tabular-nums text-neutral-500">
                      {s.yearName} · {s.termName}
                    </td>
                    <td className="px-3 py-2.5 text-[13px] font-medium text-neutral-700">{s.className}</td>
                    <td className="px-3 py-2.5 text-[13px] text-neutral-600">{s.categoryName}</td>
                    <td className="px-5 py-2.5 text-right text-[13px] font-bold tabular-nums text-neutral-800">
                      {formatMoney(s.amount)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {structures.length === 0 ? (
            <p className="px-6 py-10 text-center text-sm text-neutral-400">
              No fee structure lines defined yet.
            </p>
          ) : null}
        </Card>
      </div>
    </div>
  );
}
