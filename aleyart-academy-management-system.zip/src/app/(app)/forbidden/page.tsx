import Link from "next/link";
import { ShieldAlert, ArrowLeft } from "lucide-react";
import { requireUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const metadata = { title: "Access denied" };

export default async function ForbiddenPage() {
  const user = await requireUser();

  return (
    <div className="anim-fade-up flex min-h-[60vh] items-center justify-center">
      <div className="max-w-md text-center">
        <div className="mx-auto flex size-16 items-center justify-center rounded-3xl bg-rose-100 text-rose-500">
          <ShieldAlert className="size-8" aria-hidden />
        </div>
        <h1 className="mt-6 font-display text-2xl font-bold tracking-tight text-neutral-900">
          Access restricted
        </h1>
        <p className="mt-2 text-sm leading-relaxed text-neutral-500">
          Hi {user.fullName.split(" ")[0]}, your account does not have permission to open this
          area. If you believe this is a mistake, ask a Super Administrator to review your roles
          under <span className="font-semibold">Users &amp; Roles</span>.
        </p>
        <Link
          href="/dashboard"
          className="mt-6 inline-flex items-center gap-2 rounded-xl bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white shadow-[0_8px_20px_-8px_rgba(249,115,22,0.65)] transition-colors hover:bg-orange-600"
        >
          <ArrowLeft className="size-4" aria-hidden />
          Back to dashboard
        </Link>
      </div>
    </div>
  );
}
