import Link from "next/link";
import { asc, desc, eq, like, and, count as dcount } from "drizzle-orm";
import { Filter, ChevronLeft, ChevronRight, ScrollText, LockKeyhole } from "lucide-react";
import { db } from "@/db";
import { auditLogs, users } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { PageHeader } from "@/components/page-header";
import { Badge, Card, inputClasses } from "@/components/ui";
import { timeAgo, formatDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";

export const dynamic = "force-dynamic";

export const metadata = { title: "Audit Log" };

const PAGE_SIZE = 25;

export default async function AuditPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  await requirePermission("audit.view");
  const sp = await searchParams;
  const entity = typeof sp.entity === "string" ? sp.entity : "";
  const action = typeof sp.action === "string" ? sp.action : "";
  const page = Math.max(1, Number(typeof sp.page === "string" ? sp.page : "1") || 1);

  const conditions = [];
  if (entity) conditions.push(eq(auditLogs.entity, entity));
  if (action) conditions.push(like(auditLogs.action, `${action}%`));

  const where = conditions.length > 0 ? and(...conditions) : undefined;

  const [entities, [{ value: total }], rows] = await Promise.all([
    db
      .selectDistinct({ entity: auditLogs.entity })
      .from(auditLogs)
      .orderBy(asc(auditLogs.entity)),
    db.select({ value: dcount() }).from(auditLogs).where(where),
    db
      .select({
        id: auditLogs.id,
        action: auditLogs.action,
        entity: auditLogs.entity,
        entityId: auditLogs.entityId,
        details: auditLogs.details,
        ipAddress: auditLogs.ipAddress,
        createdAt: auditLogs.createdAt,
        username: users.username,
        fullName: users.fullName,
      })
      .from(auditLogs)
      .leftJoin(users, eq(users.id, auditLogs.userId))
      .where(where)
      .orderBy(desc(auditLogs.createdAt))
      .limit(PAGE_SIZE)
      .offset((page - 1) * PAGE_SIZE),
  ]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  const queryFor = (p: number) => {
    const params = new URLSearchParams();
    if (entity) params.set("entity", entity);
    if (action) params.set("action", action);
    params.set("page", String(p));
    return `/admin/audit?${params.toString()}`;
  };

  return (
    <div className="anim-fade-up space-y-6">
      <PageHeader
        title="Audit Log"
        description="Append-only record of every sensitive event: sign-ins, branding changes, user management, academic configuration and more."
      >
        <div className="flex items-center gap-2">
          <Badge tone="neutral">{total} event{total === 1 ? "" : "s"}</Badge>
          <Badge tone="amber">
            <LockKeyhole className="size-3" aria-hidden /> tamper-evident
          </Badge>
        </div>
      </PageHeader>

      {/* Filters */}
      <Card className="p-4">
        <form method="GET" className="flex flex-wrap items-end gap-3">
          <div className="min-w-44 flex-1 sm:max-w-56">
            <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">Entity</label>
            <select name="entity" defaultValue={entity} className={inputClasses}>
              <option value="">All entities</option>
              {entities.map((e) => (
                <option key={e.entity} value={e.entity}>
                  {e.entity}
                </option>
              ))}
            </select>
          </div>
          <div className="min-w-44 flex-1 sm:max-w-64">
            <label className="mb-1.5 block text-[12px] font-semibold text-neutral-500">Action prefix</label>
            <input
              name="action"
              defaultValue={action}
              placeholder="e.g. settings."
              className={inputClasses}
            />
          </div>
          <button
            type="submit"
            className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-orange-600"
          >
            <Filter className="size-4" aria-hidden />
            Filter
          </button>
          {(entity || action) && (
            <Link href="/admin/audit" className="rounded-xl px-3 py-2.5 text-sm font-semibold text-neutral-500 hover:bg-neutral-100">
              Clear
            </Link>
          )}
        </form>
      </Card>

      {/* Table */}
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[820px] text-left text-sm">
            <thead>
              <tr className="border-b border-neutral-100 bg-neutral-50/60 text-[11px] uppercase tracking-wider text-neutral-400">
                <th className="px-5 py-3.5 font-semibold">When</th>
                <th className="px-4 py-3.5 font-semibold">Actor</th>
                <th className="px-4 py-3.5 font-semibold">Action</th>
                <th className="px-4 py-3.5 font-semibold">Entity</th>
                <th className="px-4 py-3.5 font-semibold">Details</th>
                <th className="px-4 py-3.5 font-semibold">IP</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id} className="border-b border-neutral-50 align-top transition-colors hover:bg-orange-50/30">
                  <td className="whitespace-nowrap px-5 py-3.5">
                    <p className="text-[13px] font-medium text-neutral-700">{timeAgo(row.createdAt)}</p>
                    <p className="text-[11px] tabular-nums text-neutral-400">{formatDateTime(row.createdAt)}</p>
                  </td>
                  <td className="px-4 py-3.5">
                    <p className="max-w-40 truncate text-[13px] font-semibold text-neutral-800">
                      {row.fullName ?? "System"}
                    </p>
                    <p className="font-mono text-[11px] text-neutral-400">{row.username ?? "—"}</p>
                  </td>
                  <td className="px-4 py-3.5">
                    <span
                      className={cn(
                        "inline-block rounded-lg px-2 py-1 font-mono text-[11px] font-semibold",
                        row.action.startsWith("settings")
                          ? "bg-orange-100 text-orange-700"
                          : row.action.startsWith("auth")
                            ? "bg-neutral-100 text-neutral-600"
                            : row.action.startsWith("user")
                              ? "bg-pink-100 text-pink-700"
                              : "bg-sky-100 text-sky-700",
                      )}
                    >
                      {row.action}
                    </span>
                  </td>
                  <td className="px-4 py-3.5 text-xs text-neutral-600">
                    <p className="font-semibold">{row.entity}</p>
                    {row.entityId ? (
                      <p className="mt-0.5 max-w-36 truncate font-mono text-[10.5px] text-neutral-400">
                        {row.entityId}
                      </p>
                    ) : null}
                  </td>
                  <td className="px-4 py-3.5">
                    {row.details ? (
                      <pre className="max-w-xs overflow-x-auto whitespace-pre-wrap break-words rounded-lg bg-neutral-50 px-2.5 py-2 font-mono text-[10.5px] leading-relaxed text-neutral-500">
                        {JSON.stringify(row.details, null, 1)}
                      </pre>
                    ) : (
                      <span className="text-xs text-neutral-300">—</span>
                    )}
                  </td>
                  <td className="px-4 py-3.5 font-mono text-[11px] text-neutral-400">{row.ipAddress ?? "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {rows.length === 0 ? (
          <div className="flex flex-col items-center px-6 py-14 text-center">
            <ScrollText className="size-8 text-neutral-300" aria-hidden />
            <p className="mt-3 text-sm text-neutral-500">No audit events match your filters.</p>
          </div>
        ) : null}

        {/* Pagination */}
        <div className="flex items-center justify-between border-t border-neutral-100 px-5 py-3.5 text-xs text-neutral-500">
          <span>
            Page {page} of {totalPages}
          </span>
          <div className="flex items-center gap-2">
            <Link
              href={queryFor(Math.max(1, page - 1))}
              aria-disabled={page <= 1}
              className={cn(
                "inline-flex items-center gap-1 rounded-lg border px-2.5 py-1.5 font-semibold",
                page <= 1
                  ? "pointer-events-none border-neutral-100 text-neutral-300"
                  : "border-neutral-200 text-neutral-600 hover:border-orange-300 hover:text-orange-600",
              )}
            >
              <ChevronLeft className="size-3.5" /> Prev
            </Link>
            <Link
              href={queryFor(Math.min(totalPages, page + 1))}
              aria-disabled={page >= totalPages}
              className={cn(
                "inline-flex items-center gap-1 rounded-lg border px-2.5 py-1.5 font-semibold",
                page >= totalPages
                  ? "pointer-events-none border-neutral-100 text-neutral-300"
                  : "border-neutral-200 text-neutral-600 hover:border-orange-300 hover:text-orange-600",
              )}
            >
              Next <ChevronRight className="size-3.5" />
            </Link>
          </div>
        </div>
      </Card>
    </div>
  );
}
