"use client";

import { useActionState, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  UserPlus,
  ShieldCheck,
  KeyRound,
  Ban,
  CircleCheck,
  ChevronDown,
  X,
  Users as UsersIcon,
} from "lucide-react";
import {
  createUserAction,
  setUserStatusAction,
  updateUserRolesAction,
  resetUserPasswordAction,
} from "@/lib/actions/user-actions";
import type { FormState } from "@/lib/actions/auth-actions";
import { ROLE_LABELS, ROLE_NAMES } from "@/lib/permissions";
import { Alert, Badge, Card, Field, inputClasses, buttonClasses } from "@/components/ui";
import { SubmitButton } from "@/components/ui-client";
import { initials, formatDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";

export interface AdminUserRow {
  id: string;
  username: string;
  fullName: string;
  status: string;
  lastLoginAt: string | null;
  createdAt: string;
  mustChangePassword: boolean;
  roles: string[];
}

function RoleChip({ role }: { role: string }) {
  const tone = role === "super_admin" ? "pink" : role === "admin" ? "orange" : "neutral";
  return <Badge tone={tone}>{ROLE_LABELS[role] ?? role}</Badge>;
}

/* ------------------------------------------------------------------ */
/* Create user form                                                    */
/* ------------------------------------------------------------------ */

function CreateUserForm({ onDone }: { onDone: () => void }) {
  const [state, formAction] = useActionState<FormState | null, FormData>(createUserAction, null);
  const router = useRouter();
  const [lastOk, setLastOk] = useState(false);

  if (state?.ok && !lastOk) {
    setLastOk(true);
    router.refresh();
  }

  return (
    <form action={formAction} className="space-y-5" autoComplete="off">
      {state?.error ? <Alert>{state.error}</Alert> : null}
      {state?.ok ? (
        <Alert tone="success">
          Account created. The user must change their temporary password on first sign-in.
        </Alert>
      ) : null}

      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Username" hint="3–40 chars · lowercase letters, numbers, . _ -">
          <input name="username" required className={inputClasses} placeholder="e.g. mary.osei" />
        </Field>
        <Field label="Full name">
          <input name="fullName" required className={inputClasses} placeholder="e.g. Mary Osei" />
        </Field>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Temporary password" hint="8+ chars with letters & numbers — changed at first login">
          <input name="password" required minLength={8} className={inputClasses} placeholder="Temporary password" />
        </Field>
        <div>
          <span className="mb-1.5 block text-[13px] font-semibold text-neutral-700">Roles</span>
          <div className="flex flex-wrap gap-2">
            {ROLE_NAMES.map((role) => (
              <label
                key={role}
                className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-neutral-200 bg-neutral-50 px-3 py-2 text-xs font-semibold text-neutral-600 transition-colors has-checked:border-orange-300 has-checked:bg-orange-50 has-checked:text-orange-700"
              >
                <input
                  type="checkbox"
                  name="roles"
                  value={role}
                  defaultChecked={role === "viewer"}
                  className="size-3.5 accent-orange-500"
                />
                {ROLE_LABELS[role]}
              </label>
            ))}
          </div>
        </div>
      </div>

      <div className="flex items-center justify-end gap-2 border-t border-neutral-100 pt-4">
        <button type="button" onClick={onDone} className={buttonClasses("ghost")}>
          <X className="size-4" aria-hidden /> Cancel
        </button>
        <SubmitButton pendingText="Creating account…">
          <UserPlus className="size-4" aria-hidden /> Create account
        </SubmitButton>
      </div>
    </form>
  );
}

/* ------------------------------------------------------------------ */
/* Row action panels                                                   */
/* ------------------------------------------------------------------ */

function RolesEditor({
  user,
  disabled,
  actorIsSuper,
  onClose,
}: {
  user: AdminUserRow;
  disabled: boolean;
  actorIsSuper: boolean;
  onClose: () => void;
}) {
  const [selected, setSelected] = useState<string[]>(user.roles);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  function toggle(role: string) {
    setSelected((prev) =>
      prev.includes(role) ? prev.filter((r) => r !== role) : [...prev, role],
    );
  }

  function save() {
    startTransition(async () => {
      const result = await updateUserRolesAction(user.id, selected);
      if (result.error) setMessage({ ok: false, text: result.error });
      else {
        setMessage({ ok: true, text: "Roles updated." });
        router.refresh();
        setTimeout(onClose, 500);
      }
    });
  }

  return (
    <div className="space-y-3">
      {message ? <Alert tone={message.ok ? "success" : "error"}>{message.text}</Alert> : null}
      <div className="flex flex-wrap gap-2">
        {ROLE_NAMES.map((role) => {
          const lockedSuper = role === "super_admin" && !actorIsSuper;
          return (
            <button
              key={role}
              type="button"
              disabled={disabled || pending || lockedSuper}
              onClick={() => toggle(role)}
              title={lockedSuper ? "Only a Super Administrator can assign this role" : undefined}
              className={cn(
                "rounded-xl border px-3 py-2 text-xs font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-50",
                selected.includes(role)
                  ? "border-orange-400 bg-orange-50 text-orange-700"
                  : "border-neutral-200 bg-white text-neutral-500 hover:border-neutral-300",
              )}
            >
              {ROLE_LABELS[role]}
            </button>
          );
        })}
      </div>
      <div className="flex items-center justify-end gap-2">
        <button type="button" onClick={onClose} className={buttonClasses("ghost")} disabled={pending}>
          Cancel
        </button>
        <button type="button" onClick={save} disabled={disabled || pending} className={buttonClasses("primary")}>
          {pending ? "Saving…" : "Save roles"}
        </button>
      </div>
    </div>
  );
}

function PasswordReset({ user, disabled, onClose }: { user: AdminUserRow; disabled: boolean; onClose: () => void }) {
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, startTransition] = useTransition();

  function save() {
    startTransition(async () => {
      const result = await resetUserPasswordAction(user.id, password);
      if (result.error) setMessage({ ok: false, text: result.error });
      else {
        setMessage({ ok: true, text: "Password reset — user must change it at next sign-in." });
        setPassword("");
        setTimeout(onClose, 900);
      }
    });
  }

  return (
    <div className="flex flex-wrap items-end gap-2.5">
      {message ? (
        <div className="w-full">
          <Alert tone={message.ok ? "success" : "error"}>{message.text}</Alert>
        </div>
      ) : null}
      <div className="min-w-52 flex-1">
        <input
          type="text"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="New temporary password (8+ chars, letters & numbers)"
          className={inputClasses}
          disabled={disabled || pending}
          autoComplete="off"
        />
      </div>
      <button type="button" onClick={save} disabled={disabled || pending || password.length < 8} className={buttonClasses("primary")}>
        {pending ? "Resetting…" : "Reset password"}
      </button>
      <button type="button" onClick={onClose} className={buttonClasses("ghost")} disabled={pending}>
        Cancel
      </button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Main client                                                         */
/* ------------------------------------------------------------------ */

export function UsersAdminClient({
  users,
  canManage,
  actorIsSuper,
  actorId,
}: {
  users: AdminUserRow[];
  canManage: boolean;
  actorIsSuper: boolean;
  actorId: string;
}) {
  const [creating, setCreating] = useState(false);
  const [openPanel, setOpenPanel] = useState<{ id: string; kind: "roles" | "password" } | null>(null);
  const [rowMessage, setRowMessage] = useState<Record<string, { ok: boolean; text: string }>>({});
  const [pendingId, startTransition] = useTransition();
  const router = useRouter();

  function toggleStatus(user: AdminUserRow) {
    startTransition(async () => {
      const nextStatus = user.status === "active" ? "disabled" : "active";
      const result = await setUserStatusAction(user.id, nextStatus);
      setRowMessage((prev) => ({
        ...prev,
        [user.id]: {
          ok: !result.error,
          text: result.error ?? (nextStatus === "active" ? "Account activated." : "Account deactivated and signed out."),
        },
      }));
      if (!result.error) router.refresh();
    });
  }

  return (
    <div className="space-y-5">
      {canManage ? (
        <div className="flex justify-end">
          <button onClick={() => setCreating((v) => !v)} className={buttonClasses(creating ? "secondary" : "primary")}>
            {creating ? <X className="size-4" aria-hidden /> : <UserPlus className="size-4" aria-hidden />}
            {creating ? "Close" : "New user"}
          </button>
        </div>
      ) : null}

      {creating && canManage ? (
        <Card className="anim-fade-up p-5 sm:p-6">
          <h2 className="mb-5 font-display text-base font-bold text-neutral-900">Create staff account</h2>
          <CreateUserForm onDone={() => setCreating(false)} />
        </Card>
      ) : null}

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-left text-sm">
            <thead>
              <tr className="border-b border-neutral-100 bg-neutral-50/60 text-[11px] uppercase tracking-wider text-neutral-400">
                <th className="px-5 py-3.5 font-semibold">Staff member</th>
                <th className="px-4 py-3.5 font-semibold">Username</th>
                <th className="px-4 py-3.5 font-semibold">Roles</th>
                <th className="px-4 py-3.5 font-semibold">Status</th>
                <th className="px-4 py-3.5 font-semibold">Last sign-in</th>
                {canManage ? <th className="px-4 py-3.5 text-right font-semibold">Actions</th> : null}
              </tr>
            </thead>
            <tbody>
              {users.map((user) => {
                const isSelf = user.id === actorId;
                const panelOpen = openPanel?.id === user.id ? openPanel.kind : null;
                const msg = rowMessage[user.id];
                return (
                  <FragmentRow
                    key={user.id}
                    user={user}
                    isSelf={isSelf}
                    panelOpen={panelOpen}
                    message={msg}
                    canManage={canManage}
                    actorIsSuper={actorIsSuper}
                    busy={pendingId}
                    onOpenPanel={(kind) => setOpenPanel(panelOpen === kind ? null : { id: user.id, kind })}
                    onClosePanel={() => setOpenPanel(null)}
                    onToggleStatus={() => toggleStatus(user)}
                  />
                );
              })}
            </tbody>
          </table>
        </div>
        {users.length === 0 ? (
          <div className="flex flex-col items-center px-6 py-14 text-center">
            <UsersIcon className="size-8 text-neutral-300" aria-hidden />
            <p className="mt-3 text-sm text-neutral-500">No staff accounts found.</p>
          </div>
        ) : null}
      </Card>
    </div>
  );
}

import { Fragment } from "react";

function FragmentRow(props: {
  user: AdminUserRow;
  isSelf: boolean;
  panelOpen: "roles" | "password" | null;
  message?: { ok: boolean; text: string };
  canManage: boolean;
  actorIsSuper: boolean;
  busy: boolean;
  onOpenPanel: (kind: "roles" | "password") => void;
  onClosePanel: () => void;
  onToggleStatus: () => void;
}) {
  const { user, panelOpen, message, canManage, actorIsSuper, isSelf } = props;
  const active = user.status === "active";
  return (
    <Fragment>
      <tr className="border-b border-neutral-50 transition-colors hover:bg-orange-50/30">
        <td className="px-5 py-3.5">
          <div className="flex items-center gap-3">
            <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-orange-100 to-pink-100 text-xs font-bold text-orange-700">
              {initials(user.fullName)}
            </span>
            <div className="min-w-0">
              <p className="truncate text-[13.5px] font-semibold text-neutral-800">
                {user.fullName}
                {isSelf ? <span className="ml-1.5 text-[10px] font-bold uppercase text-orange-500">(you)</span> : null}
              </p>
              {user.mustChangePassword ? (
                <p className="text-[10.5px] font-medium text-amber-600">Password change pending</p>
              ) : null}
            </div>
          </div>
        </td>
        <td className="px-4 py-3.5 font-mono text-xs text-neutral-600">{user.username}</td>
        <td className="px-4 py-3.5">
          <div className="flex flex-wrap gap-1.5">
            {user.roles.length > 0 ? user.roles.map((r) => <RoleChip key={r} role={r} />) : <span className="text-xs text-neutral-300">—</span>}
          </div>
        </td>
        <td className="px-4 py-3.5">
          <Badge tone={active ? "green" : "rose"}>
            <span className={cn("size-1.5 rounded-full", active ? "bg-emerald-500" : "bg-rose-500")} />
            {active ? "Active" : "Disabled"}
          </Badge>
        </td>
        <td className="px-4 py-3.5 text-xs tabular-nums text-neutral-500">
          {user.lastLoginAt ? formatDateTime(new Date(user.lastLoginAt)) : "Never"}
        </td>
        {canManage ? (
          <td className="px-4 py-3.5">
            <div className="flex items-center justify-end gap-1">
              <button
                onClick={() => props.onOpenPanel("roles")}
                title="Edit roles"
                className="rounded-lg p-2 text-neutral-400 transition-colors hover:bg-orange-50 hover:text-orange-600"
              >
                <ShieldCheck className="size-4" />
              </button>
              <button
                onClick={() => props.onOpenPanel("password")}
                title="Reset password"
                className="rounded-lg p-2 text-neutral-400 transition-colors hover:bg-amber-50 hover:text-amber-600"
              >
                <KeyRound className="size-4" />
              </button>
              <button
                onClick={props.onToggleStatus}
                title={active ? "Deactivate account" : "Activate account"}
                className={cn(
                  "rounded-lg p-2 transition-colors",
                  active
                    ? "text-neutral-400 hover:bg-rose-50 hover:text-rose-600"
                    : "text-rose-500 hover:bg-emerald-50 hover:text-emerald-600",
                )}
              >
                {active ? <Ban className="size-4" /> : <CircleCheck className="size-4" />}
              </button>
              <ChevronDown
                className={cn("size-3.5 text-neutral-300 transition-transform", panelOpen && "rotate-180")}
              />
            </div>
          </td>
        ) : null}
      </tr>
      {panelOpen || message ? (
        <tr className="bg-gradient-to-r from-orange-50/60 to-pink-50/40">
          <td colSpan={canManage ? 6 : 5} className="px-5 py-4">
            {message && !panelOpen ? (
              <Alert tone={message.ok ? "success" : "error"}>{message.text}</Alert>
            ) : null}
            {panelOpen === "roles" ? (
              <RolesEditor
                user={user}
                disabled={false}
                actorIsSuper={actorIsSuper}
                onClose={props.onClosePanel}
              />
            ) : null}
            {panelOpen === "password" ? (
              <PasswordReset user={user} disabled={false} onClose={props.onClosePanel} />
            ) : null}
          </td>
        </tr>
      ) : null}
    </Fragment>
  );
}
