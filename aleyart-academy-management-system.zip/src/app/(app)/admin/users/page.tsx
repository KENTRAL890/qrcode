import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { roles, userRoles, users } from "@/db/schema";
import { requirePermission, userHasPermission, isSuperAdmin } from "@/lib/auth";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui";
import { UsersAdminClient, type AdminUserRow } from "./users-admin-client";

export const dynamic = "force-dynamic";

export const metadata = { title: "Users & Roles" };

export default async function UsersPage() {
  const actor = await requirePermission("users.view");
  const canManage = userHasPermission(actor, "users.manage");

  const userRows = await db
    .select({
      id: users.id,
      username: users.username,
      fullName: users.fullName,
      status: users.status,
      lastLoginAt: users.lastLoginAt,
      createdAt: users.createdAt,
      mustChangePassword: users.mustChangePassword,
    })
    .from(users)
    .orderBy(asc(users.createdAt));

  const roleLinks = await db
    .select({ userId: userRoles.userId, name: roles.name })
    .from(userRoles)
    .innerJoin(roles, eq(roles.id, userRoles.roleId));

  const rolesByUser = new Map<string, string[]>();
  for (const link of roleLinks) {
    const list = rolesByUser.get(link.userId) ?? [];
    list.push(link.name);
    rolesByUser.set(link.userId, list);
  }

  const data: AdminUserRow[] = userRows.map((u) => ({
    id: u.id,
    username: u.username,
    fullName: u.fullName,
    status: u.status,
    lastLoginAt: u.lastLoginAt?.toISOString() ?? null,
    createdAt: u.createdAt.toISOString(),
    mustChangePassword: u.mustChangePassword,
    roles: rolesByUser.get(u.id) ?? [],
  }));

  return (
    <div className="anim-fade-up space-y-6">
      <PageHeader
        title="Users & Roles"
        description="Staff accounts, their roles and access control. Permissions are enforced on the server for every action."
      >
        <Badge tone="neutral">{userRows.length} account{userRows.length === 1 ? "" : "s"}</Badge>
      </PageHeader>

      <UsersAdminClient
        users={data}
        canManage={canManage}
        actorIsSuper={isSuperAdmin(actor)}
        actorId={actor.id}
      />
    </div>
  );
}
