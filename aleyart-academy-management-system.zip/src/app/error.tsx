"use client";

import { useEffect } from "react";
import { AlertTriangle, RotateCcw } from "lucide-react";

/**
 * Global error boundary. Deliberately shows no stack trace, SQL text or
 * internal identifiers to the browser — only a correlation digest that a
 * administrator can match against the server logs.
 */
export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Server-side details stay on the server; this is only for local debugging.
    console.error("[ui] unhandled error", error.digest ?? "");
  }, [error]);

  return (
    <main className="flex min-h-[70vh] items-center justify-center px-6">
      <div className="max-w-md text-center">
        <div className="mx-auto flex size-16 items-center justify-center rounded-3xl bg-rose-100 text-rose-500">
          <AlertTriangle className="size-8" aria-hidden />
        </div>
        <h1 className="mt-6 font-display text-2xl font-bold tracking-tight text-neutral-900">
          Something went wrong
        </h1>
        <p className="mt-2 text-sm leading-relaxed text-neutral-500">
          The action could not be completed. No partial changes were saved. Please try again, and
          contact your system administrator if the problem continues.
        </p>
        {error.digest ? (
          <p className="mt-3 font-mono text-[11px] text-neutral-400">Reference: {error.digest}</p>
        ) : null}
        <button
          onClick={reset}
          className="mt-6 inline-flex items-center gap-2 rounded-xl bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white shadow-[0_8px_20px_-8px_rgba(249,115,22,0.65)] transition-colors hover:bg-orange-600"
        >
          <RotateCcw className="size-4" aria-hidden />
          Try again
        </button>
      </div>
    </main>
  );
}
