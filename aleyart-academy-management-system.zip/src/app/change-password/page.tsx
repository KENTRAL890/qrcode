import { redirect } from "next/navigation";
import { KeyRound, ShieldCheck } from "lucide-react";
import { getCurrentUser } from "@/lib/auth";
import { SchoolCrest } from "@/components/brand";
import { getSchoolBranding } from "@/lib/school";
import { ChangePasswordForm } from "./change-password-form";

export const dynamic = "force-dynamic";

export default async function ChangePasswordPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (!user.mustChangePassword) redirect("/dashboard");

  const brand = await getSchoolBranding();

  return (
    <main className="relative flex min-h-dvh items-center justify-center px-4 py-10">
      <div
        aria-hidden
        className="absolute inset-0 -z-10"
        style={{
          backgroundImage:
            "radial-gradient(circle at 20% 15%, rgba(249,115,22,0.10) 0, transparent 40%), radial-gradient(circle at 85% 85%, rgba(236,72,153,0.09) 0, transparent 40%)",
        }}
      />
      <div className="w-full max-w-md">
        <div className="anim-fade-up rounded-3xl border border-neutral-200/70 bg-white p-6 shadow-[0_2px_4px_rgba(28,25,23,0.04),0_24px_56px_-24px_rgba(234,88,12,0.25)] sm:p-9">
          <div className="flex items-center gap-3.5">
            <div className="rounded-2xl bg-gradient-to-br from-orange-50 to-pink-50 p-1.5 ring-1 ring-orange-100">
              <SchoolCrest size={46} />
            </div>
            <div className="min-w-0">
              <p className="truncate font-display text-sm font-bold">{brand.schoolName}</p>
              <p className="text-[11px] italic text-orange-600">&ldquo;{brand.motto}&rdquo;</p>
            </div>
          </div>

          <div className="mt-7 flex size-12 items-center justify-center rounded-2xl bg-orange-100 text-orange-600">
            <KeyRound className="size-6" aria-hidden />
          </div>
          <h1 className="mt-4 font-display text-2xl font-bold tracking-tight text-neutral-900">
            Set a new password
          </h1>
          <p className="mt-2 text-sm leading-relaxed text-neutral-500">
            Hi {user.fullName.split(" ")[0]}, you signed in with a temporary or default password.
            For the security of <span className="font-semibold text-neutral-700">{brand.schoolName}</span> records,
            you must set your own password before continuing.
          </p>

          <div className="mt-5 flex items-start gap-2.5 rounded-xl border border-orange-100 bg-orange-50 px-3.5 py-3 text-xs text-orange-800">
            <ShieldCheck className="mt-0.5 size-4 shrink-0" aria-hidden />
            <ul className="space-y-1">
              <li>At least 8 characters with letters and numbers</li>
              <li>Must not be the default password or contain your username</li>
              <li>All other devices will be signed out automatically</li>
            </ul>
          </div>

          <ChangePasswordForm />
        </div>
      </div>
    </main>
  );
}
