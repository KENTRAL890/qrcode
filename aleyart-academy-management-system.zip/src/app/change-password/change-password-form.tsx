"use client";

import { useActionState, useState } from "react";
import { Check, Eye, EyeOff, KeyRound, ShieldCheck, X } from "lucide-react";
import { changePasswordAction, type FormState } from "@/lib/actions/auth-actions";
import { Alert, Field, inputClasses } from "@/components/ui";
import { SubmitButton } from "@/components/ui-client";
import { cn } from "@/lib/utils";

function StrengthRow({ ok, label }: { ok: boolean; label: string }) {
  return (
    <li className={cn("flex items-center gap-1.5 text-xs", ok ? "text-emerald-600" : "text-neutral-400")}>
      {ok ? <Check className="size-3.5" aria-hidden /> : <X className="size-3.5" aria-hidden />}
      {label}
    </li>
  );
}

export function ChangePasswordForm() {
  const [state, formAction] = useActionState<FormState | null, FormData>(changePasswordAction, null);
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);

  return (
    <form action={formAction} className="mt-7 space-y-5" autoComplete="off">
      {state?.error ? <Alert>{state.error}</Alert> : null}

      <Field label="Current password">
        <input
          name="currentPassword"
          type="password"
          required
          autoComplete="current-password"
          placeholder="Your temporary / current password"
          className={inputClasses}
        />
      </Field>

      <Field label="New password">
        <div className="relative">
          <input
            name="newPassword"
            type={show ? "text" : "password"}
            required
            minLength={8}
            autoComplete="new-password"
            placeholder="Choose a strong password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className={cn(inputClasses, "pr-11")}
          />
          <button
            type="button"
            onClick={() => setShow((v) => !v)}
            aria-label={show ? "Hide password" : "Show password"}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-neutral-400 transition-colors hover:bg-neutral-100 hover:text-neutral-600"
          >
            {show ? <EyeOff className="size-4" aria-hidden /> : <Eye className="size-4" aria-hidden />}
          </button>
        </div>
        <ul className="mt-2.5 grid grid-cols-2 gap-1">
          <StrengthRow ok={password.length >= 8} label="8+ characters" />
          <StrengthRow ok={/[a-zA-Z]/.test(password) && /[0-9]/.test(password)} label="Letters & numbers" />
        </ul>
      </Field>

      <Field label="Confirm new password">
        <input
          name="confirmPassword"
          type={show ? "text" : "password"}
          required
          minLength={8}
          autoComplete="new-password"
          placeholder="Repeat the new password"
          className={inputClasses}
        />
      </Field>

      <SubmitButton pendingText="Updating password…" className="w-full !py-3 text-[15px]">
        <ShieldCheck className="size-4" aria-hidden />
        Save password &amp; continue
      </SubmitButton>

      <p className="flex items-center justify-center gap-1.5 text-center text-xs text-neutral-400">
        <KeyRound className="size-3.5" aria-hidden />
        Passwords are stored only as secure one-way hashes.
      </p>
    </form>
  );
}
