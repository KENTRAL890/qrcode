import type { MetadataRoute } from "next";
import { getSchoolBranding } from "@/lib/school";

export const dynamic = "force-dynamic";

/** Installable PWA manifest — school name follows central settings. */
export default async function manifest(): Promise<MetadataRoute.Manifest> {
  const brand = await getSchoolBranding();
  return {
    name: `${brand.schoolName} — School Management System`,
    short_name: brand.schoolName.length > 12 ? "Aleyart SMS" : brand.schoolName,
    description: `${brand.schoolName}${brand.motto ? ` — ${brand.motto}` : ""}. School Management System.`,
    start_url: "/dashboard",
    display: "standalone",
    background_color: "#faf9f7",
    theme_color: "#f97316",
    icons: [
      { src: "/brand/default-crest.png", sizes: "192x192", type: "image/png" },
      { src: "/brand/default-crest.png", sizes: "512x512", type: "image/png" },
      { src: "/brand/default-crest.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
}
