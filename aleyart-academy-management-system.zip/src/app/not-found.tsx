import Link from "next/link";
import { Compass } from "lucide-react";
import { getSchoolBranding } from "@/lib/school";

export default async function NotFound() {
  const brand = await getSchoolBranding();

  return (
    <main className="flex min-h-dvh items-center justify-center px-6 bg-paper">
      <div className="max-w-md text-center">
        <p className="font-display text-7xl font-bold tracking-tight text-orange-500">404</p>
        <h1 className="mt-4 font-display text-xl font-bold text-neutral-900">
          This page wandered off the timetable
        </h1>
        <p className="mt-2 text-sm text-neutral-500">
          The link you followed does not exist in the {brand.schoolName} School Management System.
        </p>
        <Link
          href="/dashboard"
          className="mt-6 inline-flex items-center gap-2 rounded-xl bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-orange-600"
        >
          <Compass className="size-4" aria-hidden />
          Go to dashboard
        </Link>
      </div>
    </main>
  );
}
