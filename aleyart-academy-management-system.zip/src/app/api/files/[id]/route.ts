import { promises as fs } from "node:fs";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { fileMetadata } from "@/db/schema";
import { resolveUploadPath } from "@/lib/files";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Serves uploaded files (e.g. the school crest) by their database id.
 * Filenames live only in the file_metadata table; the client never supplies
 * a path, which prevents traversal. Unguessable UUID names prevent
 * enumeration. Content-Type is pinned from metadata and nosniff is enforced.
 */
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  if (!UUID_RE.test(id)) {
    return new Response("Not found", { status: 404 });
  }

  const [meta] = await db
    .select()
    .from(fileMetadata)
    .where(eq(fileMetadata.id, id))
    .limit(1);
  if (!meta) return new Response("Not found", { status: 404 });

  // Cloud object storage: the client is sent to the blob CDN URL directly.
  if (meta.storagePath.startsWith("http://") || meta.storagePath.startsWith("https://")) {
    return Response.redirect(meta.storagePath, 302);
  }

  const fullPath = resolveUploadPath(meta.storedFilename);
  if (!fullPath) return new Response("Not found", { status: 404 });

  let buffer: Buffer;
  try {
    buffer = await fs.readFile(fullPath);
  } catch {
    return new Response("Not found", { status: 404 });
  }

  return new Response(new Uint8Array(buffer), {
    headers: {
      "Content-Type": meta.mimeType,
      "Content-Length": String(buffer.length),
      "X-Content-Type-Options": "nosniff",
      "Content-Disposition": "inline",
      "Cache-Control": "public, max-age=31536000, immutable",
    },
  });
}
