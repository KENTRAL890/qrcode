import { and, asc, desc, eq, gte, ilike, lte, or, sql, sum, count as dcount } from "drizzle-orm";
import { db } from "@/db";
import {
  academicYears,
  classes,
  feePayments,
  students,
  studentFeeAccounts,
  terms,
} from "@/db/schema";
import { getCurrentUser, userHasPermission } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/http";
import { toCsv } from "@/lib/finance";
import { formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";

/**
 * CSV export of financial reports. Permission-checked server-side:
 * requires both `finance.reports` and `exports.data`.
 */
export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user) return new Response("Unauthorized", { status: 401 });
  if (!userHasPermission(user, "finance.reports") || !userHasPermission(user, "exports.data")) {
    return new Response("Forbidden", { status: 403 });
  }

  const url = new URL(request.url);
  const tab = url.searchParams.get("tab") ?? "daily";
  const from = url.searchParams.get("from") ?? "";
  const to = url.searchParams.get("to") ?? "";
  const termId = url.searchParams.get("termId") ?? "";
  const yearId = url.searchParams.get("yearId") ?? "";
  const classId = url.searchParams.get("classId") ?? "";
  const q = (url.searchParams.get("q") ?? "").trim();

  const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  const DATE = /^\d{4}-\d{2}-\d{2}$/;

  let headers: string[] = [];
  let rows: Array<Array<unknown>> = [];
  let filename = "financial-report.csv";

  if (tab === "term" || tab === "year") {
    const conds = [eq(feePayments.status, "active")];
    if (tab === "term" && UUID.test(termId)) conds.push(eq(feePayments.termId, termId));
    if (tab === "year" && UUID.test(yearId)) conds.push(eq(feePayments.academicYearId, yearId));

    const data = await db
      .select({
        yearName: academicYears.name,
        termName: terms.name,
        className: classes.name,
        total: sum(feePayments.amount),
        payments: dcount(),
      })
      .from(feePayments)
      .innerJoin(terms, eq(terms.id, feePayments.termId))
      .innerJoin(academicYears, eq(academicYears.id, feePayments.academicYearId))
      .leftJoin(classes, eq(classes.id, feePayments.classId))
      .where(and(...conds))
      .groupBy(academicYears.name, terms.name, classes.name, classes.sortOrder)
      .orderBy(asc(academicYears.name), asc(classes.sortOrder));

    headers = ["Academic Year", "Term", "Class", "Payments", "Total (GHS)"];
    rows = data.map((d) => [d.yearName, d.termName, d.className ?? "", Number(d.payments), d.total ?? "0.00"]);
    filename = `collections-by-${tab}.csv`;
  } else if (tab === "outstanding") {
    const conds = [sql`${studentFeeAccounts.outstanding} > 0`];
    if (UUID.test(termId)) conds.push(eq(studentFeeAccounts.termId, termId));
    if (UUID.test(yearId)) conds.push(eq(studentFeeAccounts.academicYearId, yearId));
    if (UUID.test(classId)) conds.push(eq(studentFeeAccounts.classId, classId));

    const data = await db
      .select({
        studentCode: studentFeeAccounts.studentCode,
        fullName: students.fullName,
        className: classes.name,
        yearName: academicYears.name,
        termName: terms.name,
        totalCharged: studentFeeAccounts.totalCharged,
        totalPaid: studentFeeAccounts.totalPaid,
        outstanding: studentFeeAccounts.outstanding,
      })
      .from(studentFeeAccounts)
      .innerJoin(students, eq(students.id, studentFeeAccounts.studentId))
      .innerJoin(terms, eq(terms.id, studentFeeAccounts.termId))
      .innerJoin(academicYears, eq(academicYears.id, studentFeeAccounts.academicYearId))
      .leftJoin(classes, eq(classes.id, studentFeeAccounts.classId))
      .where(and(...conds))
      .orderBy(desc(studentFeeAccounts.outstanding));

    headers = ["Student ID", "Student", "Class", "Academic Year", "Term", "Charged", "Paid", "Outstanding"];
    rows = data.map((d) => [
      d.studentCode,
      d.fullName,
      d.className ?? "",
      d.yearName,
      d.termName,
      d.totalCharged,
      d.totalPaid,
      d.outstanding,
    ]);
    filename = "outstanding-fees.csv";
  } else {
    const conds = [eq(feePayments.status, "active")];
    if (tab === "daily" && DATE.test(from) && DATE.test(to)) {
      conds.push(gte(feePayments.paidAt, new Date(`${from}T00:00:00Z`)));
      conds.push(lte(feePayments.paidAt, new Date(`${to}T23:59:59Z`)));
    }
    if (q) {
      const pattern = `%${q.replaceAll("%", "\\%").replaceAll("_", "\\_")}%`;
      conds.push(
        or(
          ilike(feePayments.receiptNumber, pattern),
          ilike(feePayments.studentCode, pattern),
          ilike(students.fullName, pattern),
        )!,
      );
    }
    if (UUID.test(classId)) conds.push(eq(feePayments.classId, classId));
    if (UUID.test(termId)) conds.push(eq(feePayments.termId, termId));

    const data = await db
      .select({
        receiptNumber: feePayments.receiptNumber,
        paidAt: feePayments.paidAt,
        studentCode: feePayments.studentCode,
        fullName: students.fullName,
        className: classes.name,
        yearName: academicYears.name,
        termName: terms.name,
        amount: feePayments.amount,
        method: feePayments.method,
        reference: feePayments.reference,
        receivedByName: feePayments.receivedByName,
      })
      .from(feePayments)
      .innerJoin(students, eq(students.id, feePayments.studentId))
      .innerJoin(terms, eq(terms.id, feePayments.termId))
      .innerJoin(academicYears, eq(academicYears.id, feePayments.academicYearId))
      .leftJoin(classes, eq(classes.id, feePayments.classId))
      .where(and(...conds))
      .orderBy(desc(feePayments.paidAt));

    headers = [
      "Receipt Number",
      "Date",
      "Student ID",
      "Student",
      "Class",
      "Academic Year",
      "Term",
      "Method",
      "Reference",
      "Received By",
      "Amount (GHS)",
    ];
    rows = data.map((d) => [
      d.receiptNumber,
      formatDate(d.paidAt),
      d.studentCode,
      d.fullName,
      d.className ?? "",
      d.yearName,
      d.termName,
      d.method,
      d.reference ?? "",
      d.receivedByName ?? "",
      d.amount,
    ]);
    filename = tab === "search" ? "receipt-search.csv" : "daily-collections.csv";
  }

  await logAudit({
    userId: user.id,
    action: "finance.exported",
    entity: "export",
    entityId: tab,
    details: { report: tab, rows: rows.length, format: "csv" },
    ipAddress: await getClientIp(),
  });

  return new Response(toCsv(headers, rows), {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
