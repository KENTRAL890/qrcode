# ALEYART ACADEMY — School Management System

A production-ready school management system built with **Next.js (App Router)**,
**TypeScript**, **Node.js** and **PostgreSQL** (Drizzle ORM). All important data
persists in PostgreSQL; nothing of record lives in local storage.

> **Central branding:** the school name, motto and crest are stored once in
> `school_settings`. Changing them in **School Settings** instantly updates the
> login page, dashboard, navigation, student directory, profiles, ID cards, QR
> verification page, terminal reports, receipts and every printable document.
> Finalized reports and receipts keep the snapshot captured at publication, so
> historical accounting and academic records stay accurate.

---

## Getting started

```bash
npm install
npx drizzle-kit push      # create/update tables
npm run build && npm start
```

The server seeds itself on first boot (roles, permissions, classes, subjects,
grading schemes, fee categories, school settings and the default admin).

### Default account

| Username | Password | Role |
|----------|----------|------|
| `admin`  | `admin123` | Super Administrator |

The password **must** be changed at first sign-in; the app forces the change
before any other page is reachable.

### Environment

| Variable | Purpose |
|----------|---------|
| `DATABASE_URL` | PostgreSQL connection string (required) |
| `NEXT_PUBLIC_APP_URL` | Optional absolute base URL used in printed QR codes |

---

## Feature overview

### Phase 1 — Foundation & branding
- Username/password authentication only (no email/social/OTP/magic links)
- bcrypt password hashing, DB-backed sessions, httpOnly `SameSite=Lax` cookies,
  absolute + idle expiry, login rate limiting and account lockout
- Five roles (Super Administrator, Administrator, Teacher, Office Staff, Viewer)
  with 28 permission codes enforced **server-side**
- School Settings with validated crest upload (JPG/JPEG/PNG/WEBP, MIME +
  magic-byte signature check, 2 MB cap, safe filenames, UUID storage)
- Classes Basic 1–9, academic years, terms, subjects, audit log

### Phase 2 — Students, IDs, QR, promotion
- Permanent Student ID `ALA-2026-0001` — never changes, survives promotion
- Permanent opaque QR token → `/verify/<token>` public endpoint
- Student photos, guardian/contact data, directory search & filters
- Academic history (one row per year), individual & bulk promotion in
  transactions, archive/restore
- CR80 ID cards (85.6 × 54 mm) printed at 100% actual size

### Phase 3 — Assessments, reports
- Class score (0–50) + exam score (0–50) = total (100), validated server-side
- Configurable grading schemes with overlap/gap protection
  (A/Advance 80–100, P 68–79, AP 54–67, D 40–53, B 0–39)
- Basic 7–9 aggregate: 4 core + 2 best electives on the 1–9 scale, DB-driven
- Competition ranking (1, 2, 2, 4) — dense ranking configurable
- A4 terminal reports; publishing freezes an immutable snapshot
- Status flow draft → published → locked; unlocking is permissioned + audited
- Report identity = student + academic year + term (never current class)

### Phase 4 — Finance, exports, hardening
- Fee categories, structures, student accounts, charges, payments, balances
- **Outstanding = charged − paid**, computed in integer minor units (no floats);
  all money columns are `NUMERIC(12,2)`
- Permanent receipt numbers `ALA-RCP-2026-000001`; reprints reuse the number
- Corrections by **reversal/adjustment only** — records are never overwritten
- Financial reports: daily, term, year, outstanding/arrears, receipt search,
  student statement; permission-checked CSV export (Excel-compatible, protected
  against CSV formula injection)
- Dashboard fed entirely by live SQL aggregates

---

## Verification

Executable acceptance suites live in `scripts/` and drive the real UI with a
headless browser against a running server:

```bash
npm start &                             # or: npx next start -p 3100
node scripts/accept-phase2.mjs          # students, IDs, QR, cards, promotion
node scripts/accept-phase3.mjs          # assessments, reports, snapshots, locking
node scripts/accept-final.mjs           # full 25-step end-to-end acceptance
node scripts/check-responsive.mjs       # 320 → 1920px overflow audit
node scripts/check-security.mjs         # security + accessibility audit
```

Latest results: **57/57** final acceptance · **220/220** responsive combinations
· **40/40** security & accessibility.

---

## Security notes

- Authorization is enforced in server actions and server components, never by
  hiding UI; teachers are scoped to their assigned classes and subjects
- Parameterised queries throughout (Drizzle) — no string-built SQL
- React escapes all rendered output; the only `dangerouslySetInnerHTML` use is
  a server-generated QR SVG
- Uploads are validated by extension, declared MIME **and** magic bytes, then
  stored under unguessable UUID filenames outside the public directory and
  served through a controlled route with `nosniff`
- Security headers: `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`,
  `Referrer-Policy`, `Permissions-Policy`
- The global error boundary shows a correlation digest only — never a stack
  trace, SQL text, secret or internal identifier
- The public QR page exposes only approved fields (crest, school name, photo,
  name, ID, class, year, status) — never guardians, addresses, finances or notes

## Backup

See **[docs/BACKUP-AND-RESTORE.md](docs/BACKUP-AND-RESTORE.md)** for the real
`pg_dump`/`pg_restore` procedures, cron scheduling, upload-directory handling
and post-restore verification. There is deliberately no in-app "backup" button,
because the web process cannot reliably perform or verify a full backup.
