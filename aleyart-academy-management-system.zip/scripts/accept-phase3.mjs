/* PHASE 3 acceptance test — assessments, reports, snapshots, locking. */
import { chromium } from 'playwright';
import { execSync } from 'node:child_process';

const BASE = 'http://localhost:3100';
const PSQL = 'psql postgresql://postgres:postgres@127.0.0.1:5432/app_db -t -A -c';
const q = (sql) => execSync(`${PSQL} "${sql}"`).toString().trim();

const pass = [], fail = [];
const ok = (c, l) => (c ? pass.push(l) : fail.push(l), console.log((c ? '  PASS ' : '  FAIL ') + l));

const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 1440, height: 1000 } })).newPage();

/* login */
await page.goto(`${BASE}/login`);
await page.fill('input[name="username"]', 'admin');
await page.fill('input[name="password"]', 'Aleyart#2026');
await page.click('button[type="submit"]');
await page.waitForURL('**/dashboard**');
ok(true, 'login');

/* ensure branding is the official one */
await page.goto(`${BASE}/settings/school`);
await page.fill('input[name="schoolName"]', 'ALEYART ACADEMY');
await page.fill('input[name="motto"]', 'Seeking Wisdom');
await page.getByRole('button', { name: 'Save changes' }).click();
await page.waitForTimeout(1200);

/* The Phase-2 student sits in Basic 2 / 2027-2028. Put results in Basic 2 / First Term 2027/2028. */
const studentCode = q(`select student_code from students limit 1`);
ok(studentCode === 'ALA-2026-0001', `student ${studentCode} present from Phase 2`);
const classId = q(`select class_id from students limit 1`);
const className = q(`select name from classes where id='${classId}'`);
const yearId = q(`select current_academic_year_id from students limit 1`);
const yearName = q(`select name from academic_years where id='${yearId}'`);
const termId = q(`select id from terms where academic_year_id='${yearId}' and name='First Term'`);
console.log(`  (context: ${className} / ${yearName} / First Term)`);

/* --- 1. enter results via the mark sheet ------------------------- */
await page.goto(`${BASE}/assessments?classId=${classId}&termId=${termId}`);
const subjectOptions = await page.locator('select').nth(2).locator('option').allTextContents();
ok(subjectOptions.length > 1, `subjects available for ${className} (${subjectOptions.length - 1})`);

const scores = [[45, 48], [40, 42], [33, 30], [25, 20], [44, 45], [38, 39], [30, 28], [42, 41], [36, 35], [29, 31]];
let entered = 0;
for (let i = 1; i < subjectOptions.length; i++) {
  await page.goto(`${BASE}/assessments?classId=${classId}&termId=${termId}`);
  const sel = page.locator('select').nth(2);
  const value = await sel.locator('option').nth(i).getAttribute('value');
  await page.goto(`${BASE}/assessments?classId=${classId}&termId=${termId}&subjectId=${value}`);
  const cs = page.locator('input[type="number"]').first();
  if (await cs.count() === 0) continue;
  const [c, e] = scores[(i - 1) % scores.length];
  await page.locator('input[type="number"]').nth(0).fill(String(c));
  await page.locator('input[type="number"]').nth(1).fill(String(e));
  await page.getByRole('button', { name: /Save mark sheet/ }).click();
  await page.waitForTimeout(700);
  entered++;
}
ok(entered > 0, `entered scores for ${entered} subjects`);
const assessCount = Number(q(`select count(*) from assessments where term_id='${termId}'`));
ok(assessCount === entered, `${assessCount} assessment rows persisted`);

/* server-side validation: reject class score > 50 */
const firstSubject = q(`select subject_id from assessments where term_id='${termId}' limit 1`);
await page.goto(`${BASE}/assessments?classId=${classId}&termId=${termId}&subjectId=${firstSubject}`);
await page.locator('input[type="number"]').nth(0).fill('77');
const saveBtn = page.getByRole('button', { name: /Save mark sheet/ });
ok(await saveBtn.isDisabled(), 'UI blocks class score > 50');

/* grade correctness: 45+48=93 -> A */
const topGrade = q(`select grade from assessments where term_id='${termId}' and total=93`);
ok(topGrade === 'A', 'total 93 graded A (Advance)');

/* --- 2. generate + publish the report ---------------------------- */
await page.goto(`${BASE}/reports`);
await page.locator('select').nth(0).selectOption(classId);
await page.locator('select').nth(1).selectOption(termId);
await page.getByRole('button', { name: /Generate class reports/ }).click();
await page.waitForTimeout(2000);
const reportId = q(`select id from terminal_reports where term_id='${termId}' limit 1`);
ok(Boolean(reportId), 'draft report generated');

await page.goto(`${BASE}/reports/${reportId}`);
let html = await page.content();
ok(html.includes('ALEYART ACADEMY'), 'draft report shows live school name');
ok(html.includes('Seeking Wisdom'), 'draft report shows live motto');
ok(html.includes(className), 'draft report shows historical class');
ok(html.includes('Draft preview'), 'draft banner shown');

await page.fill('input[placeholder*="hardworking"]', 'An attentive and consistent learner.');
await page.getByRole('button', { name: 'Save remarks' }).click();
await page.waitForTimeout(1000);
await page.getByRole('button', { name: 'Publish report' }).click();
await page.waitForTimeout(2000);
html = await page.content();
ok(html.includes('Historical snapshot'), 'report published with snapshot');
const snapName = q(`select snapshot->'school'->>'schoolName' from terminal_reports where id='${reportId}'`);
ok(snapName === 'ALEYART ACADEMY', 'snapshot froze school name');
const snapClass = q(`select snapshot->'academic'->>'className' from terminal_reports where id='${reportId}'`);
ok(snapClass === className, `snapshot froze historical class (${snapClass})`);

/* --- 3. lock it --------------------------------------------------- */
await page.getByRole('button', { name: 'Lock report' }).click();
await page.waitForTimeout(1500);
ok(q(`select status from terminal_reports where id='${reportId}'`) === 'locked', 'report locked');

/* locked reports block score edits (server-enforced) */
await page.goto(`${BASE}/assessments?classId=${classId}&termId=${termId}&subjectId=${firstSubject}`);
const firstInput = page.locator('input[type="number"]').first();
ok(await firstInput.isDisabled(), 'locked report makes mark sheet read-only');

/* --- 4. promote the student to a new class ------------------------ */
const studentUuid = q(`select id from students limit 1`);
const nextClassId = q(`select id from classes where sort_order=(select sort_order+1 from classes where id='${classId}')`);
const nextClassName = q(`select name from classes where id='${nextClassId}'`);
// promote into a brand-new year so history stays one row per year
await page.goto(`${BASE}/academic/years`);
if (!(await page.content()).includes('2028/2029')) {
  await page.getByRole('button', { name: 'New academic year' }).click();
  await page.fill('input[name="name"]', '2028/2029');
  await page.getByRole('button', { name: 'Create academic year' }).click();
  await page.waitForTimeout(1500);
}
const otherYearId = q(`select id from academic_years where name='2028/2029'`);
const otherYearName = '2028/2029';
ok(Boolean(otherYearId), 'academic year 2028/2029 available');
await page.goto(`${BASE}/students/${studentUuid}`);
await page.getByRole('button', { name: /Promote \/ transfer/ }).click();
await page.locator('select').nth(0).selectOption(nextClassId);
await page.locator('select').nth(1).selectOption(otherYearId);
await page.getByRole('button', { name: 'Confirm promotion' }).click();
await page.waitForTimeout(2000);
ok(q(`select name from classes where id=(select class_id from students where id='${studentUuid}')`) === nextClassName,
   `student promoted to ${nextClassName}`);
ok(q(`select student_code from students where id='${studentUuid}'`) === 'ALA-2026-0001', 'Student ID unchanged by promotion');

/* --- 5. historical report must be unchanged ----------------------- */
await page.goto(`${BASE}/reports/${reportId}`);
html = await page.content();
ok(html.includes(className), `locked report STILL shows original class ${className}`);
ok(!html.includes(`>${nextClassName}<`) || html.includes(className), 'locked report not rewritten by promotion');
ok(html.includes(yearName), `locked report still shows ${yearName}`);
ok(html.includes('ALEYART ACADEMY'), 'locked report still shows original school name');

/* --- 6. rebrand, then confirm old vs new ------------------------- */
await page.goto(`${BASE}/settings/school`);
await page.fill('input[name="schoolName"]', 'ROYAL CREST ACADEMY');
await page.fill('input[name="motto"]', 'Wisdom and Virtue');
await page.getByRole('button', { name: 'Save changes' }).click();
await page.waitForTimeout(1500);

await page.goto(`${BASE}/reports/${reportId}`);
html = await page.content();
const docOnly = html.split('report-page')[1] ?? html;
ok(docOnly.includes('ALEYART ACADEMY'), 'OLD locked report keeps ALEYART ACADEMY branding');
ok(docOnly.includes('Seeking Wisdom'), 'OLD locked report keeps original motto');

/* new report for the NEW class/term, generated after rebrand */
const newTermId = q(`select id from terms where academic_year_id='${otherYearId}' and name='First Term'`);
const newSubject = q(`select cs.subject_id from class_subjects cs where cs.class_id='${nextClassId}' limit 1`);
await page.goto(`${BASE}/assessments?classId=${nextClassId}&termId=${newTermId}&subjectId=${newSubject}`);
await page.locator('input[type="number"]').nth(0).fill('40');
await page.locator('input[type="number"]').nth(1).fill('44');
await page.getByRole('button', { name: /Save mark sheet/ }).click();
await page.waitForTimeout(1200);
await page.goto(`${BASE}/reports`);
await page.locator('select').nth(0).selectOption(nextClassId);
await page.locator('select').nth(1).selectOption(newTermId);
await page.getByRole('button', { name: /Generate class reports/ }).click();
await page.waitForTimeout(2000);
const newReportId = q(`select id from terminal_reports where term_id='${newTermId}' limit 1`);
ok(Boolean(newReportId) && newReportId !== reportId, 'new report created for new term');
await page.goto(`${BASE}/reports/${newReportId}`);
const newHtml = await page.content();
ok(newHtml.includes('ROYAL CREST ACADEMY'), 'NEW report uses UPDATED school name');
ok(newHtml.includes('Wisdom and Virtue'), 'NEW report uses UPDATED motto');
ok(newHtml.includes(nextClassName), `NEW report shows ${nextClassName}`);
await page.screenshot({ path: '/tmp/shot-report.png', fullPage: true });

/* --- 7. unlock requires permission + audit ------------------------ */
await page.goto(`${BASE}/reports/${reportId}`);
await page.getByRole('button', { name: 'Unlock report' }).click();
await page.fill('input[placeholder*="Correcting"]', 'Correcting a mis-entered exam score');
await page.getByRole('button', { name: 'Confirm unlock' }).click();
await page.waitForTimeout(1500);
ok(q(`select status from terminal_reports where id='${reportId}'`) === 'published', 'locked report unlocked');
ok(Number(q(`select count(*) from audit_logs where action='report.unlocked'`)) > 0, 'unlock recorded in audit log');
ok(Number(q(`select count(*) from audit_logs where action='report.published'`)) > 0, 'publish recorded in audit log');

/* restore official branding */
await page.goto(`${BASE}/settings/school`);
await page.fill('input[name="schoolName"]', 'ALEYART ACADEMY');
await page.fill('input[name="motto"]', 'Seeking Wisdom');
await page.getByRole('button', { name: 'Save changes' }).click();
await page.waitForTimeout(1200);

await browser.close();
console.log(`\n==== PHASE 3 RESULT: ${pass.length} passed, ${fail.length} failed ====`);
if (fail.length) { console.log('FAILED:', fail); process.exit(1); }
