/* FINAL END-TO-END ACCEPTANCE TEST — all 25 steps, from a clean database. */
import { chromium } from 'playwright';
import { execSync } from 'node:child_process';

const BASE = 'http://localhost:3100';
const DB = 'postgresql://postgres:postgres@127.0.0.1:5432/app_db';
const q = (sql) => execSync(`psql ${DB} -t -A -c "${sql.replaceAll('"', '\\"')}"`).toString().trim();
const exec = (sql) => execSync(`psql ${DB} -q -c "${sql.replaceAll('"', '\\"')}"`).toString();

const pass = [], fail = [];
const ok = (c, l) => (c ? pass.push(l) : fail.push(l), console.log((c ? '  PASS ' : '  FAIL ') + l));
const step = (n, t) => console.log(`\n── STEP ${n}: ${t}`);

/* Clean transactional data; keep config (roles, subjects, grading, fee categories). */
exec(`DELETE FROM fee_payments; DELETE FROM fee_charges; DELETE FROM student_fee_accounts;
      DELETE FROM receipt_counters; DELETE FROM terminal_reports; DELETE FROM assessments;
      DELETE FROM student_academic_history; DELETE FROM students; DELETE FROM student_id_counters;
      DELETE FROM fee_structures;`);
exec(`UPDATE school_settings SET school_name='ALEYART ACADEMY', motto='Seeking Wisdom',
      location='Odokor-Official Town, Ghana', po_box='P.O. Box 4183', telephone='0553797233'
      WHERE is_current=true;`);

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
const page = await ctx.newPage();

await page.goto(`${BASE}/login`);
await page.fill('input[name="username"]', 'admin');
await page.fill('input[name="password"]', 'Aleyart#2026');
await page.click('button[type="submit"]');
await page.waitForURL('**/dashboard**');
ok(true, 'admin login');

/* ensure years exist */
for (const y of ['2026/2027', '2027/2028']) {
  if (!q(`select count(*) from academic_years where name='${y}'`).startsWith('1')) {
    await page.goto(`${BASE}/academic/years`);
    await page.getByRole('button', { name: 'New academic year' }).click();
    await page.fill('input[name="name"]', y);
    await page.getByRole('button', { name: 'Create academic year' }).click();
    await page.waitForTimeout(1400);
  }
}
const y2627 = q(`select id from academic_years where name='2026/2027'`);
const y2728 = q(`select id from academic_years where name='2027/2028'`);
const basic1 = q(`select id from classes where name='Basic 1'`);
const basic2 = q(`select id from classes where name='Basic 2'`);
const t1_2627 = q(`select id from terms where academic_year_id='${y2627}' and name='First Term'`);
const t1_2728 = q(`select id from terms where academic_year_id='${y2728}' and name='First Term'`);

/* ---- STEPS 1–4: create student, assign class/year, QR, ID card ---- */
step('1–2', 'Create student in Basic 1 / 2026/2027');
await page.goto(`${BASE}/students/new`);
await page.fill('input[name="firstName"]', 'Ama');
await page.fill('input[name="middleName"]', 'Adjoa');
await page.fill('input[name="lastName"]', 'Serwaa');
await page.selectOption('select[name="gender"]', 'female');
await page.fill('input[name="dateOfBirth"]', '2019-04-11');
await page.selectOption('select[name="classId"]', { label: 'Basic 1' });
await page.selectOption('select[name="academicYearId"]', { label: '2026/2027' });
await page.fill('input[name="guardianName"]', 'Kwame Serwaa');
await page.fill('input[name="guardianPhone"]', '0553797233');
await page.fill('input[name="address"]', 'House 12, Odokor');
await page.setInputFiles('input[name="photo"]', 'public/brand/default-crest.png');
await page.getByRole('button', { name: /Admit student/ }).click();
await page.waitForURL(/created=1/, { timeout: 30000 });
const sid = q(`select id from students where full_name='Ama Adjoa Serwaa'`);
const code = q(`select student_code from students where id='${sid}'`);
ok(code === 'ALA-2026-0001', `Student ID is ALA-2026-0001 (got ${code})`);
ok(q(`select name from classes where id=(select class_id from students where id='${sid}')`) === 'Basic 1', 'assigned Basic 1');
ok(q(`select name from academic_years where id=(select current_academic_year_id from students where id='${sid}')`) === '2026/2027', 'assigned 2026/2027');

step(3, 'Permanent QR generated');
const qrToken = q(`select qr_token from students where id='${sid}'`);
ok(/^[A-Za-z0-9_-]{40,}$/.test(qrToken), 'permanent QR token issued');

step(4, 'ID card');
await page.goto(`${BASE}/students/${sid}/card`);
let html = await page.content();
ok(html.includes('ALEYART ACADEMY') && html.includes('Seeking Wisdom'), 'ID card shows current branding');
ok(html.includes('ALA-2026-0001') && html.includes('Basic 1'), 'ID card shows ID + Basic 1');
ok(html.includes('<svg'), 'ID card back has QR code');

/* ---- STEP 5: First Term results ---- */
step(5, 'Enter First Term results (Basic 1 / 2026/2027)');
const subs = q(`select s.id from class_subjects cs join subjects s on s.id=cs.subject_id where cs.class_id='${basic1}' order by s.name`).split('\n');
const sc = [[45,48],[40,42],[38,39],[30,33],[44,45],[36,35],[29,31],[42,41],[33,30]];
for (let i = 0; i < subs.length; i++) {
  await page.goto(`${BASE}/assessments?classId=${basic1}&termId=${t1_2627}&subjectId=${subs[i]}`);
  const [c, e] = sc[i % sc.length];
  await page.locator('input[type="number"]').nth(0).fill(String(c));
  await page.locator('input[type="number"]').nth(1).fill(String(e));
  await page.getByRole('button', { name: /Save mark sheet/ }).click();
  await page.waitForTimeout(550);
}
ok(Number(q(`select count(*) from assessments where student_id='${sid}'`)) === subs.length, `${subs.length} subject results saved`);
ok(q(`select grade from assessments where student_id='${sid}' and total=93`) === 'A', 'score 93 graded A');

/* ---- STEP 6: publish + lock ---- */
step(6, 'Publish and lock the terminal report');
await page.goto(`${BASE}/reports`);
await page.locator('select').nth(0).selectOption(basic1);
await page.locator('select').nth(1).selectOption(t1_2627);
await page.getByRole('button', { name: /Generate class reports/ }).click();
await page.waitForTimeout(2200);
const rid = q(`select id from terminal_reports where student_id='${sid}'`);
await page.goto(`${BASE}/reports/${rid}`);
await page.fill('input[placeholder*="hardworking"]', 'A bright and diligent pupil.');
await page.getByRole('button', { name: 'Save remarks' }).click();
await page.waitForTimeout(900);
await page.getByRole('button', { name: 'Publish report' }).click();
await page.waitForTimeout(1800);
await page.getByRole('button', { name: 'Lock report' }).click();
await page.waitForTimeout(1600);
ok(q(`select status from terminal_reports where id='${rid}'`) === 'locked', 'report published then locked');
ok(q(`select snapshot->'academic'->>'className' from terminal_reports where id='${rid}'`) === 'Basic 1', 'snapshot froze Basic 1');

/* ---- STEPS 14–18: fees, payment, receipt, reprint ---- */
step('14', 'Create a fee charge');
await page.goto(`${BASE}/finance/payments?studentId=${sid}`);
await page.getByRole('tab', { name: /Post charge/ }).click();
await page.locator('select[name="termId"]').selectOption(t1_2627);
await page.locator('input[name="description"]').fill('Tuition');
await page.locator('input[name="amount"]').fill('500.00');
await page.getByRole('button', { name: /Post charge/ }).click();
await page.waitForTimeout(1800);
ok(q(`select total_charged from student_fee_accounts where student_id='${sid}'`) === '500.00', 'charge of 500.00 posted');

step('15–16', 'Record payment and generate receipt');
await page.goto(`${BASE}/finance/payments?studentId=${sid}`);
await page.getByRole('tab', { name: /Record payment/ }).click();
await page.locator('select[name="termId"]').selectOption(t1_2627);
await page.locator('input[name="amount"]').fill('300.00');
await page.locator('select[name="method"]').selectOption('cash');
await page.getByRole('button', { name: /Record & issue receipt/ }).click();
await page.waitForTimeout(2200);
const receiptNo = q(`select receipt_number from fee_payments where student_id='${sid}'`);
ok(receiptNo === 'ALA-RCP-2026-000001', `receipt number is ALA-RCP-2026-000001 (got ${receiptNo})`);
ok(q(`select outstanding from student_fee_accounts where student_id='${sid}'`) === '200.00', 'outstanding = 500 - 300 = 200.00 (exact decimal)');

step('17–18', 'Reprint receipt — number must not change');
const pid = q(`select id from fee_payments where student_id='${sid}'`);
await page.goto(`${BASE}/finance/receipts/${pid}`);
let rhtml = await page.content();
ok(rhtml.includes('ALA-RCP-2026-000001'), 'receipt shows permanent number');
ok(rhtml.includes('ALEYART ACADEMY') && rhtml.includes('Seeking Wisdom'), 'receipt shows current branding');
await page.getByRole('button', { name: 'Print receipt' }).click();
await page.waitForTimeout(1500);
await page.goto(`${BASE}/finance/receipts/${pid}`);
rhtml = await page.content();
ok(q(`select receipt_number from fee_payments where id='${pid}'`) === 'ALA-RCP-2026-000001', 'receipt number UNCHANGED after reprint');
ok(Number(q(`select print_count from fee_payments where id='${pid}'`)) >= 1, 'reprint recorded');
ok(Number(q(`select count(*) from audit_logs where action in ('receipt.printed','receipt.reprinted')`)) > 0, 'reprint audited');

/* ---- STEP 7: promote ---- */
step(7, 'Promote to Basic 2 / 2027/2028');
await page.goto(`${BASE}/students/${sid}`);
await page.getByRole('button', { name: /Promote \/ transfer/ }).click();
await page.locator('select').nth(0).selectOption(basic2);
await page.locator('select').nth(1).selectOption(y2728);
await page.getByRole('button', { name: 'Confirm promotion' }).click();
await page.waitForTimeout(2000);
ok(q(`select name from classes where id=(select class_id from students where id='${sid}')`) === 'Basic 2', 'promoted to Basic 2');

/* ---- STEPS 8–10: same QR ---- */
step('8–10', 'Scan the SAME QR');
await page.goto(`${BASE}/verify/${qrToken}`);
const v = await page.content();
ok(v.includes('Basic 2'), 'QR now shows Basic 2');
ok(v.includes('2027/2028'), 'QR now shows 2027/2028');
ok(v.includes('ALA-2026-0001'), 'QR still shows ALA-2026-0001');
ok(q(`select qr_token from students where id='${sid}'`) === qrToken, 'QR token itself unchanged');
ok(!v.includes('House 12') && !v.includes('Kwame Serwaa'), 'QR page hides private guardian/address data');

/* ---- STEPS 11–13: historical report + history ---- */
step('11–12', 'Open the old report');
await page.goto(`${BASE}/reports/${rid}`);
html = await page.content();
ok(html.includes('Basic 1'), 'old report STILL shows Basic 1');
ok(html.includes('2026/2027'), 'old report STILL shows 2026/2027');

step(13, 'Academic history contains both years');
const hist = q(`select ay.name||' - '||c.name from student_academic_history h
  join academic_years ay on ay.id=h.academic_year_id join classes c on c.id=h.class_id
  where h.student_id='${sid}' order by ay.name`).split('\n');
ok(hist.includes('2026/2027 - Basic 1'), 'history has 2026/2027 — Basic 1');
ok(hist.includes('2027/2028 - Basic 2'), 'history has 2027/2028 — Basic 2');

/* ---- STEPS 19–22: rebrand ---- */
step('19', 'Change School Name, Motto and Crest');
await page.goto(`${BASE}/settings/school`);
await page.fill('input[name="schoolName"]', 'ROYAL CREST ACADEMY');
await page.fill('input[name="motto"]', 'Wisdom and Virtue');
await page.getByRole('button', { name: 'Save changes' }).click();
await page.waitForTimeout(1500);
const oldCrest = q(`select crest_file_id from school_settings where is_current=true`);
await page.setInputFiles('input[name="crest"]', 'public/brand/default-crest.png');
await page.waitForTimeout(600);
await page.getByRole('button', { name: /Save new crest/ }).click();
await page.waitForTimeout(2500);
const newCrest = q(`select crest_file_id from school_settings where is_current=true`);
ok(newCrest !== oldCrest, 'new crest uploaded and bound');

step('20–21', 'New ID card, report and receipt use NEW branding');
await page.goto(`${BASE}/students/${sid}/card`);
html = await page.content();
ok(html.includes('ROYAL CREST ACADEMY'), 'NEW ID card: updated school name');
ok(html.includes('Wisdom and Virtue'), 'NEW ID card: updated motto');
ok(html.includes(`/api/files/${newCrest}`), 'NEW ID card: updated crest');

// new term results + report after rebrand
const subs2 = q(`select s.id from class_subjects cs join subjects s on s.id=cs.subject_id where cs.class_id='${basic2}' order by s.name limit 3`).split('\n');
for (const sub of subs2) {
  await page.goto(`${BASE}/assessments?classId=${basic2}&termId=${t1_2728}&subjectId=${sub}`);
  await page.locator('input[type="number"]').nth(0).fill('40');
  await page.locator('input[type="number"]').nth(1).fill('44');
  await page.getByRole('button', { name: /Save mark sheet/ }).click();
  await page.waitForTimeout(550);
}
await page.goto(`${BASE}/reports`);
await page.locator('select').nth(0).selectOption(basic2);
await page.locator('select').nth(1).selectOption(t1_2728);
await page.getByRole('button', { name: /Generate class reports/ }).click();
await page.waitForTimeout(2200);
const rid2 = q(`select id from terminal_reports where student_id='${sid}' and term_id='${t1_2728}'`);
await page.goto(`${BASE}/reports/${rid2}`);
html = await page.content();
ok(html.includes('ROYAL CREST ACADEMY'), 'NEW report: updated school name');
ok(html.includes('Wisdom and Virtue'), 'NEW report: updated motto');
ok(html.includes(`/api/files/${newCrest}`), 'NEW report: updated crest');

await page.goto(`${BASE}/finance/payments?studentId=${sid}`);
await page.getByRole('tab', { name: /Record payment/ }).click();
await page.locator('select[name="termId"]').selectOption(t1_2728);
await page.locator('input[name="amount"]').fill('150.00');
await page.getByRole('button', { name: /Record & issue receipt/ }).click();
await page.waitForTimeout(2200);
const pid2 = q(`select id from fee_payments where student_id='${sid}' and term_id='${t1_2728}'`);
const rno2 = q(`select receipt_number from fee_payments where id='${pid2}'`);
await page.goto(`${BASE}/finance/receipts/${pid2}`);
rhtml = await page.content();
ok(rhtml.includes('ROYAL CREST ACADEMY'), 'NEW receipt: updated school name');
ok(rhtml.includes('Wisdom and Virtue'), 'NEW receipt: updated motto');
ok(rno2 !== 'ALA-RCP-2026-000001', `NEW receipt got its own number (${rno2})`);

step(22, 'Historical documents preserve original snapshots');
await page.goto(`${BASE}/reports/${rid}`);
html = await page.content();
ok(html.includes('ALEYART ACADEMY'), 'OLD report keeps ALEYART ACADEMY');
ok(html.includes('Seeking Wisdom'), 'OLD report keeps Seeking Wisdom');
ok(html.includes('Basic 1'), 'OLD report keeps Basic 1');
await page.goto(`${BASE}/finance/receipts/${pid}`);
rhtml = await page.content();
ok(rhtml.includes('ALEYART ACADEMY'), 'OLD receipt keeps ALEYART ACADEMY snapshot');
ok(rhtml.includes('ALA-RCP-2026-000001'), 'OLD receipt keeps its permanent number');

/* ---- STEPS 23–25: archive / restore / integrity ---- */
step('23–24', 'Archive then restore the student');
const before = {
  history: q(`select count(*) from student_academic_history where student_id='${sid}'`),
  assessments: q(`select count(*) from assessments where student_id='${sid}'`),
  reports: q(`select count(*) from terminal_reports where student_id='${sid}'`),
  payments: q(`select count(*) from fee_payments where student_id='${sid}'`),
  charges: q(`select count(*) from fee_charges where student_id='${sid}'`),
  audits: q(`select count(*) from audit_logs`),
};
await page.goto(`${BASE}/students/${sid}`);
await page.getByRole('button', { name: 'Archive' }).click();
await page.waitForTimeout(1600);
ok(q(`select status from students where id='${sid}'`) === 'archived', 'student archived');
await page.goto(`${BASE}/students/${sid}`);
await page.getByRole('button', { name: 'Restore' }).click();
await page.waitForTimeout(1600);
ok(q(`select status from students where id='${sid}'`) === 'active', 'student restored');

step(25, 'All data intact after archive/restore');
ok(q(`select student_code from students where id='${sid}'`) === 'ALA-2026-0001', 'Student ID intact');
ok(q(`select qr_token from students where id='${sid}'`) === qrToken, 'QR token intact');
ok(q(`select count(*) from student_academic_history where student_id='${sid}'`) === before.history, 'academic history intact');
ok(q(`select count(*) from assessments where student_id='${sid}'`) === before.assessments, 'assessments intact');
ok(q(`select count(*) from terminal_reports where student_id='${sid}'`) === before.reports, 'reports intact');
ok(q(`select count(*) from fee_payments where student_id='${sid}'`) === before.payments, 'payments intact');
ok(q(`select count(*) from fee_charges where student_id='${sid}'`) === before.charges, 'charges/fees intact');
ok(q(`select receipt_number from fee_payments where id='${pid}'`) === 'ALA-RCP-2026-000001', 'receipt intact');
ok(Number(q(`select count(*) from audit_logs`)) > Number(before.audits), 'audit log grew (archive+restore recorded)');
ok(q(`select snapshot->'school'->>'schoolName' from terminal_reports where id='${rid}'`) === 'ALEYART ACADEMY', 'historical snapshot still intact');

/* restore official branding */
await page.goto(`${BASE}/settings/school`);
await page.fill('input[name="schoolName"]', 'ALEYART ACADEMY');
await page.fill('input[name="motto"]', 'Seeking Wisdom');
await page.getByRole('button', { name: 'Save changes' }).click();
await page.waitForTimeout(1400);

await browser.close();
console.log(`\n==== FINAL ACCEPTANCE: ${pass.length} passed, ${fail.length} failed ====`);
if (fail.length) { console.log('FAILED:\n - ' + fail.join('\n - ')); process.exit(1); }
