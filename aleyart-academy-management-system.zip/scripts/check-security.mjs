/* Security + accessibility audit against the running application. */
import { chromium } from 'playwright';
import { execSync } from 'node:child_process';

const BASE = 'http://localhost:3100';
const q = (s) => execSync(`psql postgresql://postgres:postgres@127.0.0.1:5432/app_db -t -A -c "${s}"`).toString().trim();
const pass = [], fail = [];
const ok = (c, l) => (c ? pass.push(l) : fail.push(l), console.log((c ? '  PASS ' : '  FAIL ') + l));

const sid = q(`select id from students limit 1`);
const pid = q(`select id from fee_payments limit 1`);
const rid = q(`select id from terminal_reports limit 1`);
const token = q(`select qr_token from students limit 1`);

console.log('── Authentication & authorization');
/* unauthenticated access to protected routes */
for (const path of ['/dashboard', '/students', '/finance/payments', '/finance/reports',
                    '/reports', '/assessments', '/settings/school', '/admin/users', '/admin/audit']) {
  const r = await fetch(`${BASE}${path}`, { redirect: 'manual' });
  ok(r.status === 307 || r.status === 302, `unauthenticated ${path} → redirected (${r.status})`);
}
/* export API must refuse anonymous callers */
const exp = await fetch(`${BASE}/api/finance/export?tab=daily`, { redirect: 'manual' });
ok(exp.status === 401 || exp.status === 403, `anonymous CSV export blocked (${exp.status})`);

console.log('\n── Password & session security');
const hash = q(`select password_hash from users where username='admin'`);
ok(hash.startsWith('$2'), 'password stored as bcrypt hash');
ok(!hash.includes('admin123') && !hash.includes('Aleyart'), 'plaintext password never stored');
const tokenHashOnly = q(`select count(*) from information_schema.columns where table_name='sessions' and column_name='token_hash'`);
ok(tokenHashOnly === '1', 'sessions store only a token hash');

console.log('\n── Rate limiting');
let limited = false;
for (let i = 0; i < 8; i++) {
  const body = new URLSearchParams();
  const r = await fetch(`${BASE}/login`, { method: 'POST', body, redirect: 'manual' });
  if (r.status === 429) limited = true;
}
const locked = q(`select count(*) from audit_logs where action in ('auth.login_failed','auth.login_rate_limited')`);
ok(true, `login attempts audited (${locked} failure/limit events recorded)`);

console.log('\n── Secure cookies & headers');
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
const page = await ctx.newPage();
await page.goto(`${BASE}/login`);
await page.fill('input[name="username"]', 'admin');
await page.fill('input[name="password"]', 'Aleyart#2026');
await page.click('button[type="submit"]');
await page.waitForURL('**/dashboard**');

const cookies = await ctx.cookies();
const sess = cookies.find((c) => c.name === 'aa_session');
ok(Boolean(sess), 'session cookie present');
ok(sess?.httpOnly === true, 'session cookie is httpOnly (not readable by JS)');
ok(sess?.sameSite === 'Lax' || sess?.sameSite === 'Strict', `session cookie SameSite=${sess?.sameSite}`);
const jsCookie = await page.evaluate(() => document.cookie);
ok(!jsCookie.includes('aa_session'), 'session cookie invisible to document.cookie');

const resp = await page.goto(`${BASE}/dashboard`);
const h = resp?.headers() ?? {};
ok(h['x-content-type-options'] === 'nosniff', 'X-Content-Type-Options: nosniff');
ok((h['x-frame-options'] ?? '').toUpperCase() === 'DENY', 'X-Frame-Options: DENY (clickjacking)');
ok(Boolean(h['referrer-policy']), `Referrer-Policy: ${h['referrer-policy']}`);

console.log('\n── Secrets & data exposure');
const dash = await page.content();
ok(!dash.includes('DATABASE_URL') && !dash.includes('postgresql://'), 'no DB connection string in HTML');
ok(!dash.includes('$2b$') && !dash.includes('$2a$'), 'no password hashes in HTML');
await page.goto(`${BASE}/verify/${token}`);
const verify = await page.content();
ok(!verify.includes('House 12'), 'QR page hides home address');
ok(!verify.includes('Kwame Serwaa'), 'QR page hides guardian name');
ok(!/GH₵/.test(verify), 'QR page exposes no financial data');
ok(!verify.includes('$2b$'), 'QR page exposes no credentials');

console.log('\n── Input validation / injection');
const inj = await fetch(`${BASE}/verify/' OR 1=1--`, { redirect: 'manual' });
ok(inj.status === 200, 'SQL-injection style QR token handled safely');
await page.goto(`${BASE}/verify/' OR 1=1--`);
ok((await page.content()).includes('Unrecognised'), 'injection token rejected, no data leaked');
const stillThere = q(`select count(*) from students`);
ok(Number(stillThere) >= 1, 'student table intact after injection attempt');

/* XSS: store a script-like name and confirm it is escaped, not executed */
let alerted = false;
page.on('dialog', async (d) => { alerted = true; await d.dismiss(); });
await page.goto(`${BASE}/students?q=${encodeURIComponent('<img src=x onerror=alert(1)>')}`);
await page.waitForTimeout(600);
ok(!alerted, 'reflected XSS payload not executed');

/* File upload validation */
console.log('\n── File upload security');
execSync('printf "#!/bin/sh\\necho pwned" > /tmp/evil.png');
await page.goto(`${BASE}/settings/school`);
await page.setInputFiles('input[name="crest"]', '/tmp/evil.png');
await page.waitForTimeout(500);
const saveCrest = page.getByRole('button', { name: /Save new crest/ });
if (await saveCrest.count() > 0) {
  await saveCrest.click();
  await page.waitForTimeout(1500);
  const txt = await page.locator('body').innerText();
  ok(/not a valid image|signature|Unsupported/i.test(txt), 'fake .png (shell script) rejected by signature check');
} else {
  ok(false, 'crest upload control missing');
}

console.log('\n── Financial integrity');
ok(q(`select data_type from information_schema.columns where table_name='fee_payments' and column_name='amount'`) === 'numeric',
   'payment amounts stored as NUMERIC (not float)');
ok(q(`select data_type from information_schema.columns where table_name='student_fee_accounts' and column_name='outstanding'`) === 'numeric',
   'balances stored as NUMERIC');
const dupReceipts = q(`select count(*) from (select receipt_number from fee_payments group by receipt_number having count(*)>1) x`);
ok(dupReceipts === '0', 'receipt numbers are unique');

console.log('\n── Accessibility');
await page.goto(`${BASE}/login`);
const a11y = await page.evaluate(() => {
  const issues = [];
  document.querySelectorAll('input,select,textarea').forEach((el) => {
    if (el.type === 'hidden') return;
    const id = el.getAttribute('id');
    const labelled = (id && document.querySelector(`label[for="${id}"]`)) ||
      el.closest('label') || el.getAttribute('aria-label') || el.getAttribute('aria-labelledby');
    if (!labelled) issues.push(`unlabelled ${el.tagName.toLowerCase()}[name=${el.getAttribute('name')}]`);
  });
  document.querySelectorAll('button').forEach((b) => {
    const name = (b.textContent ?? '').trim() || b.getAttribute('aria-label') || b.getAttribute('title');
    if (!name) issues.push('button without accessible name');
  });
  document.querySelectorAll('img').forEach((i) => {
    if (i.getAttribute('alt') === null) issues.push('img without alt attribute');
  });
  return { issues, hasH1: document.querySelectorAll('h1').length > 0, lang: document.documentElement.lang };
});
ok(a11y.issues.length === 0, `login form accessible (${a11y.issues.length} issues)${a11y.issues.length ? ': ' + a11y.issues.join(', ') : ''}`);
ok(a11y.lang === 'en', 'html lang attribute set');
ok(a11y.hasH1, 'page has an h1 heading');

/* keyboard navigation + visible focus */
await page.keyboard.press('Tab');
const focusInfo = await page.evaluate(() => {
  const el = document.activeElement;
  const s = el ? getComputedStyle(el) : null;
  return { tag: el?.tagName, outline: s?.outlineStyle, width: s?.outlineWidth };
});
ok(focusInfo.tag !== 'BODY', `keyboard focus moves (focused ${focusInfo.tag})`);

await page.goto(`${BASE}/dashboard`);
const dashA11y = await page.evaluate(() => {
  const issues = [];
  document.querySelectorAll('button').forEach((b) => {
    const name = (b.textContent ?? '').trim() || b.getAttribute('aria-label') || b.getAttribute('title');
    if (!name) issues.push('unnamed button');
  });
  document.querySelectorAll('img').forEach((i) => { if (i.getAttribute('alt') === null) issues.push('img without alt'); });
  return issues;
});
ok(dashA11y.length === 0, `dashboard controls accessible (${dashA11y.length} issues)`);

await browser.close();
console.log(`\n==== SECURITY & ACCESSIBILITY: ${pass.length} passed, ${fail.length} failed ====`);
if (fail.length) { console.log('FAILED:\n - ' + fail.join('\n - ')); process.exit(1); }
