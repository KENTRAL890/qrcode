/* PHASE 2 acceptance test — drives the real UI end-to-end. */
import { chromium } from 'playwright';

const BASE = 'http://localhost:3100';
const pass = [], fail = [];
const ok = (cond, label) => (cond ? pass.push(label) : fail.push(label), console.log((cond ? '  PASS ' : '  FAIL ') + label));

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();

/* --- 0. login ----------------------------------------------------- */
await page.goto(`${BASE}/login`);
await page.fill('input[name="username"]', 'admin');
await page.fill('input[name="password"]', 'Aleyart#2026');
await page.click('button[type="submit"]');
await page.waitForURL('**/dashboard**');
ok(true, 'login');

/* --- 1. create academic years 2026/2027 & 2027/2028 --------------- */
for (const name of ['2026/2027', '2027/2028']) {
  await page.goto(`${BASE}/academic/years`);
  await page.getByRole('button',{name:'New academic year'}).click();
  await page.fill('input[name="name"]', name);
  await page.getByRole('button',{name:'Create academic year'}).click();
  await page.waitForTimeout(1200);
  await page.waitForTimeout(600);
  const headings = await page.locator('p.font-display').allTextContents();
  ok(headings.some(h => h.trim() === name), `year ${name} created`);
}

/* --- 2. admit student --------------------------------------------- */
await page.goto(`${BASE}/students/new`);
await page.fill('input[name="firstName"]', 'Ama');
await page.fill('input[name="middleName"]', 'Adjoa');
await page.fill('input[name="lastName"]', 'Serwaa');
await page.selectOption('select[name="gender"]', 'female');
await page.fill('input[name="dateOfBirth"]', '2018-05-12');
await page.selectOption('select[name="classId"]', { label: 'Basic 1' });
await page.selectOption('select[name="academicYearId"]', { label: '2026/2027' });
await page.fill('input[name="guardianName"]', 'Kwame Serwaa');
await page.fill('input[name="guardianRelation"]', 'Father');
await page.fill('input[name="guardianPhone"]', '0553797233');
await page.fill('input[name="address"]', 'House 12, Odokor, Accra');
await page.setInputFiles('input[name="photo"]', 'public/brand/default-crest.png');
await page.getByRole('button',{name:/Admit student/}).click();
await page.waitForURL(/created=1/, { timeout: 30000 });
await page.waitForLoadState('domcontentloaded');
const profileHtml = await page.content();
ok(profileHtml.includes('ALA-2026-0001'), 'permanent ID ALA-2026-0001 issued');
ok(profileUrlHasCreated(page), 'profile page after admission');
const studentPageUrl = page.url();
const studentUuid = studentPageUrl.match(/students\/([0-9a-f-]{36})/)[1];

/* --- 3. QR verification BEFORE promotion --------------------------- */
const { execSync } = await import('node:child_process');
const qrToken = execSync(`psql postgresql://postgres:postgres@127.0.0.1:5432/app_db -t -A -c "select qr_token from students where student_code='ALA-2026-0001'"`).toString().trim();
ok(/^[A-Za-z0-9_-]{40,}$/.test(qrToken), 'qr token exists');
await page.goto(`${BASE}/verify/${qrToken}`);
const v1 = await page.content();
ok(v1.includes('Verified — authentic student') || v1.includes('VERIFIED'), 'verify page shows verified');
ok(v1.includes('Basic 1'), 'verify shows Basic 1');
ok(v1.includes('2026/2027'), 'verify shows 2026/2027');
ok(v1.includes('ALEYART ACADEMY'), 'verify shows school name');
ok(v1.includes('Ama Adjoa Serwaa'), 'verify shows student name');
ok(v1.includes('/api/files/'), 'verify shows photo');
ok(!v1.includes('House 12'), 'verify hides private address');

/* --- 4. ID card BEFORE rebrand -------------------------------------- */
await page.goto(`${BASE}/students/${studentUuid}/card`);
const c1 = await page.content();
ok(c1.includes('ALEYART ACADEMY'), 'card shows school name');
ok(c1.includes('Seeking Wisdom'), 'card shows motto');
ok(c1.includes('ALA-2026-0001'), 'card shows permanent ID');
ok(c1.includes('Basic 1') && c1.includes('2026/2027'), 'card shows class + year');
ok(c1.includes('<svg'), 'card back contains QR svg');
await page.screenshot({ path: '/tmp/shot-idcard.png', fullPage: false });

/* --- 5. rebrand + verify propagation -------------------------------- */
await page.goto(`${BASE}/settings/school`);
await page.fill('input[name="schoolName"]', 'SUNRISE MONTESSORI SCHOOL');
await page.fill('input[name="motto"]', 'Light and Learn');
await page.getByRole('button',{name:'Save changes'}).click();
await page.waitForTimeout(1500);
await page.goto(`${BASE}/students/${studentUuid}/card`, { waitUntil: 'domcontentloaded' });
const c2 = await page.content();
ok(c2.includes('SUNRISE MONTESSORI SCHOOL'), 'ID card picks up NEW school name');
ok(c2.includes('Light and Learn'), 'ID card picks up NEW motto');
await page.goto(`${BASE}/verify/${qrToken}`);
ok((await page.content()).includes('SUNRISE MONTESSORI SCHOOL'), 'verify page picks up NEW school name');

/* restore official branding */
await page.goto(`${BASE}/settings/school`);
await page.fill('input[name="schoolName"]', 'ALEYART ACADEMY');
await page.fill('input[name="motto"]', 'Seeking Wisdom');
await page.getByRole('button',{name:'Save changes'}).click();
await page.waitForTimeout(1500);

/* --- 6. promote to Basic 2 / 2027/2028 ------------------------------- */
await page.goto(studentPageUrl);
await page.getByRole('button',{name:/Promote \/ transfer/}).click();
await page.locator('select').nth(0).selectOption({ label: 'Basic 2' });
await page.locator('select').nth(1).selectOption({ label: '2027/2028' });
await page.fill('input[maxlength="200"]', 'End of year promotion');
await page.getByRole('button',{name:'Confirm promotion'}).click();
await page.waitForTimeout(1800);
const p2 = await page.content();
ok(p2.includes('Promoted successfully'), 'promotion success message');
ok(p2.includes('ALA-2026-0001'), 'ID unchanged after promotion');
// history shows both years
ok(p2.includes('2026/2027') && p2.includes('2027/2028'), 'history shows both years');
ok(p2.includes('Basic 1') && p2.includes('Basic 2'), 'history shows both classes');

/* --- 7. same QR now resolves Basic 2 / 2027/2028 --------------------- */
await page.goto(`${BASE}/verify/${qrToken}`);
const v2 = await page.content();
ok(v2.includes('Basic 2'), 'same QR now shows Basic 2');
ok(v2.includes('2027/2028'), 'same QR now shows 2027/2028');
ok(v2.includes('ALA-2026-0001'), 'same QR still shows ALA-2026-0001');
await page.screenshot({ path: '/tmp/shot-verify.png' });

/* --- 8. card now shows Basic 2 --------------------------------------- */
await page.goto(`${BASE}/students/${studentUuid}/card`);
ok((await page.content()).includes('Basic 2'), 'ID card shows Basic 2 after promotion');

/* --- 9. directory + dashboard ---------------------------------------- */
await page.goto(`${BASE}/students`);
const dir = await page.content();
ok(dir.includes('ALA-2026-0001'), 'directory lists student');
ok(dir.includes('Basic 2'), 'directory shows Basic 2');
await page.screenshot({ path: '/tmp/shot-directory.png' });
await page.goto(`${BASE}/dashboard`);
const dash = await page.content();
ok(/>\s*1\s*</.test(dash), 'dashboard total students = 1');
await page.screenshot({ path: '/tmp/shot-dashboard.png' });

await browser.close();

console.log(`\n==== RESULT: ${pass.length} passed, ${fail.length} failed ====`);
if (fail.length) { console.log('FAILED:', fail); process.exit(1); }

function profileUrlHasCreated(p) {
  return p.url().includes('created=1');
}
