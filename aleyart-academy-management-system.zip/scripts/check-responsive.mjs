/* Responsive audit: detects horizontal overflow and clipped controls. */
import { chromium } from 'playwright';
import { execSync } from 'node:child_process';

const BASE = 'http://localhost:3100';
const q = (s) => execSync(`psql postgresql://postgres:postgres@127.0.0.1:5432/app_db -t -A -c "${s}"`).toString().trim();

const WIDTHS = [
  [320, 'phone 320'], [375, 'phone 375'], [390, 'phone 390'], [414, 'phone 414'],
  [480, 'phone 480'], [768, 'tablet 768'], [820, 'iPad 820'], [1024, 'iPad landscape'],
  [1366, 'desktop 1366'], [1440, 'desktop 1440'], [1920, 'desktop 1920'],
];

const sid = q(`select id from students limit 1`);
const rid = q(`select id from terminal_reports limit 1`);
const pid = q(`select id from fee_payments limit 1`);
const token = q(`select qr_token from students limit 1`);

const PAGES = [
  ['/login', 'Login'],
  ['/dashboard', 'Dashboard'],
  ['/students', 'Student directory'],
  [`/students/${sid}`, 'Student profile'],
  ['/students/new', 'Admit student'],
  ['/students/promote', 'Bulk promotion'],
  ['/assessments', 'Assessments'],
  ['/reports', 'Reports list'],
  [`/reports/${rid}`, 'Report detail'],
  ['/finance', 'Fee setup'],
  [`/finance/payments?studentId=${sid}`, 'Payments'],
  [`/finance/receipts/${pid}`, 'Receipt'],
  ['/finance/reports', 'Financial reports'],
  ['/settings/school', 'School settings'],
  ['/admin/users', 'Users'],
  ['/admin/audit', 'Audit log'],
  ['/academic/classes', 'Classes'],
  ['/academic/subjects', 'Subjects'],
  ['/academic/years', 'Years'],
  [`/verify/${token}`, 'QR verify'],
];

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
await page.goto(`${BASE}/login`);
await page.fill('input[name="username"]', 'admin');
await page.fill('input[name="password"]', 'Aleyart#2026');
await page.click('button[type="submit"]');
await page.waitForURL('**/dashboard**');

const issues = [];
let checks = 0;

for (const [width, wlabel] of WIDTHS) {
  await page.setViewportSize({ width, height: 900 });
  for (const [path, plabel] of PAGES) {
    await page.goto(`${BASE}${path}`, { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(140);
    checks++;

    const res = await page.evaluate(() => {
      const de = document.documentElement;
      // Documents are intentionally fixed-width (A4 / card / receipt) and
      // live inside their own horizontally scrollable viewer.
      const overflow = de.scrollWidth - de.clientWidth;
      const offenders = [];
      if (overflow > 2) {
        for (const el of Array.from(document.querySelectorAll('body *'))) {
          const r = el.getBoundingClientRect();
          if (r.width === 0 || r.height === 0) continue;
          if (r.right > de.clientWidth + 2) {
            const inScroller = el.closest('.overflow-x-auto, .report-zoom, .card-zoom');
            if (!inScroller) {
              offenders.push(`${el.tagName.toLowerCase()}.${String(el.className).split(' ').slice(0,2).join('.')}`);
              if (offenders.length >= 3) break;
            }
          }
        }
      }
      // tiny text check
      let tiny = 0;
      for (const el of Array.from(document.querySelectorAll('p,span,td,th,label,a,button'))) {
        const t = (el.textContent ?? '').trim();
        if (!t) continue;
        // Print documents (A4 report, CR80 card, receipt) are typeset in pt
        // for paper output, not for screen reading.
        if (el.closest('.report-page, .receipt-page, .id-card-face')) continue;
        const fs = parseFloat(getComputedStyle(el).fontSize);
        if (fs && fs < 9) tiny++;
      }
      return { overflow, offenders, tiny };
    });

    if (res.offenders.length > 0) {
      issues.push(`${wlabel} · ${plabel}: overflow ${res.overflow}px → ${res.offenders.join(', ')}`);
    }
    if (res.tiny > 0) {
      issues.push(`${wlabel} · ${plabel}: ${res.tiny} element(s) with font-size < 9px`);
    }
  }
}

// Mobile navigation check
await page.setViewportSize({ width: 320, height: 720 });
await page.goto(`${BASE}/dashboard`);
const menuBtn = page.getByRole('button', { name: 'Open menu' });
if (await menuBtn.count() === 0) issues.push('320: mobile menu button missing');
else {
  await menuBtn.click();
  await page.waitForTimeout(400);
  const navVisible = await page.getByRole('link', { name: 'Dashboard' }).first().isVisible();
  if (!navVisible) issues.push('320: sidebar did not open');
}

await browser.close();

console.log(`Checked ${checks} page/width combinations across ${WIDTHS.length} breakpoints.`);
if (issues.length === 0) {
  console.log('\n==== RESPONSIVE: no horizontal overflow, no unreadable text, nav OK ====');
} else {
  console.log(`\n==== RESPONSIVE ISSUES (${issues.length}) ====`);
  for (const i of issues.slice(0, 40)) console.log(' - ' + i);
  process.exit(1);
}
